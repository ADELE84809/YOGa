import { useState } from 'react';
import { PageHeader, DemoModeBadge, Disclaimer } from '@/components/Shared';
import { AssessmentFlow, type AssessmentQuestion } from '@/components/AssessmentFlow';
import { generateSession } from '@/services/recommendationService';
import { ExerciseCard } from '@/components/ExerciseCard';
import { storage } from '@/services/storageService';
import { ArrowRight, X, Plus } from 'lucide-react';
import type { Exercise } from '@/data/types';

export function SessionBuilderPage() {
  const [session, setSession] = useState<Exercise[] | null>(null);
  const [answers, setAnswers] = useState<Record<string, number | number[]> | null>(null);
  const [review, setReview] = useState(false);
  const questions: AssessmentQuestion[] = [
    { id: 'goal', question: 'Session goal?', type: 'choice', options: [
      { label: 'Flexibility', value: 1 }, { label: 'Strength', value: 2 }, { label: 'Mobility', value: 3 },
      { label: 'Recovery', value: 4 }, { label: 'Stress Relief', value: 5 }, { label: 'Energy', value: 6 },
    ]},
    { id: 'duration', question: 'Session duration?', type: 'choice', options: [
      { label: '10 min', value: 10 }, { label: '20 min', value: 20 }, { label: '30 min', value: 30 },
    ]},
    { id: 'difficulty', question: 'Difficulty level?', type: 'choice', options: [
      { label: 'Beginner', value: 1 }, { label: 'Intermediate', value: 2 }, { label: 'Advanced', value: 3 },
    ]},
    { id: 'energy', question: 'Current energy level?', type: 'scale', min: 1, max: 5, labels: ['Low', 'High'] },
  ];
  const goalMap: Record<number, string> = { 1: 'Flexibility', 2: 'Strength', 3: 'Mobility', 4: 'Recovery', 5: 'Stress Relief', 6: 'Energy' };
  const diffMap: Record<number, string> = { 1: 'Beginner', 2: 'Intermediate', 3: 'Advanced' };
  const onComplete = (a: Record<string, number | number[]>) => { setAnswers(a); setSession(generateSession({ goal: goalMap[a.goal as number], duration: a.duration as number, difficulty: diffMap[a.difficulty as number], energy: a.energy as number })); };

  return (
    <div className="pb-20 lg:pl-72">
      <PageHeader title="Personalized Session Builder" subtitle="Build a custom session from the exercise database. Replace, remove, or add exercises." badge="AI Tool" />
      <div className="section-padding">
        {!session ? <AssessmentFlow questions={questions} onComplete={onComplete} /> : !review ? (
          <div className="space-y-6">
            <div className="flex items-center justify-between"><h2 className="font-display text-2xl font-bold text-ink-800">Your Session</h2><DemoModeBadge /></div>
            <div className="space-y-3">
              {session.map((ex, i) => (
                <div key={ex.id} className="glass p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <span className="text-xs text-ink-300 font-mono">{i + 1}</span>
                      <ExerciseCard exercise={ex} />
                      <p className="text-xs text-sage-700 mt-2">Selected because it supports {goalMap[answers?.goal as number || 1]} at {diffMap[answers?.difficulty as number || 1]} level.</p>
                    </div>
                    <div className="flex flex-col gap-1">
                      <button onClick={() => setSession(session.filter((_, idx) => idx !== i))} className="p-2 rounded-lg glass-card text-ink-400 hover:text-red-400"><X className="w-4 h-4" /></button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="glass p-4 flex items-center gap-3">
              <button onClick={() => { const more = generateSession({ goal: goalMap[answers?.goal as number || 1], limit: 1 }); setSession([...session, ...more]); }} className="btn-secondary flex items-center gap-2"><Plus className="w-4 h-4" /> Add Exercise</button>
              <button onClick={() => { session.forEach(ex => storage.addSession({ id: `${ex.id}-${Date.now()}`, exerciseId: ex.id, exerciseName: ex.name, date: new Date().toISOString(), duration: ex.duration, difficulty: 3, completed: true })); setReview(true); }} className="btn-primary flex items-center gap-2 ml-auto">Complete Session <ArrowRight className="w-4 h-4" /></button>
            </div>
            <Disclaimer />
            <button onClick={() => { setSession(null); setAnswers(null); }} className="btn-secondary">Rebuild Session</button>
          </div>
        ) : (
          <div className="space-y-6 max-w-2xl mx-auto">
            <DemoModeBadge />
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-ink-800 mb-3">Session Complete</h3>
              <p className="text-sm text-ink-600">You completed a session with {session.length} exercises totaling {Math.floor(session.reduce((s, e) => s + e.duration, 0) / 60)} minutes. This has been recorded in your activity history.</p>
            </div>
            <button onClick={() => { setSession(null); setAnswers(null); setReview(false); }} className="btn-secondary">Build New Session</button>
          </div>
        )}
      </div>
    </div>
  );
}
