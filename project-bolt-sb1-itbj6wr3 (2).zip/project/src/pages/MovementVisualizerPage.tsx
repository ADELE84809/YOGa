import { useState } from 'react';
import { PageHeader, DemoModeBadge } from '@/components/Shared';
import { VirtualHuman } from '@/components/VirtualHuman';
import { ExerciseCard } from '@/components/ExerciseCard';
import { getAllExercises } from '@/services/exerciseService';
import type { MovementPhase } from '@/data/types';
import { Search } from 'lucide-react';

export function MovementVisualizerPage() {
  const exercises = getAllExercises();
  const [selected, setSelected] = useState(exercises[0]);
  const [search, setSearch] = useState('');
  const [phase, setPhase] = useState<MovementPhase>('START');
  const [playing, setPlaying] = useState(true);
  const [progress, setProgress] = useState(0);
  const [highlightedArea, setHighlightedArea] = useState<string>('');

  const filtered = search ? exercises.filter(e => e.name.toLowerCase().includes(search.toLowerCase())).slice(0, 20) : exercises.slice(0, 20);
  const bodyAreas = ['Head', 'Neck', 'Shoulders', 'Arms', 'Chest', 'Upper Back', 'Lower Back', 'Core', 'Hips', 'Glutes', 'Thighs', 'Knees', 'Calves', 'Ankles', 'Feet'];

  return (
    <div className="pb-20 lg:pl-72">
      <PageHeader title="Movement Visualizer" subtitle="Interactive movement laboratory. Select an exercise, watch the virtual human move, explore body regions, and understand every phase." badge="Signature Feature" />
      <div className="section-padding">
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="glass rounded-2xl overflow-hidden">
              <div className="relative aspect-video bg-ink-950">
                <VirtualHuman exerciseName={selected.name} primitives={selected.primitives} activePhase={phase} playing={playing} speed={0.5} progress={progress} showSkeleton showJoints showBreathing highlightedAreas={highlightedArea ? [highlightedArea] : selected.targetAreas} />
              </div>
              <div className="p-4 space-y-3">
                <div className="flex gap-2">
                  {(['START', 'MOVE', 'HOLD', 'RETURN'] as MovementPhase[]).map(p => (
                    <button key={p} onClick={() => { setPhase(p); setPlaying(false); }} className={`flex-1 py-2 rounded-lg text-xs font-medium ${phase === p ? 'bg-sage-500/20 text-sage-700' : 'glass-card text-ink-400'}`}>{p}</button>
                  ))}
                </div>
                <div className="glass-card p-3">
                  <p className="text-sm text-ink-600">{selected.instructions}</p>
                </div>
                <div className="glass-card p-3">
                  <h4 className="text-xs text-ink-400 mb-2">Form Cues</h4>
                  <ul className="space-y-1">{selected.formCues.map((c, i) => <li key={i} className="text-xs text-ink-600 flex items-start gap-2"><span className="text-sage-600">+</span>{c.cue}</li>)}</ul>
                </div>
              </div>
            </div>
          </div>
          <div className="space-y-4">
            <div>
              <div className="relative mb-3">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-300" />
                <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search movements..." className="input-field pl-11 text-sm" />
              </div>
              <div className="space-y-2 max-h-60 overflow-y-auto scrollbar-hide">
                {filtered.map(ex => (
                  <button key={ex.id} onClick={() => setSelected(ex)} className={`w-full text-left p-3 rounded-lg transition-colors ${selected.id === ex.id ? 'bg-sage-500/10 border border-sage-300' : 'glass-card'}`}>
                    <span className="text-sm text-ink-800">{ex.name}</span>
                    <span className="text-xs text-ink-300 block">{ex.category}</span>
                  </button>
                ))}
              </div>
            </div>
            <div>
              <h4 className="text-xs text-ink-400 mb-2">Interactive Body Map</h4>
              <div className="flex flex-wrap gap-1.5">
                {bodyAreas.map(area => (
                  <button key={area} onClick={() => setHighlightedArea(highlightedArea === area ? '' : area)} className={`px-2 py-1 rounded-md text-xs transition-colors ${highlightedArea === area ? 'bg-ocean-400/20 text-ocean-600' : 'glass-card text-ink-400'}`}>{area}</button>
                ))}
              </div>
              {highlightedArea && (
                <div className="mt-3 glass-card p-3">
                  <p className="text-xs text-ink-500">Exercises targeting {highlightedArea}:</p>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {exercises.filter(e => e.targetAreas.includes(highlightedArea as any)).slice(0, 5).map(ex => (
                      <button key={ex.id} onClick={() => setSelected(ex)} className="text-xs text-sage-700 hover:underline">{ex.name}</button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
        <div className="mt-8">
          <DemoModeBadge />
        </div>
      </div>
    </div>
  );
}
