import { useState } from 'react';
import { PageHeader, DemoModeBadge, Disclaimer } from '@/components/Shared';
import { AssessmentFlow, type AssessmentQuestion } from '@/components/AssessmentFlow';
import { generateGoalPlan, recommendExercises } from '@/services/recommendationService';
import { ExerciseCard } from '@/components/ExerciseCard';
import { storage } from '@/services/storageService';
import type { GoalPlan, Difficulty } from '@/data/types';

export function GoalPlannerPage() {
  const [plan, setPlan] = useState<ReturnType<typeof generateGoalPlan> | null>(null);
  const [answers, setAnswers] = useState<Record<string, number | number[]> | null>(null);
  const questions: AssessmentQuestion[] = [
    { id: 'goal', question: 'What is your primary goal?', type: 'choice', options: [
      { label: 'Flexibility', value: 1 }, { label: 'Strength', value: 2 }, { label: 'Mobility', value: 3 },
      { label: 'Balance', value: 4 }, { label: 'Stress Relief', value: 5 }, { label: 'Better Sleep', value: 6 },
    ]},
    { id: 'experience', question: 'Experience level?', type: 'choice', options: [
      { label: 'Beginner', value: 1 }, { label: 'Intermediate', value: 2 }, { label: 'Advanced', value: 3 },
    ]},
    { id: 'time', question: 'Minutes available per session?', type: 'choice', options: [
      { label: '15 min', value: 15 }, { label: '30 min', value: 30 }, { label: '45 min', value: 45 },
    ]},
    { id: 'targetDate', question: 'When do you want to achieve this?', type: 'choice', options: [
      { label: '4 weeks', value: 4 }, { label: '8 weeks', value: 8 }, { label: '12 weeks', value: 12 },
    ]},
    { id: 'difficulty', question: 'Preferred difficulty?', type: 'choice', options: [
      { label: 'Beginner', value: 1 }, { label: 'Intermediate', value: 2 }, { label: 'Advanced', value: 3 },
    ]},
  ];
  const goalMap: Record<number, string> = { 1: 'Flexibility', 2: 'Strength', 3: 'Mobility', 4: 'Balance', 5: 'Stress Relief', 6: 'Better Sleep' };
  const diffMap: Record<number, Difficulty> = { 1: 'Beginner', 2: 'Intermediate', 3: 'Advanced' };
  const onComplete = (a: Record<string, number | number[]>) => {
    setAnswers(a);
    const p = generateGoalPlan({ goal: goalMap[a.goal as number], experience: a.experience === 1 ? 'Beginner' : a.experience === 2 ? 'Intermediate' : 'Advanced', timeAvailable: a.time as number, targetDate: `${a.targetDate} weeks`, preferences: [], difficulty: diffMap[a.difficulty as number] || 'Beginner' });
    setPlan(p);
    const goalPlan: GoalPlan = { id: `goal-${Date.now()}`, goal: goalMap[a.goal as number] as any, experience: '', timeAvailable: a.time as number, targetDate: '', preferences: [], difficulty: diffMap[a.difficulty as number] || 'Beginner', milestones: p.milestones, weeklyTargets: p.weeklyTargets, recommendedExercises: p.recommendedExercises, createdAt: new Date().toISOString() };
    storage.saveGoal(goalPlan);
  };
  return (
    <div className="pb-20 lg:pl-72">
      <PageHeader title="Goal Planner" subtitle="Set a goal, get milestones, weekly targets, and recommended exercises." badge="AI Tool" />
      <div className="section-padding">
        {!plan ? <AssessmentFlow questions={questions} onComplete={onComplete} /> : (
          <div className="space-y-6">
            <div className="flex items-center justify-between"><h2 className="font-display text-2xl font-bold text-ink-800">Your Goal Plan</h2><DemoModeBadge /></div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-ink-800 mb-3">Milestones</h3>
              <div className="space-y-3">{plan.milestones.map((m, i) => (
                <div key={i} className="glass-card p-4"><div className="flex items-center gap-3"><span className="w-8 h-8 rounded-full bg-sage-500/20 text-sage-700 flex items-center justify-center text-sm font-mono">{i + 1}</span><div><p className="text-sm text-ink-800 font-medium">{m.title}</p><p className="text-xs text-ink-500">{m.description}</p></div></div></div>
              ))}</div>
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-ink-800 mb-3">Weekly Targets</h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">{plan.weeklyTargets.map(w => (
                <div key={w.week} className="glass-card p-4 text-center"><p className="text-xs text-ink-400">Week {w.week}</p><p className="text-sm text-ink-800/80 mt-1">{w.focus}</p><p className="text-xs text-sage-700 mt-1">{w.sessions} sessions</p></div>
              ))}</div>
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-ink-800 mb-3">Recommended Exercises</h3>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {plan.recommendedExercises.map(id => { const ex = recommendExercises({ limit: 50 }).exercises.find(e => e.id === id); return ex ? <ExerciseCard key={id} exercise={ex} /> : null; })}
              </div>
            </div>
            <Disclaimer />
            <button onClick={() => { setPlan(null); setAnswers(null); }} className="btn-secondary">Edit Plan</button>
          </div>
        )}
      </div>
    </div>
  );
}
