import { useParams, Link, useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { ExerciseViewer } from '@/components/ExerciseViewer';
import { ExerciseCard } from '@/components/ExerciseCard';
import { Disclaimer, DemoModeBadge } from '@/components/Shared';
import { getExerciseById, getRelatedExercises } from '@/services/exerciseService';
import { storage } from '@/services/storageService';
import { generateExerciseReview } from '@/services/recommendationService';
import { ArrowLeft, Heart, Clock, Tag, AlertTriangle, CheckCircle2, TrendingUp, ArrowRight } from 'lucide-react';

export function ExerciseDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const exercise = id ? getExerciseById(id) : undefined;
  const [showFeedback, setShowFeedback] = useState(false);
  const [review, setReview] = useState<ReturnType<typeof generateExerciseReview> | null>(null);
  const [fav, setFav] = useState(false);
  const [feedback, setFeedback] = useState({ difficulty: 3, bodyFeel: 'Good', areaFelt: '', comfortable: true, completedFullMovement: true, energyBefore: 3, energyAfter: 3 });

  useEffect(() => {
    if (id) { storage.addRecent(id); setFav(storage.getFavorites().includes(id)); }
  }, [id]);

  if (!exercise) {
    return <div className="pt-24 section-padding"><p className="text-ink-400">Exercise not found.</p><Link to="/exercises" className="btn-primary mt-4 inline-block">Back to Library</Link></div>;
  }

  const related = getRelatedExercises(exercise.id);
  const isFav = storage.getFavorites().includes(exercise.id);

  const submitFeedback = () => {
    const r = generateExerciseReview(feedback);
    setReview(r);
    storage.addSession({
      id: `${exercise.id}-${Date.now()}`, exerciseId: exercise.id, exerciseName: exercise.name,
      date: new Date().toISOString(), duration: exercise.duration, difficulty: feedback.difficulty,
      bodyFeel: feedback.bodyFeel, areaFelt: feedback.areaFelt, completed: feedback.completedFullMovement,
      energyBefore: feedback.energyBefore, energyAfter: feedback.energyAfter,
    });
    storage.addFeedback({ ...feedback, exerciseId: exercise.id, date: new Date().toISOString() });
  };

  return (
    <div className="pt-20 pb-20 lg:pl-72">
      <div className="section-padding">
        <Link to="/exercises" className="inline-flex items-center gap-1 text-sm text-ink-400 hover:text-ink-800 mb-4"><ArrowLeft className="w-4 h-4" /> Back to Library</Link>
        <div className="grid lg:grid-cols-2 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="badge-neutral">{exercise.category}</span>
              <span className="badge-sage">{exercise.difficulty}</span>
              <button onClick={() => { const f = storage.toggleFavorite(exercise.id); setFav(f); }} className="ml-auto p-2 rounded-lg glass-card">
                <Heart className={`w-4 h-4 ${fav || isFav ? 'fill-sage-700 text-sage-700' : 'text-ink-400'}`} />
              </button>
            </div>
            <h1 className="font-display text-3xl sm:text-4xl font-bold text-ink-800 mb-2">{exercise.name}</h1>
            <p className="text-ink-400 text-sm mb-4">{exercise.subcategory}</p>
            <div className="flex items-center gap-4 text-sm text-ink-500 mb-6">
              <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {Math.floor(exercise.duration / 60)} min</span>
              {exercise.goals.map(g => <span key={g} className="flex items-center gap-1"><Tag className="w-3 h-3" /> {g}</span>)}
            </div>
            <ExerciseViewer exercise={exercise} />
          </div>

          <div className="space-y-6">
            <div className="glass p-5">
              <h3 className="font-display font-semibold text-ink-800 mb-3">Instructions</h3>
              <p className="text-ink-600 text-sm leading-relaxed mb-4">{exercise.instructions}</p>
              <ol className="space-y-2">
                {exercise.steps.map((step, i) => (
                  <li key={i} className="flex gap-3 text-sm text-ink-600">
                    <span className="w-6 h-6 rounded-full bg-sage-500/20 text-sage-700 flex items-center justify-center text-xs font-mono flex-shrink-0">{i + 1}</span>
                    {step}
                  </li>
                ))}
              </ol>
            </div>

            <div className="glass p-5">
              <h3 className="font-display font-semibold text-ink-800 mb-3">Form Guide</h3>
              <ul className="space-y-2">
                {exercise.formCues.map((cue, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-ink-600">
                    <CheckCircle2 className="w-4 h-4 text-sage-600 flex-shrink-0 mt-0.5" /> {cue.cue}
                  </li>
                ))}
              </ul>
            </div>

            <div className="glass p-5">
              <h3 className="font-display font-semibold text-ink-800 mb-3">Breathing</h3>
              <p className="text-ink-600 text-sm">{exercise.breathing}</p>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="glass p-5">
                <h3 className="font-display font-semibold text-ink-800 mb-2 text-sm">Benefits</h3>
                <ul className="space-y-1">{exercise.benefits.map(b => <li key={b} className="text-xs text-ink-500 flex items-start gap-1"><span className="text-sage-600">+</span>{b}</li>)}</ul>
              </div>
              <div className="glass p-5">
                <h3 className="font-display font-semibold text-ink-800 mb-2 text-sm">Common Mistakes</h3>
                <ul className="space-y-1">{exercise.commonMistakes.map(m => <li key={m} className="text-xs text-ink-500 flex items-start gap-1"><AlertTriangle className="w-3 h-3 text-amber-400 flex-shrink-0 mt-0.5" />{m}</li>)}</ul>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="glass p-5">
                <h3 className="font-display font-semibold text-ink-800 mb-2 text-sm">Beginner Modification</h3>
                <p className="text-xs text-ink-500">{exercise.beginnerModification}</p>
              </div>
              <div className="glass p-5">
                <h3 className="font-display font-semibold text-ink-800 mb-2 text-sm">Advanced Progression</h3>
                <p className="text-xs text-ink-500">{exercise.advancedProgression}</p>
              </div>
            </div>

            <div className="glass p-5">
              <h3 className="font-display font-semibold text-ink-800 mb-3">Target Areas</h3>
              <div className="flex flex-wrap gap-2">{exercise.targetAreas.map(a => <span key={a} className="badge-ocean">{a}</span>)}</div>
              <h3 className="font-display font-semibold text-ink-800 mt-4 mb-2 text-sm">Joints Involved</h3>
              <div className="flex flex-wrap gap-2">{exercise.jointsInvolved.map(j => <span key={j} className="badge-neutral">{j}</span>)}</div>
            </div>

            <Disclaimer />

            {/* Feedback */}
            {!showFeedback && !review && (
              <button onClick={() => setShowFeedback(true)} className="btn-primary w-full">Complete Exercise & Review</button>
            )}
            {showFeedback && !review && (
              <div className="glass p-5 space-y-4">
                <div className="flex items-center justify-between"><h3 className="font-display font-semibold text-ink-800">Exercise Review</h3><DemoModeBadge /></div>
                <div>
                  <label className="text-xs text-ink-400 mb-1 block">How difficult was it? ({feedback.difficulty}/5)</label>
                  <input type="range" min={1} max={5} value={feedback.difficulty} onChange={e => setFeedback({...feedback, difficulty: Number(e.target.value)})} className="w-full accent-sage-500" />
                </div>
                <div>
                  <label className="text-xs text-ink-400 mb-1 block">How did your body feel?</label>
                  <select value={feedback.bodyFeel} onChange={e => setFeedback({...feedback, bodyFeel: e.target.value})} className="input-field text-sm">
                    <option>Great</option><option>Good</option><option>Okay</option><option>Challenging</option><option>Uncomfortable</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs text-ink-400 mb-1 block">Which area did you feel working?</label>
                  <input value={feedback.areaFelt} onChange={e => setFeedback({...feedback, areaFelt: e.target.value})} placeholder="e.g. Core, shoulders..." className="input-field text-sm" />
                </div>
                <div className="flex items-center gap-4">
                  <label className="flex items-center gap-2 text-sm text-ink-600"><input type="checkbox" checked={feedback.comfortable} onChange={e => setFeedback({...feedback, comfortable: e.target.checked})} className="accent-sage-500" /> Comfortable</label>
                  <label className="flex items-center gap-2 text-sm text-ink-600"><input type="checkbox" checked={feedback.completedFullMovement} onChange={e => setFeedback({...feedback, completedFullMovement: e.target.checked})} className="accent-sage-500" /> Full movement</label>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div><label className="text-xs text-ink-400 mb-1 block">Energy before ({feedback.energyBefore}/5)</label><input type="range" min={1} max={5} value={feedback.energyBefore} onChange={e => setFeedback({...feedback, energyBefore: Number(e.target.value)})} className="w-full accent-sage-500" /></div>
                  <div><label className="text-xs text-ink-400 mb-1 block">Energy after ({feedback.energyAfter}/5)</label><input type="range" min={1} max={5} value={feedback.energyAfter} onChange={e => setFeedback({...feedback, energyAfter: Number(e.target.value)})} className="w-full accent-sage-500" /></div>
                </div>
                <button onClick={submitFeedback} className="btn-primary w-full">Generate Review</button>
              </div>
            )}
            {review && (
              <div className="glass p-5 space-y-4">
                <div className="flex items-center justify-between"><h3 className="font-display font-semibold text-ink-800">Personalized Exercise Review</h3><DemoModeBadge /></div>
                <div><p className="text-xs text-ink-400 mb-1">What you reported</p><p className="text-sm text-ink-700">{review.whatYouReported}</p></div>
                <div><p className="text-xs text-ink-400 mb-1">What we learned</p><p className="text-sm text-ink-700">{review.whatWeLearned}</p></div>
                <div><p className="text-xs text-ink-400 mb-1">Session review</p><p className="text-sm text-ink-700">{review.sessionReview}</p></div>
                <div><p className="text-xs text-ink-400 mb-1">Suggested next step</p><p className="text-sm text-ink-700">{review.nextStep}</p></div>
                <div className="flex items-center gap-2 text-sm text-sage-700"><TrendingUp className="w-4 h-4" /> Recommended next: {review.recommendedNextType}</div>
              </div>
            )}
          </div>
        </div>

        {related.length > 0 && (
          <div className="mt-12">
            <h2 className="font-display text-2xl font-bold text-ink-800 mb-4">Related Movements</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {related.slice(0, 4).map(ex => <ExerciseCard key={ex.id} exercise={ex} />)}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
