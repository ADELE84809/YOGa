import { useState } from 'react';
import { PageHeader, DemoModeBadge, Disclaimer } from '@/components/Shared';
import { AssessmentFlow, type AssessmentQuestion } from '@/components/AssessmentFlow';
import { ProgressRing } from '@/components/ProgressRing';
import { calculateWellnessScore } from '@/services/recommendationService';
import { storage } from '@/services/storageService';

export function WellnessScorePage() {
  const [result, setResult] = useState<ReturnType<typeof calculateWellnessScore> | null>(null);
  const [answers, setAnswers] = useState<Record<string, number | number[]> | null>(null);
  const questions: AssessmentQuestion[] = [
    { id: 'movement', question: 'Weekly movement sessions?', type: 'scale', min: 0, max: 10, labels: ['None', 'Daily'] },
    { id: 'recovery', question: 'Recovery quality?', type: 'scale', min: 1, max: 10, labels: ['Poor', 'Excellent'] },
    { id: 'sleep', question: 'Sleep quality?', type: 'scale', min: 1, max: 10, labels: ['Poor', 'Excellent'] },
    { id: 'mindfulness', question: 'Mindfulness practice frequency?', type: 'scale', min: 0, max: 10, labels: ['Never', 'Daily'] },
    { id: 'routine', question: 'Routine consistency?', type: 'scale', min: 1, max: 10, labels: ['Inconsistent', 'Very consistent'] },
    { id: 'consistency', question: 'Overall consistency in wellness habits?', type: 'scale', min: 1, max: 10, labels: ['Inconsistent', 'Very consistent'] },
  ];
  const onComplete = (a: Record<string, number | number[]>) => {
    setAnswers(a);
    setResult(calculateWellnessScore({
      movement: a.movement as number * 10, recovery: a.recovery as number * 10, sleep: a.sleep as number * 10,
      mindfulness: a.mindfulness as number * 10, routine: a.routine as number * 10, consistency: a.consistency as number * 10,
    }));
  };
  return (
    <div className="pb-20 lg:pl-72">
      <PageHeader title="Wellness Score" subtitle="A transparent score based on your actual inputs. Not a clinically validated health assessment." badge="AI Tool" />
      <div className="section-padding">
        {!result ? <AssessmentFlow questions={questions} onComplete={onComplete} /> : (
          <div className="space-y-6 max-w-3xl mx-auto">
            <div className="flex items-center justify-between"><h2 className="font-display text-2xl font-bold text-ink-800">Your Wellness Score</h2><DemoModeBadge /></div>
            <div className="glass p-8 text-center">
              <ProgressRing value={result.overall} label="Overall" size={160} />
              <p className="text-ink-400 text-sm mt-4">This is a general wellness indicator, not a clinically validated score.</p>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {Object.entries(result.breakdown).map(([key, val]) => (
                <div key={key} className="glass-card p-4 text-center"><ProgressRing value={val} size={80} /><p className="text-sm text-ink-600 mt-2">{key}</p></div>
              ))}
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-ink-800 mb-3">Improvement Opportunities</h3>
              <ul className="space-y-2">{result.improvements.map(imp => <li key={imp} className="text-sm text-ink-600 flex items-start gap-2"><span className="w-1.5 h-1.5 rounded-full bg-sage-500 mt-1.5" />{imp}</li>)}</ul>
            </div>
            <div className="glass p-6"><h3 className="font-display font-semibold text-ink-800 mb-2">Next Action</h3><p className="text-sm text-sage-700">{result.nextAction}</p></div>
            <Disclaimer />
            <button onClick={() => { setResult(null); setAnswers(null); }} className="btn-secondary">Recalculate</button>
          </div>
        )}
      </div>
    </div>
  );
}
