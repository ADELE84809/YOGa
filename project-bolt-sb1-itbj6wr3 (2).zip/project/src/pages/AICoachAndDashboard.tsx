import { PageHeader, DemoModeBadge, Disclaimer, EmptyState } from '@/components/Shared';
import { storage } from '@/services/storageService';
import { recommendExercises } from '@/services/recommendationService';
import { ExerciseCard } from '@/components/ExerciseCard';
import { ProgressRing } from '@/components/ProgressRing';
import { Link } from 'react-router-dom';
import { Sparkles, Target, Clock, TrendingUp, ArrowRight } from 'lucide-react';

export function GlobalYogaAIPage() {
  const profile = storage.getProfile();
  const sessions = storage.getSessions();
  const assessments = storage.getAssessments();
  const goals = storage.getGoals();
  const rec = recommendExercises({ goal: profile.goal, difficulty: profile.experience, limit: 4 });
  return (
    <div className="pb-20 lg:pl-72">
      <PageHeader title="GlobalYoga AI Coach" subtitle="The central intelligence layer combining your profile, goals, history, and feedback into unified recommendations." badge="AI Tool" />
      <div className="section-padding space-y-6">
        <DemoModeBadge />
        <div className="grid lg:grid-cols-3 gap-4">
          <div className="glass p-5"><Sparkles className="w-5 h-5 text-sage-700 mb-2" /><p className="text-sm text-ink-600">Profile: {profile.goal || 'Not set'} • {profile.experience || 'Not set'}</p></div>
          <div className="glass p-5"><Clock className="w-5 h-5 text-ocean-600 mb-2" /><p className="text-sm text-ink-600">{sessions.length} sessions completed</p></div>
          <div className="glass p-5"><Target className="w-5 h-5 text-sage-600 mb-2" /><p className="text-sm text-ink-600">{goals.length} goals set • {assessments.length} assessments</p></div>
        </div>
        {sessions.length === 0 && assessments.length === 0 ? (
          <EmptyState title="No data yet" message="Complete an assessment or a few exercises to unlock personalized AI recommendations." />
        ) : (
          <>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-ink-800 mb-3">Today's Recommendation</h3>
              <p className="text-sm text-ink-600 mb-4">Based on your profile and activity, here are recommended exercises:</p>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">{rec.exercises.map(ex => <ExerciseCard key={ex.id} exercise={ex} />)}</div>
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-ink-800 mb-3">Quick Actions</h3>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
                <Link to="/wellness-assessment" className="glass-card p-3 text-center text-sm text-ink-600 hover:text-sage-700">Take Assessment</Link>
                <Link to="/session-builder" className="glass-card p-3 text-center text-sm text-ink-600 hover:text-sage-700">Build Session</Link>
                <Link to="/goal-planner" className="glass-card p-3 text-center text-sm text-ink-600 hover:text-sage-700">Set Goal</Link>
                <Link to="/wellness-os" className="glass-card p-3 text-center text-sm text-ink-600 hover:text-sage-700">Open Dashboard</Link>
              </div>
            </div>
          </>
        )}
        <Disclaimer />
      </div>
    </div>
  );
}

export function WellnessOSPage() {
  const sessions = storage.getSessions();
  const assessments = storage.getAssessments();
  const goals = storage.getGoals();
  const routines = storage.getRoutines();
  const profile = storage.getProfile();
  const favorites = storage.getFavorites();
  const recent = storage.getRecent();
  const totalMinutes = sessions.reduce((s, ses) => s + sen.duration, 0);
  return (
    <div className="pb-20 lg:pl-72">
      <PageHeader title="Wellness OS" subtitle="Your personal wellness command center. All data is real — no fabricated numbers." badge="Dashboard" />
      <div className="section-padding space-y-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="glass p-5 text-center"><p className="font-display text-2xl font-bold text-ink-800">{sessions.length}</p><p className="text-xs text-ink-400">Sessions</p></div>
          <div className="glass p-5 text-center"><p className="font-display text-2xl font-bold text-ink-800">{totalMinutes}</p><p className="text-xs text-ink-400">Minutes</p></div>
          <div className="glass p-5 text-center"><p className="font-display text-2xl font-bold text-ink-800">{goals.length}</p><p className="text-xs text-ink-400">Goals</p></div>
          <div className="glass p-5 text-center"><p className="font-display text-2xl font-bold text-ink-800">{routines.length}</p><p className="text-xs text-ink-400">Saved Routines</p></div>
        </div>
        <div className="grid lg:grid-cols-2 gap-6">
          <div className="glass p-6">
            <h3 className="font-display font-semibold text-ink-800 mb-3">Quick Actions</h3>
            <div className="grid grid-cols-2 gap-2">
              <Link to="/ai-yoga-coach" className="glass-card p-3 text-center text-sm text-ink-600 hover:text-sage-700">AI Coach</Link>
              <Link to="/session-builder" className="glass-card p-3 text-center text-sm text-ink-600 hover:text-sage-700">Build Session</Link>
              <Link to="/breathing-lab" className="glass-card p-3 text-center text-sm text-ink-600 hover:text-sage-700">Breathing</Link>
              <Link to="/meditation-studio" className="glass-card p-3 text-center text-sm text-ink-600 hover:text-sage-700">Meditate</Link>
            </div>
          </div>
          <div className="glass p-6">
            <h3 className="font-display font-semibold text-ink-800 mb-3">Profile</h3>
            <p className="text-sm text-ink-600">Goal: {profile.goal || 'Not set'}</p>
            <p className="text-sm text-ink-600">Experience: {profile.experience || 'Not set'}</p>
            <p className="text-sm text-ink-600">Preferred duration: {profile.preferredDuration ? `${Math.floor(profile.preferredDuration / 60)} min` : 'Not set'}</p>
          </div>
        </div>
        {sessions.length > 0 && (
          <div className="glass p-6">
            <h3 className="font-display font-semibold text-ink-800 mb-3">Recent Activity</h3>
            <div className="space-y-2">{sessions.slice(0, 5).map(s => (
              <div key={s.id} className="flex items-center justify-between glass-card p-3">
                <span className="text-sm text-ink-800/80">{s.exerciseName}</span>
                <span className="text-xs text-ink-400">{new Date(s.date).toLocaleDateString()} • {Math.floor(s.duration / 60)}min</span>
              </div>
            ))}</div>
          </div>
        )}
        {favorites.length > 0 && (
          <div className="glass p-6">
            <h3 className="font-display font-semibold text-ink-800 mb-3">Favorites</h3>
            <div className="flex flex-wrap gap-2">{favorites.slice(0, 10).map(id => {
              const ex = storage.getRecent().includes(id) ? id : null;
              return ex ? <Link key={id} to={`/exercise/${id}`} className="badge-sage text-xs">{id}</Link> : null;
            })}</div>
          </div>
        )}
        {assessments.length > 0 && (
          <div className="glass p-6">
            <h3 className="font-display font-semibold text-ink-800 mb-3">Latest Assessment</h3>
            <div className="flex items-center gap-4"><ProgressRing value={assessments[0].movement} size={60} /><ProgressRing value={assessments[0].energy} size={60} /><ProgressRing value={assessments[0].sleep} size={60} /></div>
          </div>
        )}
      </div>
    </div>
  );
}
