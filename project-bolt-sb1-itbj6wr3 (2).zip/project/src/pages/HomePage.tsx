import { Link } from 'react-router-dom';
import { VirtualHuman } from '@/components/VirtualHuman';
import { ToolCard, aiTools } from '@/data/aiTools';
import { exerciseCount } from '@/data/exercises';
import { images } from '@/data/images';
import { ArrowRight, Activity, Brain, Eye, Heart, Zap, Moon, Leaf, Wind } from 'lucide-react';

export function HomePage() {
  return (
    <div className="min-h-screen lg:pl-72">
      {/* Hero */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden pt-14">
        <div className="absolute inset-0">
          <img src={images.heroMeditation} alt="Woman meditating in peace" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-cream-50/95 via-cream-50/70 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-cream-50 via-transparent to-cream-50/30" />
        </div>
        <div className="section-padding relative z-10 py-20">
          <div className="max-w-xl animate-fade-up">
            <div className="badge-sage mb-6"><Leaf className="w-3 h-3" /> Intelligent Wellness Platform</div>
            <h1 className="font-display text-5xl sm:text-6xl font-bold text-ink-800 leading-[1.05] text-balance">
              Your Body.<br />Your Mind.<br /><span className="text-gradient">In Harmony.</span>
            </h1>
            <p className="text-ink-500 text-lg mt-6 max-w-lg text-balance">
              One calm, intelligent platform for yoga, movement, recovery, and mindfulness. {exerciseCount}+ exercises, 20 AI tools, real progress tracking.
            </p>
            <div className="flex flex-wrap items-center gap-3 mt-8">
              <Link to="/ai-yoga-coach" className="btn-primary flex items-center gap-2">Start Free <ArrowRight className="w-4 h-4" /></Link>
              <Link to="/courses" className="btn-secondary flex items-center gap-2">View Courses</Link>
            </div>
            <p className="text-ink-400 text-sm mt-4">Free tools • No sign-up required</p>
          </div>
        </div>
      </section>

      {/* Why */}
      <section className="py-20 section-padding">
        <h2 className="font-display text-3xl sm:text-4xl font-bold text-ink-800 text-center mb-4">Why GlobalYogaCourse</h2>
        <p className="text-ink-400 text-center max-w-2xl mx-auto mb-12">Understand your body → Build better movement → Recover → Improve → Repeat</p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { icon: Brain, title: 'Understand', desc: 'Assess your body, posture, mobility, and wellness with intelligent tools.' },
            { icon: Activity, title: 'Move Better', desc: `${exerciseCount}+ exercises with virtual human visualization and form guidance.` },
            { icon: Heart, title: 'Recover', desc: 'Personalized recovery, breathing, and meditation sessions.' },
            { icon: Zap, title: 'Improve', desc: 'Track real progress and get smarter recommendations over time.' },
          ].map((item, i) => {
            const Icon = item.icon;
            return (
              <div key={i} className="glass-card p-6">
                <div className="p-3 rounded-xl bg-sage-50 w-fit mb-4"><Icon className="w-6 h-6 text-sage-600" /></div>
                <h3 className="font-display font-semibold text-ink-800 text-lg mb-2">{item.title}</h3>
                <p className="text-ink-400 text-sm leading-relaxed">{item.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* AI Wellness Hub */}
      <section className="py-20 section-padding">
        <div className="text-center mb-12">
          <span className="badge-ocean mb-4"><Brain className="w-3 h-3" /> 20 AI Wellness Tools</span>
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-ink-800">AI Wellness Hub</h2>
          <p className="text-ink-400 mt-2">Each tool is a standalone mini-product with personalized output.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {aiTools.slice(0, 12).map(tool => <ToolCard key={tool.id} tool={tool} />)}
        </div>
        <div className="text-center mt-8">
          <Link to="/ai-tools" className="btn-secondary inline-flex items-center gap-2">View All 20 Tools <ArrowRight className="w-4 h-4" /></Link>
        </div>
      </section>

      {/* Movement Intelligence with photo */}
      <section className="py-20 section-padding">
        <div className="grid lg:grid-cols-2 gap-8 items-center">
          <div className="relative h-[400px] rounded-2xl overflow-hidden">
            <img src={images.warriorPose} alt="Warrior yoga pose at sunrise" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-ink-900/40 to-transparent" />
          </div>
          <div>
            <span className="badge-sage mb-4"><Eye className="w-3 h-3" /> Movement Intelligence</span>
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-ink-800 mb-4">Virtual Human Exercise System</h2>
            <p className="text-ink-500 leading-relaxed mb-6">
              A holographic human shows you exactly how each movement works. See the skeleton, joints, movement paths, and breathing — all in an interactive laboratory.
            </p>
            <ul className="space-y-2 text-ink-600">
              {['Front, side, and back camera views', 'Skeleton and joint tracking overlays', 'Movement phase timeline (Start → Move → Hold → Return)', 'Compare correct form vs common mistakes', 'Breathing synchronization guide'].map(f => (
              <li key={f} className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-sage-400" />{f}</li>
            ))}
            </ul>
            <Link to="/movement-visualizer" className="btn-primary mt-8 inline-flex items-center gap-2">Open Movement Lab <ArrowRight className="w-4 h-4" /></Link>
          </div>
        </div>
      </section>

      {/* Exercise Library */}
      <section className="py-20 section-padding">
        <div className="text-center mb-12">
          <span className="badge-sage mb-4"><Activity className="w-3 h-3" /> Exercise Database</span>
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-ink-800">{exerciseCount}+ Structured Movements</h2>
          <p className="text-ink-400 mt-2">Yoga, mobility, strength, breathing, meditation, recovery, and more.</p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {['Yoga', 'Mobility', 'Strength', 'Breathing', 'Meditation', 'Posture', 'Recovery', 'Movement Break'].map(cat => (
            <Link key={cat} to={`/exercises?category=${cat}`} className="glass-card p-4 text-center group">
              <span className="text-sm font-medium text-ink-600 group-hover:text-sage-700 transition-colors">{cat}</span>
            </Link>
          ))}
        </div>
        <div className="text-center mt-8">
          <Link to="/exercises" className="btn-secondary inline-flex items-center gap-2">Browse All Exercises <ArrowRight className="w-4 h-4" /></Link>
        </div>
      </section>

      {/* Courses as USP */}
      <section className="py-20 section-padding">
        <div className="text-center mb-12">
          <span className="badge-clay mb-4"><Moon className="w-3 h-3" /> Our Signature Programs</span>
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-ink-800">Premium Yoga Courses</h2>
          <p className="text-ink-400 mt-2 max-w-2xl mx-auto">Structured learning journeys designed by experts. Lifetime access.</p>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="glass-card overflow-hidden group">
            <div className="relative h-48 overflow-hidden">
              <img src={images.courseFoundations} alt="Yoga foundations class" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-900/50 to-transparent" />
              <span className="absolute top-3 left-3 badge-sage">Beginner</span>
            </div>
            <div className="p-6">
              <h3 className="font-display text-xl font-bold text-ink-800 mb-2">Yoga Foundations Masterclass</h3>
              <p className="text-ink-400 text-sm mb-4">Build a strong, safe, and sustainable yoga practice from the ground up.</p>
              <div className="flex items-center justify-between">
                <div><span className="text-2xl font-bold text-sage-700">₹29</span> <span className="text-sm text-ink-300 line-through">₹1,500</span></div>
                <span className="text-sm text-ink-400">1.5 hours</span>
              </div>
              <Link to="/courses/yoga-foundations" className="btn-primary mt-4 w-full text-center">Enroll Now</Link>
            </div>
          </div>
          <div className="glass-card overflow-hidden group">
            <div className="relative h-48 overflow-hidden">
              <img src={images.course7Day} alt="7 day yoga transformation" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-900/50 to-transparent" />
              <span className="absolute top-3 left-3 badge-clay">Launch Offer</span>
            </div>
            <div className="p-6">
              <div className="flex items-center gap-2 mb-2"><span className="badge-clay">Save ₹2,601</span></div>
              <h3 className="font-display text-xl font-bold text-ink-800 mb-2">7-Day AI Yoga Transformation</h3>
              <p className="text-ink-400 text-sm mb-4">A structured week-long journey to transform your practice and wellbeing.</p>
              <div className="flex items-center justify-between">
                <div><span className="text-2xl font-bold text-sage-700">₹399</span> <span className="text-sm text-ink-300 line-through">₹3,000</span></div>
                <span className="text-sm text-ink-400">7 days • All levels</span>
              </div>
              <Link to="/courses/7-day-transformation" className="btn-primary mt-4 w-full text-center">Enroll Now</Link>
            </div>
          </div>
        </div>
      </section>

      {/* Breathing & Meditation with photo */}
      <section className="py-20 section-padding">
        <div className="grid lg:grid-cols-2 gap-8 items-center">
          <div>
            <span className="badge-ocean mb-4"><Wind className="w-3 h-3" /> Breathing & Meditation</span>
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-ink-800 mb-4">Find Your Calm</h2>
            <p className="text-ink-500 leading-relaxed mb-6">
              Interactive breathing sessions with visual guides. Personalized meditation. Evening wind-down routines for better sleep.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link to="/breathing-lab" className="btn-primary">Breathing Lab</Link>
              <Link to="/meditation-studio" className="btn-secondary">Meditate</Link>
            </div>
          </div>
          <div className="relative h-[350px] rounded-2xl overflow-hidden">
            <img src={images.breathingClose} alt="Woman practicing breathing techniques" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-ink-900/30 to-transparent" />
          </div>
        </div>
      </section>

      {/* Wellness OS */}
      <section className="py-20 section-padding">
        <div className="glass p-8 lg:p-12 text-center">
          <span className="badge-ocean mb-4"><Zap className="w-3 h-3" /> Wellness OS</span>
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-ink-800 mb-4">Your Personal Wellness Dashboard</h2>
          <p className="text-ink-500 max-w-2xl mx-auto mb-8">Track sessions, habits, goals, and progress — all from real data. No fake numbers.</p>
          <Link to="/wellness-os" className="btn-primary inline-flex items-center gap-2">Open Wellness OS <ArrowRight className="w-4 h-4" /></Link>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 section-padding">
        <div className="text-center">
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-ink-800 mb-4">Start Your Wellness Journey</h2>
          <p className="text-ink-400 mb-8 max-w-xl mx-auto">Free tools. No sign-up required. {exerciseCount}+ movements and 20 intelligent wellness tools.</p>
          <div className="flex flex-wrap justify-center gap-3">
            <Link to="/ai-tools" className="btn-primary">Explore AI Tools</Link>
            <Link to="/wellness-assessment" className="btn-secondary">Take Assessment</Link>
          </div>
        </div>
      </section>
    </div>
  );
}
