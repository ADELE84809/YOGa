import { useState } from 'react';
import { PageHeader, DemoModeBadge, Disclaimer } from '@/components/Shared';
import { AssessmentFlow, type AssessmentQuestion } from '@/components/AssessmentFlow';
import { recommendExercises } from '@/services/recommendationService';
import { ExerciseCard } from '@/components/ExerciseCard';

export function ExerciseIntelligencePage() {
  const [result, setResult] = useState<ReturnType<typeof recommendExercises> | null>(null);
  const questions: AssessmentQuestion[] = [
    { id: 'goal', question: 'What is your primary goal?', type: 'choice', options: [
      { label: 'Flexibility', value: 1 }, { label: 'Strength', value: 2 }, { label: 'Mobility', value: 3 },
      { label: 'Balance', value: 4 }, { label: 'Recovery', value: 5 }, { label: 'Stress Relief', value: 6 },
    ]},
    { id: 'bodyArea', question: 'Which body area do you want to target?', type: 'choice', options: [
      { label: 'Hips', value: 1 }, { label: 'Shoulders', value: 2 }, { label: 'Lower Back', value: 3 },
      { label: 'Core', value: 4 }, { label: 'Neck', value: 5 }, { label: 'Full Body', value: 6 },
    ]},
    { id: 'difficulty', question: 'What difficulty level?', type: 'choice', options: [
      { label: 'Beginner', value: 1 }, { label: 'Intermediate', value: 2 }, { label: 'Advanced', value: 3 },
    ]},
    { id: 'duration', question: 'How much time do you have?', type: 'choice', options: [
      { label: 'Under 5 min', value: 300 }, { label: '5-10 min', value: 600 }, { label: '10-20 min', value: 1200 },
    ]},
    { id: 'energy', question: 'Current energy level?', type: 'scale', min: 1, max: 5, labels: ['Low', 'High'] },
  ];
  const goalMap: Record<number, string> = { 1: 'Flexibility', 2: 'Strength', 3: 'Mobility', 4: 'Balance', 5: 'Recovery', 6: 'Stress Relief' };
  const areaMap: Record<number, string> = { 1: 'Hips', 2: 'Shoulders', 3: 'Lower Back', 4: 'Core', 5: 'Neck', 6: '' };
  const diffMap: Record<number, string> = { 1: 'Beginner', 2: 'Intermediate', 3: 'Advanced' };
  const onComplete = (a: Record<string, number | number[]>) => {
    const rec = recommendExercises({ goal: goalMap[a.goal as number], bodyArea: areaMap[a.bodyArea as number], difficulty: diffMap[a.difficulty as number], maxDuration: a.duration as number, energy: a.energy as number, limit: 6 });
    setResult(rec);
  };
  return (
    <div className="pb-20 lg:pl-72">
      <PageHeader title="Exercise Intelligence" subtitle="Find the perfect exercises based on your goals, body area, and current state. Every recommendation includes a clear reason why." badge="AI Tool" />
      <div className="section-padding">
        {!result ? <AssessmentFlow questions={questions} onComplete={onComplete} /> : (
          <div className="space-y-6">
            <div className="flex items-center justify-between"><h2 className="font-display text-2xl font-bold text-ink-800">Recommended Exercises</h2><DemoModeBadge /></div>
            {result.exercises.map(ex => (
              <div key={ex.id} className="glass p-5">
                <ExerciseCard exercise={ex} />
                <p className="text-sm text-sage-700 mt-3">{result.reasons[ex.id]}</p>
                <div className="mt-3 grid sm:grid-cols-2 gap-2 text-xs text-ink-500">
                  <p><span className="text-ink-300">Beginner:</span> {ex.beginnerModification}</p>
                  <p><span className="text-ink-300">Advanced:</span> {ex.advancedProgression}</p>
                </div>
                <div className="mt-2 flex flex-wrap gap-1">{ex.benefits.map(b => <span key={b} className="badge-sage text-[10px]">{b}</span>)}</div>
                <div className="mt-2"><p className="text-xs text-ink-300 mb-1">Recovery suggestion: {ex.safetyNotes}</p></div>
              </div>
            ))}
            <Disclaimer />
            <button onClick={() => setResult(null)} className="btn-secondary">New Search</button>
          </div>
        )}
      </div>
    </div>
  );
}
