import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Navigation } from '@/components/Navigation';
import { HomePage } from '@/pages/HomePage';
import { ExerciseLibraryPage } from '@/pages/ExerciseLibraryPage';
import { ExerciseDetailPage } from '@/pages/ExerciseDetailPage';
import { ExerciseIntelligencePage } from '@/pages/ExerciseIntelligencePage';
import { MovementVisualizerPage } from '@/pages/MovementVisualizerPage';
import { AIYogaCoachPage } from '@/pages/AIYogaCoachPage';
import { PostureLabPage, FlexibilityLabPage, MobilityLabPage, RecoveryLabPage } from '@/pages/LabPages';
import { BreathingLabPage, MeditationStudioPage, SleepStudioPage, FocusStudioPage } from '@/pages/StudioPages';
import { WellnessAssessmentPage } from '@/pages/WellnessAssessmentPage';
import { RoutineBuilderPage } from '@/pages/RoutineBuilderPage';
import { HabitIntelligencePage, ProgressIntelligencePage } from '@/pages/TrackingPages';
import { WellnessScorePage } from '@/pages/WellnessScorePage';
import { GoalPlannerPage } from '@/pages/GoalPlannerPage';
import { SessionBuilderPage } from '@/pages/SessionBuilderPage';
import { GlobalYogaAIPage, WellnessOSPage } from '@/pages/AICoachAndDashboard';
import { NutritionPage } from '@/pages/NutritionPage';
import { AIToolsPage, ProgramsPage } from '@/pages/IndexPages';
import { CoursesPage, CourseDetailPage } from '@/pages/CoursePages';
import { AboutPage } from '@/pages/AboutPage';

function App() {
  return (
    <BrowserRouter>
      <Navigation />
      <main className="pb-16 lg:pb-0">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/ai-tools" element={<AIToolsPage />} />
          <Route path="/exercises" element={<ExerciseLibraryPage />} />
          <Route path="/exercise/:id" element={<ExerciseDetailPage />} />
          <Route path="/ai-yoga-coach" element={<AIYogaCoachPage />} />
          <Route path="/exercise-intelligence" element={<ExerciseIntelligencePage />} />
          <Route path="/movement-visualizer" element={<MovementVisualizerPage />} />
          <Route path="/posture-lab" element={<PostureLabPage />} />
          <Route path="/flexibility-lab" element={<FlexibilityLabPage />} />
          <Route path="/mobility-lab" element={<MobilityLabPage />} />
          <Route path="/breathing-lab" element={<BreathingLabPage />} />
          <Route path="/meditation-studio" element={<MeditationStudioPage />} />
          <Route path="/wellness-assessment" element={<WellnessAssessmentPage />} />
          <Route path="/routine-builder" element={<RoutineBuilderPage />} />
          <Route path="/habit-intelligence" element={<HabitIntelligencePage />} />
          <Route path="/recovery-lab" element={<RecoveryLabPage />} />
          <Route path="/sleep-studio" element={<SleepStudioPage />} />
          <Route path="/focus-studio" element={<FocusStudioPage />} />
          <Route path="/nutrition" element={<NutritionPage />} />
          <Route path="/wellness-score" element={<WellnessScorePage />} />
          <Route path="/progress-intelligence" element={<ProgressIntelligencePage />} />
          <Route path="/goal-planner" element={<GoalPlannerPage />} />
          <Route path="/session-builder" element={<SessionBuilderPage />} />
          <Route path="/globalyoga-ai" element={<GlobalYogaAIPage />} />
          <Route path="/wellness-os" element={<WellnessOSPage />} />
          <Route path="/programs" element={<ProgramsPage />} />
          <Route path="/courses" element={<CoursesPage />} />
          <Route path="/courses/:id" element={<CourseDetailPage />} />
          <Route path="/about" element={<AboutPage />} />
        </Routes>
      </main>
    </BrowserRouter>
  );
}

export default App;
