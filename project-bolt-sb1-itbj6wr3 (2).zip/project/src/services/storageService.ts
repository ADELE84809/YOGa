import type { SessionRecord, FeedbackRecord, AssessmentResult, SavedRoutine, GoalPlan, UserProfile } from '@/data/types';

const KEYS = {
  sessions: 'gyc_sessions', feedback: 'gyc_feedback', assessment: 'gyc_assessment',
  routines: 'gyc_routines', goals: 'gyc_goals', profile: 'gyc_profile', favorites: 'gyc_favorites', recent: 'gyc_recent',
};

function read<T>(key: string, fallback: T): T {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch { return fallback; }
}
function write(key: string, val: unknown) { try { localStorage.setItem(key, JSON.stringify(val)); } catch {} }

export const storage = {
  getSessions: () => read<SessionRecord[]>(KEYS.sessions, []),
  addSession: (s: SessionRecord) => { const all = read<SessionRecord[]>(KEYS.sessions, []); all.unshift(s); write(KEYS.sessions, all.slice(0, 200)); },
  getFeedback: () => read<FeedbackRecord[]>(KEYS.feedback, []),
  addFeedback: (f: FeedbackRecord) => { const all = read<FeedbackRecord[]>(KEYS.feedback, []); all.unshift(f); write(KEYS.feedback, all.slice(0, 200)); },
  getAssessments: () => read<AssessmentResult[]>(KEYS.assessment, []),
  addAssessment: (a: AssessmentResult) => { const all = read<AssessmentResult[]>(KEYS.assessment, []); all.unshift(a); write(KEYS.assessment, all.slice(0, 50)); },
  getRoutines: () => read<SavedRoutine[]>(KEYS.routines, []),
  saveRoutine: (r: SavedRoutine) => { const all = read<SavedRoutine[]>(KEYS.routines, []); all.unshift(r); write(KEYS.routines, all); },
  deleteRoutine: (id: string) => { const all = read<SavedRoutine[]>(KEYS.routines, []).filter(r => r.id !== id); write(KEYS.routines, all); },
  getGoals: () => read<GoalPlan[]>(KEYS.goals, []),
  saveGoal: (g: GoalPlan) => { const all = read<GoalPlan[]>(KEYS.goals, []); all.unshift(g); write(KEYS.goals, all); },
  getProfile: () => read<UserProfile>(KEYS.profile, {}),
  saveProfile: (p: UserProfile) => write(KEYS.profile, p),
  getFavorites: () => read<string[]>(KEYS.favorites, []),
  toggleFavorite: (id: string) => {
    const favs = read<string[]>(KEYS.favorites, []);
    const idx = favs.indexOf(id);
    if (idx >= 0) favs.splice(idx, 1); else favs.unshift(id);
    write(KEYS.favorites, favs);
    return favs.includes(id);
  },
  getRecent: () => read<string[]>(KEYS.recent, []),
  addRecent: (id: string) => {
    const recent = read<string[]>(KEYS.recent, []).filter(r => r !== id);
    recent.unshift(id);
    write(KEYS.recent, recent.slice(0, 20));
  },
};
