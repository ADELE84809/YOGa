import { exercises } from '@/data/exercises';
import type { Exercise, Difficulty, Goal, BodyRegion } from '@/data/types';

export function getAllExercises(): Exercise[] { return exercises; }
export function getExerciseById(id: string): Exercise | undefined { return exercises.find(e => e.id === id); }
export function searchExercises(query: string): Exercise[] {
  const q = query.toLowerCase();
  return exercises.filter(e => e.name.toLowerCase().includes(q) || e.tags.some(t => t.toLowerCase().includes(q)));
}
export interface FilterOptions {
  category?: string; difficulty?: string; goal?: string; bodyArea?: string; equipment?: string; maxDuration?: number;
}
export function filterExercises(opts: FilterOptions): Exercise[] {
  return exercises.filter(e => {
    if (opts.category && e.category !== opts.category) return false;
    if (opts.difficulty && e.difficulty !== opts.difficulty) return false;
    if (opts.goal && !e.goals.includes(opts.goal as Goal)) return false;
    if (opts.bodyArea && !e.targetAreas.includes(opts.bodyArea as BodyRegion)) return false;
    if (opts.equipment && !e.equipment.includes(opts.equipment)) return false;
    if (opts.maxDuration && e.duration > opts.maxDuration) return false;
    return true;
  });
}
export function getRelatedExercises(id: string): Exercise[] {
  const ex = getExerciseById(id);
  if (!ex) return [];
  return ex.relatedExercises.map(rid => getExerciseById(rid)).filter(Boolean) as Exercise[];
}
export function getCategories(): string[] { return [...new Set(exercises.map(e => e.category))]; }
export function getDifficulties(): Difficulty[] { return ['Beginner', 'Intermediate', 'Advanced']; }
export function getGoals(): string[] { return [...new Set(exercises.flatMap(e => e.goals))] as string[]; }
export function getBodyAreas(): string[] { return [...new Set(exercises.flatMap(e => e.targetAreas))] as string[]; }
export function getExercisesByCategory(cat: string): Exercise[] { return exercises.filter(e => e.category === cat); }
export function getExercisesByGoal(goal: string): Exercise[] { return exercises.filter(e => e.goals.some(g => g === goal)); }
export function getExercisesByBodyArea(area: string): Exercise[] { return exercises.filter(e => e.targetAreas.some(a => a === area)); }
