import type { Exercise, Goal, Difficulty, BodyRegion } from '@/data/types';
import { filterExercises, getRelatedExercises } from './exerciseService';

export interface RecommendationResult {
  exercises: Exercise[];
  reasons: Record<string, string>;
}

export function recommendExercises(opts: {
  goal?: string; bodyArea?: string; difficulty?: string; maxDuration?: number; energy?: number; experience?: string; limit?: number;
}): RecommendationResult {
  let results = filterExercises({
    goal: opts.goal, bodyArea: opts.bodyArea, difficulty: opts.difficulty, maxDuration: opts.maxDuration,
  });
  if (results.length === 0) {
    results = filterExercises({ goal: opts.goal });
  }
  if (results.length === 0) {
    results = filterExercises({ bodyArea: opts.bodyArea });
  }
  if (results.length === 0) {
    results = filterExercises({});
  }
  const shuffled = [...results].sort(() => Math.random() - 0.5);
  const limit = opts.limit || 6;
  const selected = shuffled.slice(0, limit);
  const reasons: Record<string, string> = {};
  for (const ex of selected) {
    const parts: string[] = [];
    if (opts.goal && ex.goals.includes(opts.goal as Goal)) parts.push(`supports your goal of ${opts.goal}`);
    if (opts.bodyArea && ex.targetAreas.includes(opts.bodyArea as BodyRegion)) parts.push(`targets ${opts.bodyArea}`);
    if (opts.difficulty && ex.difficulty === opts.difficulty) parts.push(`matches your ${opts.difficulty} level`);
    if (opts.maxDuration && ex.duration <= opts.maxDuration) parts.push(`fits your time budget`);
    if (parts.length === 0) parts.push(`aligns with your preferences`);
    reasons[ex.id] = `Selected because it ${parts.join(', ')}.`;
  }
  return { exercises: selected, reasons };
}

export function generateRoutine(opts: {
  goal?: string; difficulty?: string; duration?: number; bodyArea?: string;
}): Exercise[] {
  const perSession = opts.duration && opts.duration > 20 ? 8 : 5;
  const rec = recommendExercises({ ...opts, limit: perSession });
  return rec.exercises;
}

export function generateSession(opts: {
  goal?: string; duration?: number; difficulty?: string; bodyArea?: string; energy?: number; equipment?: string; experience?: string;
}): Exercise[] {
  const numExercises = opts.duration ? Math.max(3, Math.floor(opts.duration / 3)) : 6;
  const rec = recommendExercises({ ...opts, limit: numExercises });
  return rec.exercises;
}

export function generateExerciseReview(feedback: {
  difficulty: number; bodyFeel: string; areaFelt: string; comfortable: boolean; completedFullMovement: boolean; energyBefore: number; energyAfter: number;
}): { whatYouReported: string; whatWeLearned: string; sessionReview: string; nextStep: string; recommendedNextType: string } {
  const energyChange = feedback.energyAfter - feedback.energyBefore;
  const whatYouReported = `Difficulty: ${feedback.difficulty}/5. Body felt: ${feedback.bodyFeel}. Primary area: ${feedback.areaFelt}. ${feedback.completedFullMovement ? 'Completed full movement.' : 'Did not complete full movement.'} Energy ${energyChange >= 0 ? 'increased' : 'decreased'} by ${Math.abs(energyChange)}/5.`;
  const whatWeLearned = `${feedback.comfortable ? 'The movement felt comfortable for you.' : 'The movement felt challenging.'} ${energyChange > 0 ? 'This type of practice energizes you.' : 'This practice may be more demanding for you right now.'}`;
  const sessionReview = feedback.difficulty <= 2
    ? 'This session was relatively easy. Consider progressing to more challenging variations.'
    : feedback.difficulty <= 3
    ? 'Good balanced session. This intensity level suits your current state.'
    : 'This was a demanding session. Consider more recovery before the next challenge.';
  const nextStep = feedback.difficulty <= 2
    ? 'Try an intermediate variation or increase duration.'
    : feedback.difficulty <= 3
    ? 'Continue at this level and explore related movements.'
    : 'Add a recovery session before your next intense practice.';
  const recommendedNextType = energyChange >= 0 ? 'Strength' : 'Recovery';
  return { whatYouReported, whatWeLearned, sessionReview, nextStep, recommendedNextType };
}

export function calculateWellnessScore(data: {
  movement: number; recovery: number; sleep: number; mindfulness: number; routine: number; consistency: number;
}): { overall: number; breakdown: Record<string, number>; improvements: string[]; nextAction: string } {
  const weights = { movement: 0.25, recovery: 0.15, sleep: 0.2, mindfulness: 0.15, routine: 0.1, consistency: 0.15 };
  const overall = Math.round(
    data.movement * weights.movement + data.recovery * weights.recovery + data.sleep * weights.sleep +
    data.mindfulness * weights.mindfulness + data.routine * weights.routine + data.consistency * weights.consistency
  );
  const breakdown = {
    Movement: data.movement, Recovery: data.recovery, 'Sleep Habits': data.sleep,
    Mindfulness: data.mindfulness, Routine: data.routine, Consistency: data.consistency,
  };
  const improvements: string[] = [];
  for (const [key, val] of Object.entries(breakdown)) {
    if (val < 50) improvements.push(`Focus on improving ${key} — currently ${val}/100`);
    else if (val < 75) improvements.push(`${key} is moderate — small improvements will help`);
  }
  if (improvements.length === 0) improvements.push('All areas are strong — maintain your current routine');
  const lowestArea = Object.entries(breakdown).sort((a, b) => a[1] - b[1])[0];
  const nextAction = `Prioritize ${lowestArea[0]} this week to see the biggest overall improvement.`;
  return { overall, breakdown, improvements, nextAction };
}

export function generateGoalPlan(opts: {
  goal: string; experience: string; timeAvailable: number; targetDate: string; preferences: string[]; difficulty: Difficulty;
}): { milestones: { title: string; description: string }[]; weeklyTargets: { week: number; focus: string; sessions: number }[]; recommendedExercises: string[] } {
  const milestones = [
    { title: 'Week 1-2: Foundation', description: `Build a consistent base with ${opts.timeAvailable}min sessions, ${opts.difficulty} level.` },
    { title: 'Week 3-4: Progression', description: 'Increase intensity slightly and add variety to target areas.' },
    { title: 'Week 5-8: Deepening', description: 'Deepen practice with more challenging variations and longer holds.' },
    { title: 'Week 9-12: Integration', description: 'Integrate all elements into a sustainable weekly routine.' },
  ];
  const sessionsPerWeek = opts.timeAvailable >= 30 ? 4 : 3;
  const weeklyTargets = [
    { week: 1, focus: 'Establish routine and form', sessions: sessionsPerWeek },
    { week: 2, focus: 'Build consistency', sessions: sessionsPerWeek },
    { week: 3, focus: 'Increase range of motion', sessions: sessionsPerWeek + 1 },
    { week: 4, focus: 'Add challenge', sessions: sessionsPerWeek + 1 },
  ];
  const rec = recommendExercises({ goal: opts.goal, difficulty: opts.difficulty, limit: 8 });
  const recommendedExercises = rec.exercises.map(e => e.id);
  return { milestones, weeklyTargets, recommendedExercises };
}

export function generateProgressInsights(sessions: { date: string; duration: number; category: string }[]): {
  totalSessions: number; totalMinutes: number; categories: Record<string, number>; hasData: boolean; insights: string[];
} {
  if (sessions.length === 0) {
    return { totalSessions: 0, totalMinutes: 0, categories: {}, hasData: false, insights: [] };
  }
  const totalSessions = sessions.length;
  const totalMinutes = sessions.reduce((sum, s) => sum + s.duration, 0);
  const categories: Record<string, number> = {};
  for (const s of sessions) { categories[s.category] = (categories[s.category] || 0) + 1; }
  const insights: string[] = [];
  if (totalSessions >= 3) insights.push(`You've completed ${totalSessions} sessions — great consistency building.`);
  if (totalMinutes >= 60) insights.push(`Total practice time: ${totalMinutes} minutes. Steady progress.`);
  const topCat = Object.entries(categories).sort((a, b) => b[1] - a[1])[0];
  if (topCat) insights.push(`Most frequent practice type: ${topCat[0]} (${topCat[1]} sessions). Consider diversifying.`);
  if (totalSessions < 3) insights.push('Complete a few more sessions to unlock deeper progress insights.');
  return { totalSessions, totalMinutes, categories, hasData: true, insights };
}
