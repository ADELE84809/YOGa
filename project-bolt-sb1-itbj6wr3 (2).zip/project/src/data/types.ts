export type ExerciseCategory =
  | 'Yoga'
  | 'Mobility'
  | 'Flexibility'
  | 'Strength'
  | 'Balance'
  | 'Core'
  | 'Breathing'
  | 'Meditation'
  | 'Recovery'
  | 'Posture'
  | 'Morning'
  | 'Evening'
  | 'Mindfulness'
  | 'Movement Break';

export type Difficulty = 'Beginner' | 'Intermediate' | 'Advanced';

export type MovementPhase = 'START' | 'MOVE' | 'HOLD' | 'RETURN';

export type MovementPrimitive =
  | 'Squat'
  | 'Hinge'
  | 'Lunge'
  | 'Rotation'
  | 'Flexion'
  | 'Extension'
  | 'Lateral'
  | 'ArmRaise'
  | 'ArmRotation'
  | 'Balance'
  | 'Hold'
  | 'ControlledTransition'
  | 'BreathingCycle'
  | 'Flow'
  | 'Twist'
  | 'ForwardFold'
  | 'Backbend'
  | 'HipOpener'
  | 'Inversion'
  | 'Stretch';

export type BodyRegion =
  | 'Head' | 'Neck' | 'Shoulders' | 'Arms' | 'Wrists'
  | 'Chest' | 'Upper Back' | 'Lower Back' | 'Core' | 'Hips'
  | 'Glutes' | 'Thighs' | 'Knees' | 'Calves' | 'Ankles' | 'Feet';

export type CameraAngle = 'front' | 'side' | 'back';

export type Goal =
  | 'Strength' | 'Flexibility' | 'Mobility' | 'Balance'
  | 'Relaxation' | 'Energy' | 'Focus' | 'Posture'
  | 'Recovery' | 'Core Stability' | 'Stress Relief'
  | 'Better Sleep' | 'Morning Energy' | 'Evening Wind-down';

export interface FormCue {
  cue: string;
  phase?: MovementPhase;
}

export interface AnimationStep {
  phase: MovementPhase;
  description: string;
  duration: number;
  breathing?: 'inhale' | 'exhale' | 'hold';
}

export interface Exercise {
  id: string;
  name: string;
  category: ExerciseCategory;
  subcategory: string;
  difficulty: Difficulty;
  duration: number;
  targetAreas: BodyRegion[];
  goals: Goal[];
  equipment: string[];
  instructions: string;
  steps: string[];
  breathing: string;
  benefits: string[];
  commonMistakes: string[];
  beginnerModification: string;
  advancedProgression: string;
  relatedExercises: string[];
  tags: string[];
  safetyNotes: string;
  movementPhases: MovementPhase[];
  movementType: MovementPrimitive[];
  jointsInvolved: string[];
  animationSequence: AnimationStep[];
  formCues: FormCue[];
  primitives: MovementPrimitive[];
}

export interface Course {
  id: string;
  title: string;
  subtitle: string;
  price: number;
  originalPrice?: number;
  duration: string;
  audience: string;
  description: string;
  curriculum: { title: string; duration: string; description: string }[];
  learnings: string[];
  benefits: string[];
  instructor: { name: string; bio: string };
  faqs: { q: string; a: string }[];
  isLaunchOffer?: boolean;
  savings?: number;
}

export interface UserProfile {
  goal?: Goal;
  experience?: 'Beginner' | 'Intermediate' | 'Advanced';
  preferredDuration?: number;
  daysAvailable?: number;
  preferredTime?: 'Morning' | 'Afternoon' | 'Evening';
  energy?: number;
  bodyAreas?: BodyRegion[];
  equipment?: string[];
  shortTermGoal?: string;
  longTermGoal?: string;
}

export interface SessionRecord {
  id: string;
  exerciseId: string;
  exerciseName: string;
  date: string;
  duration: number;
  difficulty: number;
  bodyFeel?: string;
  areaFelt?: string;
  completed: boolean;
  energyBefore?: number;
  energyAfter?: number;
}

export interface FeedbackRecord {
  exerciseId: string;
  difficulty: number;
  bodyFeel: string;
  areaFelt: string;
  comfortable: boolean;
  completedFullMovement: boolean;
  energyBefore: number;
  energyAfter: number;
  date: string;
}

export interface AssessmentResult {
  date: string;
  movement: number;
  energy: number;
  sleep: number;
  stress: number;
  recovery: number;
  mindfulness: number;
  routine: number;
  activity: number;
}

export interface SavedRoutine {
  id: string;
  name: string;
  exercises: { exerciseId: string; duration: number }[];
  createdAt: string;
}

export interface GoalPlan {
  id: string;
  goal: Goal;
  experience: string;
  timeAvailable: number;
  targetDate: string;
  preferences: string[];
  difficulty: Difficulty;
  milestones: { title: string; description: string }[];
  weeklyTargets: { week: number; focus: string; sessions: number }[];
  recommendedExercises: string[];
  createdAt: string;
}
