import type { Exercise, MovementPrimitive, BodyRegion, Goal, Difficulty, MovementPhase, AnimationStep, FormCue } from './types';
import { additionalExerciseGroups } from './additionalExercises';

const asanaPoses = [
  { name: 'Mountain Pose', sanskrit: 'Tadasana', areas: ['Core', 'Feet', 'Shoulders'] as BodyRegion[], primitives: ['Hold', 'Balance'] as MovementPrimitive[], goals: ['Posture', 'Focus'] as Goal[], joints: ['Ankles', 'Knees', 'Spine', 'Shoulders'] },
  { name: 'Downward Dog', sanskrit: 'Adho Mukha Svanasana', areas: ['Shoulders', 'Hamstrings' as BodyRegion, 'Calves', 'Wrists'] as BodyRegion[], primitives: ['Hold', 'Extension'] as MovementPrimitive[], goals: ['Flexibility', 'Recovery'] as Goal[], joints: ['Shoulders', 'Wrists', 'Spine', 'Hips'] },
  { name: 'Warrior I', sanskrit: 'Virabhadrasana I', areas: ['Thighs', 'Shoulders', 'Core'] as BodyRegion[], primitives: ['Lunge', 'ArmRaise'] as MovementPrimitive[], goals: ['Strength', 'Balance'] as Goal[], joints: ['Hips', 'Knees', 'Shoulders'] },
  { name: 'Warrior II', sanskrit: 'Virabhadrasana II', areas: ['Thighs', 'Shoulders', 'Hips'] as BodyRegion[], primitives: ['Lunge', 'ArmRaise'] as MovementPrimitive[], goals: ['Strength', 'Balance'] as Goal[], joints: ['Hips', 'Knees', 'Shoulders'] },
  { name: 'Warrior III', sanskrit: 'Virabhadrasana III', areas: ['Core', 'Thighs', 'Lower Back'] as BodyRegion[], primitives: ['Balance', 'Hinge'] as MovementPrimitive[], goals: ['Balance', 'Core Stability'] as Goal[], joints: ['Hips', 'Knees', 'Ankles'] },
  { name: 'Tree Pose', sanskrit: 'Vrksasana', areas: ['Feet', 'Ankles', 'Core', 'Hips'] as BodyRegion[], primitives: ['Balance', 'Hold'] as MovementPrimitive[], goals: ['Balance', 'Focus'] as Goal[], joints: ['Ankles', 'Knees', 'Hips'] },
  { name: 'Triangle Pose', sanskrit: 'Trikonasana', areas: ['Hips', 'Shoulders', 'Lower Back'] as BodyRegion[], primitives: ['Lateral', 'Stretch'] as MovementPrimitive[], goals: ['Flexibility', 'Mobility'] as Goal[], joints: ['Hips', 'Spine', 'Shoulders'] },
  { name: 'Extended Side Angle', sanskrit: 'Utthita Parsvakonasana', areas: ['Hips', 'Thighs', 'Shoulders'] as BodyRegion[], primitives: ['Lunge', 'Lateral'] as MovementPrimitive[], goals: ['Strength', 'Flexibility'] as Goal[], joints: ['Hips', 'Knees', 'Shoulders'] },
  { name: 'Half Moon Pose', sanskrit: 'Ardha Chandrasana', areas: ['Core', 'Hips', 'Ankles'] as BodyRegion[], primitives: ['Balance', 'Extension'] as MovementPrimitive[], goals: ['Balance', 'Core Stability'] as Goal[], joints: ['Hips', 'Ankles', 'Spine'] },
  { name: 'Chair Pose', sanskrit: 'Utkatasana', areas: ['Thighs', 'Glutes', 'Core'] as BodyRegion[], primitives: ['Squat', 'ArmRaise'] as MovementPrimitive[], goals: ['Strength', 'Core Stability'] as Goal[], joints: ['Knees', 'Hips', 'Shoulders'] },
  { name: 'Cobra Pose', sanskrit: 'Bhujangasana', areas: ['Lower Back', 'Chest', 'Shoulders'] as BodyRegion[], primitives: ['Backbend', 'Extension'] as MovementPrimitive[], goals: ['Flexibility', 'Posture'] as Goal[], joints: ['Spine', 'Shoulders'] },
  { name: 'Child Pose', sanskrit: 'Balasana', areas: ['Hips', 'Lower Back', 'Shoulders'] as BodyRegion[], primitives: ['ForwardFold', 'Hold'] as MovementPrimitive[], goals: ['Relaxation', 'Recovery'] as Goal[], joints: ['Hips', 'Knees', 'Spine'] },
  { name: 'Cat-Cow', sanskrit: 'Marjaryasana-Bitilasana', areas: ['Upper Back', 'Lower Back', 'Core'] as BodyRegion[], primitives: ['Flexion', 'Extension'] as MovementPrimitive[], goals: ['Mobility', 'Recovery'] as Goal[], joints: ['Spine', 'Shoulders'] },
  { name: 'Pigeon Pose', sanskrit: 'Eka Pada Rajakapotasana', areas: ['Hips', 'Glutes', 'Lower Back'] as BodyRegion[], primitives: ['HipOpener', 'Hold'] as MovementPrimitive[], goals: ['Flexibility', 'Recovery'] as Goal[], joints: ['Hips', 'Knees'] },
  { name: 'Seated Forward Bend', sanskrit: 'Paschimottanasana', areas: ['Lower Back', 'Calves', 'Shoulders'] as BodyRegion[], primitives: ['ForwardFold', 'Stretch'] as MovementPrimitive[], goals: ['Flexibility', 'Relaxation'] as Goal[], joints: ['Hips', 'Spine'] },
  { name: 'Bridge Pose', sanskrit: 'Setu Bandha Sarvangasana', areas: ['Glutes', 'Lower Back', 'Thighs'] as BodyRegion[], primitives: ['Extension', 'Hold'] as MovementPrimitive[], goals: ['Strength', 'Mobility'] as Goal[], joints: ['Hips', 'Spine', 'Knees'] },
  { name: 'Plank Pose', sanskrit: 'Phalakasana', areas: ['Core', 'Shoulders', 'Arms'] as BodyRegion[], primitives: ['Hold'] as MovementPrimitive[], goals: ['Core Stability', 'Strength'] as Goal[], joints: ['Shoulders', 'Wrists', 'Core'] },
  { name: 'Upward Dog', sanskrit: 'Urdhva Mukha Svanasana', areas: ['Chest', 'Shoulders', 'Lower Back'] as BodyRegion[], primitives: ['Backbend', 'Extension'] as MovementPrimitive[], goals: ['Flexibility', 'Posture'] as Goal[], joints: ['Spine', 'Shoulders', 'Wrists'] },
  { name: 'Standing Forward Bend', sanskrit: 'Uttanasana', areas: ['Lower Back', 'Calves', 'Neck'] as BodyRegion[], primitives: ['ForwardFold', 'Stretch'] as MovementPrimitive[], goals: ['Flexibility', 'Recovery'] as Goal[], joints: ['Hips', 'Spine'] },
  { name: 'Low Lunge', sanskrit: 'Anjaneyasana', areas: ['Hips', 'Thighs', 'Lower Back'] as BodyRegion[], primitives: ['Lunge', 'Stretch'] as MovementPrimitive[], goals: ['Flexibility', 'Mobility'] as Goal[], joints: ['Hips', 'Knees'] },
  { name: 'Boat Pose', sanskrit: 'Navasana', areas: ['Core', 'Hips', 'Lower Back'] as BodyRegion[], primitives: ['Hold', 'Balance'] as MovementPrimitive[], goals: ['Core Stability', 'Strength'] as Goal[], joints: ['Hips', 'Spine'] },
  { name: 'Camel Pose', sanskrit: 'Ustrasana', areas: ['Chest', 'Lower Back', 'Neck'] as BodyRegion[], primitives: ['Backbend', 'Extension'] as MovementPrimitive[], goals: ['Flexibility', 'Posture'] as Goal[], joints: ['Spine', 'Shoulders'] },
  { name: 'Crow Pose', sanskrit: 'Bakasana', areas: ['Wrists', 'Shoulders', 'Core'] as BodyRegion[], primitives: ['Balance', 'Hold'] as MovementPrimitive[], goals: ['Balance', 'Strength'] as Goal[], joints: ['Wrists', 'Shoulders', 'Elbows'] },
  { name: 'Headstand Prep', sanskrit: 'Sirsasana Prep', areas: ['Shoulders', 'Core', 'Neck'] as BodyRegion[], primitives: ['Inversion', 'Hold'] as MovementPrimitive[], goals: ['Strength', 'Focus'] as Goal[], joints: ['Shoulders', 'Neck', 'Spine'] },
  { name: 'Dolphin Pose', sanskrit: 'Ardha Pincha Mayurasana', areas: ['Shoulders', 'Core', 'Upper Back'] as BodyRegion[], primitives: ['Hold', 'Extension'] as MovementPrimitive[], goals: ['Strength', 'Flexibility'] as Goal[], joints: ['Shoulders', 'Spine'] },
  { name: 'Supine Twist', sanskrit: 'Supta Matsyendrasana', areas: ['Lower Back', 'Upper Back', 'Hips'] as BodyRegion[], primitives: ['Twist', 'Hold'] as MovementPrimitive[], goals: ['Mobility', 'Recovery'] as Goal[], joints: ['Spine', 'Hips'] },
  { name: 'Happy Baby', sanskrit: 'Ananda Balasana', areas: ['Hips', 'Lower Back', 'Glutes'] as BodyRegion[], primitives: ['HipOpener', 'Hold'] as MovementPrimitive[], goals: ['Flexibility', 'Relaxation'] as Goal[], joints: ['Hips', 'Knees'] },
  { name: 'Reclined Pigeon', sanskrit: 'Supta Kapotasana', areas: ['Hips', 'Glutes', 'Lower Back'] as BodyRegion[], primitives: ['HipOpener', 'Stretch'] as MovementPrimitive[], goals: ['Flexibility', 'Recovery'] as Goal[], joints: ['Hips', 'Knees'] },
  { name: 'Standing Twist', sanskrit: 'Parivrtta Trikonasana', areas: ['Spine' as BodyRegion, 'Hips', 'Shoulders'] as BodyRegion[], primitives: ['Twist', 'Lunge'] as MovementPrimitive[], goals: ['Mobility', 'Balance'] as Goal[], joints: ['Spine', 'Hips', 'Shoulders'] },
  { name: 'Wide-Legged Forward Fold', sanskrit: 'Prasarita Padottanasana', areas: ['Lower Back', 'Calves', 'Hips'] as BodyRegion[], primitives: ['ForwardFold', 'Stretch'] as MovementPrimitive[], goals: ['Flexibility', 'Recovery'] as Goal[], joints: ['Hips', 'Spine'] },
  { name: 'Garland Pose', sanskrit: 'Malasana', areas: ['Hips', 'Ankles', 'Lower Back'] as BodyRegion[], primitives: ['Squat', 'HipOpener'] as MovementPrimitive[], goals: ['Flexibility', 'Mobility'] as Goal[], joints: ['Hips', 'Ankles', 'Knees'] },
  { name: 'Locust Pose', sanskrit: 'Salabhasana', areas: ['Lower Back', 'Glutes', 'Upper Back'] as BodyRegion[], primitives: ['Extension', 'Hold'] as MovementPrimitive[], goals: ['Strength', 'Posture'] as Goal[], joints: ['Spine', 'Shoulders'] },
  { name: 'Bow Pose', sanskrit: 'Dhanurasana', areas: ['Chest', 'Lower Back', 'Thighs'] as BodyRegion[], primitives: ['Backbend', 'Hold'] as MovementPrimitive[], goals: ['Flexibility', 'Strength'] as Goal[], joints: ['Spine', 'Shoulders', 'Hips'] },
  { name: 'Gate Pose', sanskrit: 'Parighasana', areas: ['Hips', 'Lower Back', 'Shoulders'] as BodyRegion[], primitives: ['Lateral', 'Stretch'] as MovementPrimitive[], goals: ['Flexibility', 'Mobility'] as Goal[], joints: ['Hips', 'Spine', 'Shoulders'] },
  { name: 'Hero Pose', sanskrit: 'Virasana', areas: ['Knees', 'Ankles', 'Thighs'] as BodyRegion[], primitives: ['Hold', 'Stretch'] as MovementPrimitive[], goals: ['Flexibility', 'Relaxation'] as Goal[], joints: ['Knees', 'Ankles'] },
  { name: 'Staff Pose', sanskrit: 'Dandasana', areas: ['Core', 'Lower Back', 'Shoulders'] as BodyRegion[], primitives: ['Hold'] as MovementPrimitive[], goals: ['Posture', 'Core Stability'] as Goal[], joints: ['Spine', 'Hips'] },
  { name: 'Crescent Lunge', sanskrit: 'Ashta Chandrasana', areas: ['Thighs', 'Hips', 'Shoulders'] as BodyRegion[], primitives: ['Lunge', 'Balance'] as MovementPrimitive[], goals: ['Strength', 'Balance'] as Goal[], joints: ['Hips', 'Knees', 'Shoulders'] },
  { name: 'Pyramid Pose', sanskrit: 'Parsvottanasana', areas: ['Calves', 'Lower Back', 'Hips'] as BodyRegion[], primitives: ['ForwardFold', 'Stretch'] as MovementPrimitive[], goals: ['Flexibility', 'Balance'] as Goal[], joints: ['Hips', 'Spine'] },
  { name: 'Revolved Chair', sanskrit: 'Parivrtta Utkatasana', areas: ['Spine' as BodyRegion, 'Thighs', 'Core'] as BodyRegion[], primitives: ['Twist', 'Squat'] as MovementPrimitive[], goals: ['Mobility', 'Core Stability'] as Goal[], joints: ['Spine', 'Knees', 'Hips'] },
  { name: 'Side Plank', sanskrit: 'Vasisthasana', areas: ['Core', 'Shoulders', 'Wrists'] as BodyRegion[], primitives: ['Balance', 'Hold'] as MovementPrimitive[], goals: ['Core Stability', 'Strength'] as Goal[], joints: ['Shoulders', 'Wrists'] },
  { name: 'Dancer Pose', sanskrit: 'Natarajasana', areas: ['Core', 'Ankles', 'Shoulders'] as BodyRegion[], primitives: ['Balance', 'Extension'] as MovementPrimitive[], goals: ['Balance', 'Flexibility'] as Goal[], joints: ['Hips', 'Shoulders', 'Ankles'] },
  { name: 'Eagle Pose', sanskrit: 'Garudasana', areas: ['Shoulders', 'Ankles', 'Core'] as BodyRegion[], primitives: ['Balance', 'Hold'] as MovementPrimitive[], goals: ['Balance', 'Focus'] as Goal[], joints: ['Shoulders', 'Ankles', 'Hips'] },
  { name: 'Lord of the Dance', sanskrit: 'Natarajasana Advanced', areas: ['Core', 'Thighs', 'Shoulders'] as BodyRegion[], primitives: ['Balance', 'Backbend'] as MovementPrimitive[], goals: ['Balance', 'Flexibility'] as Goal[], joints: ['Hips', 'Shoulders', 'Spine'] },
  { name: 'Fish Pose', sanskrit: 'Matsyasana', areas: ['Chest', 'Neck', 'Upper Back'] as BodyRegion[], primitives: ['Backbend', 'Hold'] as MovementPrimitive[], goals: ['Flexibility', 'Posture'] as Goal[], joints: ['Spine', 'Shoulders', 'Neck'] },
  { name: 'Wind-Relieving Pose', sanskrit: 'Pavanamuktasana', areas: ['Core', 'Lower Back', 'Hips'] as BodyRegion[], primitives: ['Flexion', 'Hold'] as MovementPrimitive[], goals: ['Recovery', 'Relaxation'] as Goal[], joints: ['Hips', 'Spine'] },
  { name: 'Supine Hand-to-Foot', sanskrit: 'Supta Padangusthasana', areas: ['Calves', 'Hips', 'Lower Back'] as BodyRegion[], primitives: ['Stretch', 'Hold'] as MovementPrimitive[], goals: ['Flexibility', 'Recovery'] as Goal[], joints: ['Hips', 'Knees'] },
  { name: 'Cow Face Pose', sanskrit: 'Gomukhasana', areas: ['Shoulders', 'Hips', 'Arms'] as BodyRegion[], primitives: ['Stretch', 'Hold'] as MovementPrimitive[], goals: ['Flexibility', 'Mobility'] as Goal[], joints: ['Shoulders', 'Hips', 'Knees'] },
  { name: 'Lotus Prep', sanskrit: 'Padmasana Prep', areas: ['Hips', 'Knees', 'Ankles'] as BodyRegion[], primitives: ['HipOpener', 'Hold'] as MovementPrimitive[], goals: ['Flexibility', 'Relaxation'] as Goal[], joints: ['Hips', 'Knees', 'Ankles'] },
  { name: 'Standing Split', sanskrit: 'Urdhva Prasarita Eka Padasana', areas: ['Calves', 'Hips', 'Core'] as BodyRegion[], primitives: ['Balance', 'ForwardFold'] as MovementPrimitive[], goals: ['Flexibility', 'Balance'] as Goal[], joints: ['Hips', 'Spine'] },
  { name: 'Firelog Pose', sanskrit: 'Agnistambhasana', areas: ['Hips', 'Lower Back', 'Glutes'] as BodyRegion[], primitives: ['HipOpener', 'Hold'] as MovementPrimitive[], goals: ['Flexibility', 'Mobility'] as Goal[], joints: ['Hips', 'Knees'] },
];

const mobilityDrills = [
  { name: 'Neck Rolls', areas: ['Neck'] as BodyRegion[], primitives: ['Rotation', 'ControlledTransition'] as MovementPrimitive[], goals: ['Mobility', 'Stress Relief'] as Goal[], joints: ['Neck', 'Upper Spine'] },
  { name: 'Shoulder Circles', areas: ['Shoulders', 'Neck'] as BodyRegion[], primitives: ['ArmRotation', 'ControlledTransition'] as MovementPrimitive[], goals: ['Mobility', 'Posture'] as Goal[], joints: ['Shoulders'] },
  { name: 'Cat-Cow Flow', areas: ['Upper Back', 'Lower Back', 'Core'] as BodyRegion[], primitives: ['Flexion', 'Extension'] as MovementPrimitive[], goals: ['Mobility', 'Recovery'] as Goal[], joints: ['Spine', 'Shoulders'] },
  { name: 'Thoracic Rotations', areas: ['Upper Back', 'Shoulders'] as BodyRegion[], primitives: ['Rotation', 'Twist'] as MovementPrimitive[], goals: ['Mobility', 'Posture'] as Goal[], joints: ['Thoracic Spine', 'Shoulders'] },
  { name: 'Hip Circles', areas: ['Hips', 'Lower Back'] as BodyRegion[], primitives: ['Rotation', 'ControlledTransition'] as MovementPrimitive[], goals: ['Mobility', 'Recovery'] as Goal[], joints: ['Hips'] },
  { name: 'Ankle Circles', areas: ['Ankles', 'Feet'] as BodyRegion[], primitives: ['Rotation', 'ControlledTransition'] as MovementPrimitive[], goals: ['Mobility'] as Goal[], joints: ['Ankles'] },
  { name: 'Wrist Stretches', areas: ['Wrists', 'Arms'] as BodyRegion[], primitives: ['Stretch', 'Hold'] as MovementPrimitive[], goals: ['Mobility'] as Goal[], joints: ['Wrists'] },
  { name: 'World\'s Greatest Stretch', areas: ['Hips', 'Thoracic' as BodyRegion, 'Shoulders'] as BodyRegion[], primitives: ['Lunge', 'Rotation'] as MovementPrimitive[], goals: ['Mobility', 'Flexibility'] as Goal[], joints: ['Hips', 'Spine', 'Shoulders'] },
  { name: '90/90 Hip Switch', areas: ['Hips', 'Glutes'] as BodyRegion[], primitives: ['HipOpener', 'ControlledTransition'] as MovementPrimitive[], goals: ['Mobility', 'Flexibility'] as Goal[], joints: ['Hips', 'Knees'] },
  { name: 'Thoracic Bridge', areas: ['Upper Back', 'Shoulders', 'Core'] as BodyRegion[], primitives: ['Extension', 'Hold'] as MovementPrimitive[], goals: ['Mobility', 'Posture'] as Goal[], joints: ['Spine', 'Shoulders'] },
  { name: 'Quadruped T-Spine Rotation', areas: ['Upper Back', 'Shoulders', 'Core'] as BodyRegion[], primitives: ['Rotation', 'Hold'] as MovementPrimitive[], goals: ['Mobility', 'Posture'] as Goal[], joints: ['Thoracic Spine'] },
  { name: 'Standing Hip Rotations', areas: ['Hips', 'Ankles'] as BodyRegion[], primitives: ['Rotation', 'Balance'] as MovementPrimitive[], goals: ['Mobility'] as Goal[], joints: ['Hips', 'Ankles'] },
  { name: 'Knee Circles', areas: ['Knees', 'Ankles', 'Hips'] as BodyRegion[], primitives: ['Rotation', 'ControlledTransition'] as MovementPrimitive[], goals: ['Mobility'] as Goal[], joints: ['Knees', 'Ankles'] },
  { name: 'Spinal Wave', areas: ['Upper Back', 'Lower Back', 'Core'] as BodyRegion[], primitives: ['Flexion', 'Extension'] as MovementPrimitive[], goals: ['Mobility', 'Recovery'] as Goal[], joints: ['Spine'] },
  { name: 'Cervical Nods', areas: ['Neck', 'Upper Back'] as BodyRegion[], primitives: ['Flexion', 'Extension'] as MovementPrimitive[], goals: ['Mobility', 'Stress Relief'] as Goal[], joints: ['Neck'] },
  { name: 'Scapular Slides', areas: ['Shoulders', 'Upper Back'] as BodyRegion[], primitives: ['ArmRaise', 'ControlledTransition'] as MovementPrimitive[], goals: ['Mobility', 'Posture'] as Goal[], joints: ['Shoulders', 'Scapula'] },
  { name: 'Pendulum Legs', areas: ['Hips', 'Thighs'] as BodyRegion[], primitives: ['ControlledTransition', 'Stretch'] as MovementPrimitive[], goals: ['Mobility', 'Recovery'] as Goal[], joints: ['Hips', 'Knees'] },
  { name: 'Arm Circles', areas: ['Shoulders', 'Arms'] as BodyRegion[], primitives: ['ArmRotation', 'ControlledTransition'] as MovementPrimitive[], goals: ['Mobility', 'Energy'] as Goal[], joints: ['Shoulders'] },
  { name: 'Hip Flexor Stretch', areas: ['Hips', 'Thighs'] as BodyRegion[], primitives: ['Lunge', 'Stretch'] as MovementPrimitive[], goals: ['Flexibility', 'Mobility'] as Goal[], joints: ['Hips', 'Knees'] },
  { name: 'Pec Stretch Doorway', areas: ['Chest', 'Shoulders'] as BodyRegion[], primitives: ['Stretch', 'Hold'] as MovementPrimitive[], goals: ['Posture', 'Flexibility'] as Goal[], joints: ['Shoulders', 'Chest'] },
  { name: 'Figure-4 Stretch', areas: ['Hips', 'Glutes', 'Lower Back'] as BodyRegion[], primitives: ['HipOpener', 'Stretch'] as MovementPrimitive[], goals: ['Flexibility', 'Recovery'] as Goal[], joints: ['Hips', 'Knees'] },
  { name: 'Seated Spinal Twist', areas: ['Lower Back', 'Upper Back', 'Hips'] as BodyRegion[], primitives: ['Twist', 'Hold'] as MovementPrimitive[], goals: ['Mobility', 'Recovery'] as Goal[], joints: ['Spine', 'Hips'] },
  { name: 'Standing Side Bend', areas: ['Core', 'Lower Back', 'Shoulders'] as BodyRegion[], primitives: ['Lateral', 'Stretch'] as MovementPrimitive[], goals: ['Flexibility', 'Mobility'] as Goal[], joints: ['Spine', 'Shoulders'] },
  { name: 'Hamstring Sweep', areas: ['Calves', 'Lower Back', 'Hips'] as BodyRegion[], primitives: ['ForwardFold', 'Stretch'] as MovementPrimitive[], goals: ['Flexibility', 'Recovery'] as Goal[], joints: ['Hips', 'Knees'] },
  { name: 'Calf Wall Stretch', areas: ['Calves', 'Ankles'] as BodyRegion[], primitives: ['Stretch', 'Hold'] as MovementPrimitive[], goals: ['Flexibility', 'Recovery'] as Goal[], joints: ['Ankles', 'Calves'] },
  { name: 'Frog Stretch', areas: ['Hips', 'Glutes', 'Lower Back'] as BodyRegion[], primitives: ['HipOpener', 'Hold'] as MovementPrimitive[], goals: ['Flexibility', 'Mobility'] as Goal[], joints: ['Hips', 'Knees'] },
  { name: 'Butterfly Stretch', areas: ['Hips', 'Lower Back', 'Thighs'] as BodyRegion[], primitives: ['HipOpener', 'Stretch'] as MovementPrimitive[], goals: ['Flexibility', 'Recovery'] as Goal[], joints: ['Hips', 'Knees'] },
  { name: 'Thread the Needle', areas: ['Shoulders', 'Upper Back', 'Neck'] as BodyRegion[], primitives: ['Rotation', 'Stretch'] as MovementPrimitive[], goals: ['Mobility', 'Recovery'] as Goal[], joints: ['Shoulders', 'Spine'] },
  { name: 'Open Book Stretch', areas: ['Chest', 'Upper Back', 'Shoulders'] as BodyRegion[], primitives: ['Rotation', 'Stretch'] as MovementPrimitive[], goals: ['Mobility', 'Posture'] as Goal[], joints: ['Spine', 'Shoulders'] },
  { name: 'Dead Bug', areas: ['Core', 'Lower Back', 'Hips'] as BodyRegion[], primitives: ['ControlledTransition', 'Hold'] as MovementPrimitive[], goals: ['Core Stability', 'Mobility'] as Goal[], joints: ['Hips', 'Spine'] },
  { name: 'Bird Dog', areas: ['Core', 'Lower Back', 'Shoulders'] as BodyRegion[], primitives: ['Balance', 'Hold'] as MovementPrimitive[], goals: ['Core Stability', 'Balance'] as Goal[], joints: ['Spine', 'Shoulders', 'Hips'] },
  { name: 'Prone Cobra', areas: ['Lower Back', 'Upper Back', 'Neck'] as BodyRegion[], primitives: ['Extension', 'Hold'] as MovementPrimitive[], goals: ['Posture', 'Mobility'] as Goal[], joints: ['Spine', 'Shoulders'] },
];

const strengthMovements = [
  { name: 'Bodyweight Squat', areas: ['Thighs', 'Glutes', 'Core'] as BodyRegion[], primitives: ['Squat', 'ControlledTransition'] as MovementPrimitive[], goals: ['Strength', 'Core Stability'] as Goal[], joints: ['Knees', 'Hips', 'Ankles'] },
  { name: 'Split Squat', areas: ['Thighs', 'Glutes', 'Hips'] as BodyRegion[], primitives: ['Lunge', 'ControlledTransition'] as MovementPrimitive[], goals: ['Strength', 'Balance'] as Goal[], joints: ['Knees', 'Hips'] },
  { name: 'Glute Bridge', areas: ['Glutes', 'Lower Back', 'Thighs'] as BodyRegion[], primitives: ['Extension', 'Hold'] as MovementPrimitive[], goals: ['Strength', 'Mobility'] as Goal[], joints: ['Hips', 'Spine'] },
  { name: 'Single-Leg Glute Bridge', areas: ['Glutes', 'Thighs', 'Core'] as BodyRegion[], primitives: ['Extension', 'Balance'] as MovementPrimitive[], goals: ['Strength', 'Balance'] as Goal[], joints: ['Hips', 'Knees'] },
  { name: 'Push-up Hold', areas: ['Chest', 'Shoulders', 'Core'] as BodyRegion[], primitives: ['Hold'] as MovementPrimitive[], goals: ['Strength', 'Core Stability'] as Goal[], joints: ['Shoulders', 'Wrists', 'Elbows'] },
  { name: 'Wall Sit', areas: ['Thighs', 'Glutes'] as BodyRegion[], primitives: ['Squat', 'Hold'] as MovementPrimitive[], goals: ['Strength'] as Goal[], joints: ['Knees', 'Hips'] },
  { name: 'Calf Raises', areas: ['Calves', 'Ankles'] as BodyRegion[], primitives: ['ControlledTransition', 'Balance'] as MovementPrimitive[], goals: ['Strength', 'Balance'] as Goal[], joints: ['Ankles', 'Calves'] },
  { name: 'Reverse Lunge', areas: ['Thighs', 'Glutes', 'Hips'] as BodyRegion[], primitives: ['Lunge', 'ControlledTransition'] as MovementPrimitive[], goals: ['Strength', 'Balance'] as Goal[], joints: ['Knees', 'Hips'] },
  { name: 'Side Lunge', areas: ['Hips', 'Thighs', 'Glutes'] as BodyRegion[], primitives: ['Lateral', 'Squat'] as MovementPrimitive[], goals: ['Strength', 'Mobility'] as Goal[], joints: ['Hips', 'Knees'] },
  { name: 'Hollow Body Hold', areas: ['Core', 'Lower Back'] as BodyRegion[], primitives: ['Hold', 'Flexion'] as MovementPrimitive[], goals: ['Core Stability', 'Strength'] as Goal[], joints: ['Spine', 'Hips'] },
  { name: 'Superman Hold', areas: ['Lower Back', 'Glutes', 'Upper Back'] as BodyRegion[], primitives: ['Extension', 'Hold'] as MovementPrimitive[], goals: ['Strength', 'Posture'] as Goal[], joints: ['Spine', 'Shoulders'] },
  { name: 'Plank to Push-up', areas: ['Core', 'Chest', 'Shoulders'] as BodyRegion[], primitives: ['Hold', 'ControlledTransition'] as MovementPrimitive[], goals: ['Strength', 'Core Stability'] as Goal[], joints: ['Shoulders', 'Wrists'] },
  { name: 'Shoulder Taps', areas: ['Shoulders', 'Core', 'Wrists'] as BodyRegion[], primitives: ['Balance', 'Hold'] as MovementPrimitive[], goals: ['Core Stability', 'Balance'] as Goal[], joints: ['Shoulders', 'Wrists'] },
  { name: 'Step-up', areas: ['Thighs', 'Glutes', 'Calves'] as BodyRegion[], primitives: ['Lunge', 'ControlledTransition'] as MovementPrimitive[], goals: ['Strength', 'Balance'] as Goal[], joints: ['Knees', 'Hips', 'Ankles'] },
  { name: 'Single-Leg Deadlift', areas: ['Glutes', 'Lower Back', 'Thighs'] as BodyRegion[], primitives: ['Hinge', 'Balance'] as MovementPrimitive[], goals: ['Strength', 'Balance'] as Goal[], joints: ['Hips', 'Knees'] },
  { name: 'Bear Crawl Hold', areas: ['Core', 'Shoulders', 'Knees'] as BodyRegion[], primitives: ['Hold', 'Balance'] as MovementPrimitive[], goals: ['Core Stability', 'Strength'] as Goal[], joints: ['Shoulders', 'Hips', 'Knees'] },
  { name: 'Tricep Dip', areas: ['Arms', 'Shoulders', 'Chest'] as BodyRegion[], primitives: ['ControlledTransition', 'Hold'] as MovementPrimitive[], goals: ['Strength'] as Goal[], joints: ['Elbows', 'Shoulders'] },
  { name: 'Pike Push-up', areas: ['Shoulders', 'Arms', 'Core'] as BodyRegion[], primitives: ['ControlledTransition', 'Hold'] as MovementPrimitive[], goals: ['Strength'] as Goal[], joints: ['Shoulders', 'Wrists'] },
  { name: 'Diamond Push-up', areas: ['Chest', 'Arms', 'Shoulders'] as BodyRegion[], primitives: ['ControlledTransition', 'Hold'] as MovementPrimitive[], goals: ['Strength'] as Goal[], joints: ['Elbows', 'Shoulders'] },
  { name: 'Wide Push-up', areas: ['Chest', 'Shoulders', 'Core'] as BodyRegion[], primitives: ['ControlledTransition', 'Hold'] as MovementPrimitive[], goals: ['Strength'] as Goal[], joints: ['Shoulders', 'Wrists'] },
];

const breathingExercises = [
  { name: 'Box Breathing', areas: ['Chest'] as BodyRegion[], primitives: ['BreathingCycle', 'Hold'] as MovementPrimitive[], goals: ['Stress Relief', 'Focus'] as Goal[], joints: ['Lungs', 'Diaphragm'] },
  { name: '4-7-8 Breathing', areas: ['Chest'] as BodyRegion[], primitives: ['BreathingCycle', 'Hold'] as MovementPrimitive[], goals: ['Stress Relief', 'Better Sleep'] as Goal[], joints: ['Lungs', 'Diaphragm'] },
  { name: 'Alternate Nostril Breathing', areas: ['Head'] as BodyRegion[], primitives: ['BreathingCycle'] as MovementPrimitive[], goals: ['Focus', 'Stress Relief'] as Goal[], joints: ['Sinuses', 'Lungs'] },
  { name: 'Diaphragmatic Breathing', areas: ['Chest', 'Core'] as BodyRegion[], primitives: ['BreathingCycle'] as MovementPrimitive[], goals: ['Relaxation', 'Stress Relief'] as Goal[], joints: ['Diaphragm', 'Lungs'] },
  { name: 'Lion\'s Breath', areas: ['Neck', 'Face' as BodyRegion] as BodyRegion[], primitives: ['BreathingCycle'] as MovementPrimitive[], goals: ['Stress Relief', 'Energy'] as Goal[], joints: ['Jaw', 'Throat'] },
  { name: 'Ocean Breath', areas: ['Chest', 'Throat' as BodyRegion] as BodyRegion[], primitives: ['BreathingCycle'] as MovementPrimitive[], goals: ['Focus', 'Relaxation'] as Goal[], joints: ['Throat', 'Lungs'] },
  { name: 'Skull-Shining Breath', areas: ['Chest', 'Core'] as BodyRegion[], primitives: ['BreathingCycle', 'ControlledTransition'] as MovementPrimitive[], goals: ['Energy', 'Focus'] as Goal[], joints: ['Lungs', 'Diaphragm'] },
  { name: 'Cooling Breath', areas: ['Head'] as BodyRegion[], primitives: ['BreathingCycle'] as MovementPrimitive[], goals: ['Stress Relief', 'Better Sleep'] as Goal[], joints: ['Sinuses', 'Lungs'] },
  { name: 'Bee Breath', areas: ['Head', 'Neck'] as BodyRegion[], primitives: ['BreathingCycle', 'Hold'] as MovementPrimitive[], goals: ['Stress Relief', 'Focus'] as Goal[], joints: ['Sinuses', 'Throat'] },
  { name: 'Coherent Breathing', areas: ['Chest'] as BodyRegion[], primitives: ['BreathingCycle'] as MovementPrimitive[], goals: ['Stress Relief', 'Better Sleep'] as Goal[], joints: ['Lungs', 'Heart'] },
  { name: 'Wim Hof Style Breathing', areas: ['Chest', 'Core'] as BodyRegion[], primitives: ['BreathingCycle', 'Hold'] as MovementPrimitive[], goals: ['Energy', 'Stress Relief'] as Goal[], joints: ['Lungs', 'Diaphragm'] },
  { name: 'Pursed Lip Breathing', areas: ['Chest'] as BodyRegion[], primitives: ['BreathingCycle'] as MovementPrimitive[], goals: ['Relaxation', 'Focus'] as Goal[], joints: ['Lungs', 'Diaphragm'] },
  { name: 'Three-Part Breath', areas: ['Chest', 'Core'] as BodyRegion[], primitives: ['BreathingCycle'] as MovementPrimitive[], goals: ['Relaxation', 'Energy'] as Goal[], joints: ['Lungs', 'Diaphragm'] },
  { name: 'Breath of Fire', areas: ['Core', 'Chest'] as BodyRegion[], primitives: ['BreathingCycle', 'ControlledTransition'] as MovementPrimitive[], goals: ['Energy', 'Core Stability'] as Goal[], joints: ['Diaphragm', 'Lungs'] },
  { name: 'Sitali Breath', areas: ['Head'] as BodyRegion[], primitives: ['BreathingCycle'] as MovementPrimitive[], goals: ['Stress Relief', 'Better Sleep'] as Goal[], joints: ['Sinuses', 'Lungs'] },
];

const meditationPractices = [
  { name: 'Body Scan Meditation', areas: ['Head'] as BodyRegion[], primitives: ['Hold', 'BreathingCycle'] as MovementPrimitive[], goals: ['Stress Relief', 'Relaxation'] as Goal[], joints: ['Mind'] },
  { name: 'Mindful Breathing', areas: ['Head'] as BodyRegion[], primitives: ['BreathingCycle', 'Hold'] as MovementPrimitive[], goals: ['Focus', 'Stress Relief'] as Goal[], joints: ['Mind'] },
  { name: 'Loving-Kindness Meditation', areas: ['Head'] as BodyRegion[], primitives: ['Hold', 'BreathingCycle'] as MovementPrimitive[], goals: ['Stress Relief', 'Relaxation'] as Goal[], joints: ['Mind'] },
  { name: 'Walking Meditation', areas: ['Feet', 'Ankles'] as BodyRegion[], primitives: ['ControlledTransition', 'BreathingCycle'] as MovementPrimitive[], goals: ['Focus', 'Mindfulness' as Goal] as Goal[], joints: ['Ankles', 'Hips'] },
  { name: 'Visualization Meditation', areas: ['Head'] as BodyRegion[], primitives: ['Hold', 'BreathingCycle'] as MovementPrimitive[], goals: ['Focus', 'Stress Relief'] as Goal[], joints: ['Mind'] },
  { name: 'Mantra Meditation', areas: ['Head', 'Throat' as BodyRegion] as BodyRegion[], primitives: ['Hold', 'BreathingCycle'] as MovementPrimitive[], goals: ['Focus', 'Stress Relief'] as Goal[], joints: ['Mind', 'Throat'] },
  { name: 'Progressive Relaxation', areas: ['Head', 'Neck', 'Shoulders'] as BodyRegion[], primitives: ['Hold', 'ControlledTransition'] as MovementPrimitive[], goals: ['Relaxation', 'Better Sleep'] as Goal[], joints: ['Full Body'] },
  { name: 'Open Awareness Meditation', areas: ['Head'] as BodyRegion[], primitives: ['Hold', 'BreathingCycle'] as MovementPrimitive[], goals: ['Focus', 'Mindfulness' as Goal] as Goal[], joints: ['Mind'] },
  { name: 'Chakra Meditation', areas: ['Core', 'Chest', 'Head'] as BodyRegion[], primitives: ['Hold', 'BreathingCycle'] as MovementPrimitive[], goals: ['Relaxation', 'Focus'] as Goal[], joints: ['Mind', 'Spine'] },
  { name: 'Sound Bath Meditation', areas: ['Head'] as BodyRegion[], primitives: ['Hold', 'BreathingCycle'] as MovementPrimitive[], goals: ['Relaxation', 'Stress Relief'] as Goal[], joints: ['Mind'] },
  { name: 'Gratitude Meditation', areas: ['Head'] as BodyRegion[], primitives: ['Hold', 'BreathingCycle'] as MovementPrimitive[], goals: ['Stress Relief', 'Relaxation'] as Goal[], joints: ['Mind'] },
  { name: 'Sleep Meditation', areas: ['Head'] as BodyRegion[], primitives: ['Hold', 'BreathingCycle'] as MovementPrimitive[], goals: ['Better Sleep', 'Relaxation'] as Goal[], joints: ['Mind'] },
];

const flowSequences = [
  { name: 'Sun Salutation A', areas: ['Core', 'Shoulders', 'Thighs'] as BodyRegion[], primitives: ['Flow', 'ControlledTransition'] as MovementPrimitive[], goals: ['Energy', 'Mobility'] as Goal[], joints: ['Full Body'] },
  { name: 'Sun Salutation B', areas: ['Core', 'Shoulders', 'Thighs'] as BodyRegion[], primitives: ['Flow', 'ControlledTransition'] as MovementPrimitive[], goals: ['Energy', 'Strength'] as Goal[], joints: ['Full Body'] },
  { name: 'Moon Salutation', areas: ['Hips', 'Lower Back', 'Shoulders'] as BodyRegion[], primitives: ['Flow', 'ControlledTransition'] as MovementPrimitive[], goals: ['Relaxation', 'Flexibility'] as Goal[], joints: ['Full Body'] },
  { name: 'Vinyasa Flow', areas: ['Core', 'Shoulders', 'Hips'] as BodyRegion[], primitives: ['Flow', 'ControlledTransition'] as MovementPrimitive[], goals: ['Energy', 'Mobility'] as Goal[], joints: ['Full Body'] },
  { name: 'Standing Flow', areas: ['Thighs', 'Hips', 'Core'] as BodyRegion[], primitives: ['Flow', 'Balance'] as MovementPrimitive[], goals: ['Balance', 'Strength'] as Goal[], joints: ['Full Body'] },
  { name: 'Seated Flow', areas: ['Hips', 'Lower Back', 'Core'] as BodyRegion[], primitives: ['Flow', 'Stretch'] as MovementPrimitive[], goals: ['Flexibility', 'Relaxation'] as Goal[], joints: ['Hips', 'Spine'] },
  { name: 'Gentle Morning Flow', areas: ['Neck', 'Shoulders', 'Hips'] as BodyRegion[], primitives: ['Flow', 'ControlledTransition'] as MovementPrimitive[], goals: ['Morning Energy', 'Mobility'] as Goal[], joints: ['Full Body'] },
  { name: 'Evening Wind-Down Flow', areas: ['Lower Back', 'Hips', 'Neck'] as BodyRegion[], primitives: ['Flow', 'Stretch'] as MovementPrimitive[], goals: ['Evening Wind-down', 'Relaxation'] as Goal[], joints: ['Full Body'] },
  { name: 'Core Flow', areas: ['Core', 'Lower Back', 'Hips'] as BodyRegion[], primitives: ['Flow', 'Hold'] as MovementPrimitive[], goals: ['Core Stability', 'Strength'] as Goal[], joints: ['Spine', 'Hips'] },
  { name: 'Balance Flow', areas: ['Ankles', 'Core', 'Hips'] as BodyRegion[], primitives: ['Flow', 'Balance'] as MovementPrimitive[], goals: ['Balance', 'Focus'] as Goal[], joints: ['Ankles', 'Hips'] },
  { name: 'Hip Opening Flow', areas: ['Hips', 'Lower Back', 'Glutes'] as BodyRegion[], primitives: ['Flow', 'HipOpener'] as MovementPrimitive[], goals: ['Flexibility', 'Mobility'] as Goal[], joints: ['Hips', 'Knees'] },
  { name: 'Heart Opening Flow', areas: ['Chest', 'Shoulders', 'Upper Back'] as BodyRegion[], primitives: ['Flow', 'Backbend'] as MovementPrimitive[], goals: ['Posture', 'Flexibility'] as Goal[], joints: ['Spine', 'Shoulders'] },
  { name: 'Spinal Flow', areas: ['Upper Back', 'Lower Back', 'Core'] as BodyRegion[], primitives: ['Flow', 'Twist'] as MovementPrimitive[], goals: ['Mobility', 'Recovery'] as Goal[], joints: ['Spine'] },
  { name: 'Strength Flow', areas: ['Thighs', 'Core', 'Shoulders'] as BodyRegion[], primitives: ['Flow', 'Squat'] as MovementPrimitive[], goals: ['Strength', 'Energy'] as Goal[], joints: ['Full Body'] },
  { name: 'Restorative Flow', areas: ['Lower Back', 'Hips', 'Neck'] as BodyRegion[], primitives: ['Flow', 'Hold'] as MovementPrimitive[], goals: ['Recovery', 'Relaxation'] as Goal[], joints: ['Full Body'] },
];

const postureExercises = [
  { name: 'Chin Tucks', areas: ['Neck', 'Head'] as BodyRegion[], primitives: ['Flexion', 'Hold'] as MovementPrimitive[], goals: ['Posture'] as Goal[], joints: ['Neck', 'Cervical Spine'] },
  { name: 'Wall Angels', areas: ['Shoulders', 'Upper Back'] as BodyRegion[], primitives: ['ArmRaise', 'ControlledTransition'] as MovementPrimitive[], goals: ['Posture', 'Mobility'] as Goal[], joints: ['Shoulders', 'Spine'] },
  { name: 'Shoulder Blade Squeeze', areas: ['Upper Back', 'Shoulders'] as BodyRegion[], primitives: ['Hold', 'ControlledTransition'] as MovementPrimitive[], goals: ['Posture'] as Goal[], joints: ['Scapula', 'Shoulders'] },
  { name: 'Wall Posture Check', areas: ['Head', 'Shoulders', 'Lower Back'] as BodyRegion[], primitives: ['Hold'] as MovementPrimitive[], goals: ['Posture', 'Focus'] as Goal[], joints: ['Spine', 'Shoulders'] },
  { name: 'Doorway Stretch', areas: ['Chest', 'Shoulders'] as BodyRegion[], primitives: ['Stretch', 'Hold'] as MovementPrimitive[], goals: ['Posture', 'Flexibility'] as Goal[], joints: ['Shoulders', 'Chest'] },
  { name: 'Upper Back Extension', areas: ['Upper Back', 'Neck'] as BodyRegion[], primitives: ['Extension', 'Hold'] as MovementPrimitive[], goals: ['Posture', 'Mobility'] as Goal[], joints: ['Thoracic Spine'] },
  { name: 'Neck Retraction', areas: ['Neck', 'Head'] as BodyRegion[], primitives: ['Flexion', 'Hold'] as MovementPrimitive[], goals: ['Posture', 'Stress Relief'] as Goal[], joints: ['Neck'] },
  { name: 'Standing Alignment Check', areas: ['Head', 'Shoulders', 'Feet'] as BodyRegion[], primitives: ['Hold'] as MovementPrimitive[], goals: ['Posture', 'Focus'] as Goal[], joints: ['Spine', 'Ankles'] },
  { name: 'Prone W-Raise', areas: ['Shoulders', 'Upper Back'] as BodyRegion[], primitives: ['ArmRaise', 'Hold'] as MovementPrimitive[], goals: ['Posture', 'Strength'] as Goal[], joints: ['Shoulders', 'Scapula'] },
  { name: 'Wall Slide', areas: ['Shoulders', 'Upper Back'] as BodyRegion[], primitives: ['ArmRaise', 'ControlledTransition'] as MovementPrimitive[], goals: ['Posture', 'Mobility'] as Goal[], joints: ['Shoulders', 'Spine'] },
];

const recoveryMovements = [
  { name: 'Legs Up the Wall', areas: ['Lower Back', 'Calves'] as BodyRegion[], primitives: ['Inversion', 'Hold'] as MovementPrimitive[], goals: ['Recovery', 'Relaxation'] as Goal[], joints: ['Hips', 'Spine'] },
  { name: 'Knees to Chest', areas: ['Lower Back', 'Hips'] as BodyRegion[], primitives: ['Flexion', 'Hold'] as MovementPrimitive[], goals: ['Recovery', 'Relaxation'] as Goal[], joints: ['Hips', 'Spine'] },
  { name: 'Gentle Spinal Twist', areas: ['Lower Back', 'Upper Back'] as BodyRegion[], primitives: ['Twist', 'Hold'] as MovementPrimitive[], goals: ['Recovery', 'Mobility'] as Goal[], joints: ['Spine'] },
  { name: 'Supported Child Pose', areas: ['Hips', 'Lower Back', 'Shoulders'] as BodyRegion[], primitives: ['ForwardFold', 'Hold'] as MovementPrimitive[], goals: ['Recovery', 'Relaxation'] as Goal[], joints: ['Hips', 'Knees', 'Spine'] },
  { name: 'Supine Rest Pose', areas: ['Core', 'Lower Back'] as BodyRegion[], primitives: ['Hold', 'BreathingCycle'] as MovementPrimitive[], goals: ['Recovery', 'Relaxation'] as Goal[], joints: ['Full Body'] },
  { name: 'Gentle Hip Rock', areas: ['Hips', 'Lower Back'] as BodyRegion[], primitives: ['ControlledTransition', 'Stretch'] as MovementPrimitive[], goals: ['Recovery', 'Mobility'] as Goal[], joints: ['Hips', 'Spine'] },
  { name: 'Neck Release', areas: ['Neck', 'Shoulders'] as BodyRegion[], primitives: ['Stretch', 'Hold'] as MovementPrimitive[], goals: ['Recovery', 'Stress Relief'] as Goal[], joints: ['Neck'] },
  { name: 'Shoulder Release', areas: ['Shoulders', 'Neck'] as BodyRegion[], primitives: ['Stretch', 'ArmRotation'] as MovementPrimitive[], goals: ['Recovery', 'Stress Relief'] as Goal[], joints: ['Shoulders'] },
  { name: 'Foam Roller Spine', areas: ['Upper Back', 'Lower Back'] as BodyRegion[], primitives: ['Extension', 'Hold'] as MovementPrimitive[], goals: ['Recovery', 'Mobility'] as Goal[], joints: ['Spine'] },
  { name: 'Gentle Knee Hug', areas: ['Lower Back', 'Hips', 'Knees'] as BodyRegion[], primitives: ['Flexion', 'Hold'] as MovementPrimitive[], goals: ['Recovery', 'Relaxation'] as Goal[], joints: ['Hips', 'Knees'] },
];

const movementBreaks = [
  { name: 'Desk Shoulder Roll', areas: ['Shoulders', 'Neck'] as BodyRegion[], primitives: ['ArmRotation', 'ControlledTransition'] as MovementPrimitive[], goals: ['Stress Relief', 'Mobility'] as Goal[], joints: ['Shoulders'] },
  { name: 'Seated Spinal Twist', areas: ['Lower Back', 'Upper Back'] as BodyRegion[], primitives: ['Twist', 'Hold'] as MovementPrimitive[], goals: ['Mobility', 'Stress Relief'] as Goal[], joints: ['Spine'] },
  { name: 'Seated Forward Fold', areas: ['Lower Back', 'Neck'] as BodyRegion[], primitives: ['ForwardFold', 'Stretch'] as MovementPrimitive[], goals: ['Stress Relief', 'Recovery'] as Goal[], joints: ['Spine', 'Hips'] },
  { name: 'Standing Side Stretch', areas: ['Core', 'Shoulders'] as BodyRegion[], primitives: ['Lateral', 'Stretch'] as MovementPrimitive[], goals: ['Mobility', 'Energy'] as Goal[], joints: ['Spine', 'Shoulders'] },
  { name: 'Wrist Shake-Out', areas: ['Wrists', 'Arms'] as BodyRegion[], primitives: ['ControlledTransition'] as MovementPrimitive[], goals: ['Mobility', 'Stress Relief'] as Goal[], joints: ['Wrists'] },
  { name: 'Seated Hip Opener', areas: ['Hips', 'Lower Back'] as BodyRegion[], primitives: ['HipOpener', 'Hold'] as MovementPrimitive[], goals: ['Mobility', 'Recovery'] as Goal[], joints: ['Hips'] },
  { name: 'Eye Palming', areas: ['Head'] as BodyRegion[], primitives: ['Hold', 'BreathingCycle'] as MovementPrimitive[], goals: ['Stress Relief', 'Focus'] as Goal[], joints: ['Eyes', 'Mind'] },
  { name: 'Standing Hamstring Stretch', areas: ['Calves', 'Lower Back'] as BodyRegion[], primitives: ['Stretch', 'Hold'] as MovementPrimitive[], goals: ['Flexibility', 'Recovery'] as Goal[], joints: ['Hips', 'Knees'] },
  { name: 'Seated Cat-Cow', areas: ['Upper Back', 'Lower Back'] as BodyRegion[], primitives: ['Flexion', 'Extension'] as MovementPrimitive[], goals: ['Mobility', 'Posture'] as Goal[], joints: ['Spine'] },
  { name: 'Ankle Circles Seated', areas: ['Ankles', 'Feet'] as BodyRegion[], primitives: ['Rotation', 'ControlledTransition'] as MovementPrimitive[], goals: ['Mobility'] as Goal[], joints: ['Ankles'] },
  { name: 'Standing Quad Stretch', areas: ['Thighs', 'Hips'] as BodyRegion[], primitives: ['Stretch', 'Balance'] as MovementPrimitive[], goals: ['Flexibility', 'Mobility'] as Goal[], joints: ['Knees', 'Hips'] },
  { name: 'Seated Neck Stretch', areas: ['Neck', 'Shoulders'] as BodyRegion[], primitives: ['Stretch', 'Hold'] as MovementPrimitive[], goals: ['Stress Relief', 'Mobility'] as Goal[], joints: ['Neck'] },
  { name: 'Standing March', areas: ['Hips', 'Thighs'] as BodyRegion[], primitives: ['ControlledTransition', 'Balance'] as MovementPrimitive[], goals: ['Energy', 'Mobility'] as Goal[], joints: ['Hips', 'Knees'] },
  { name: 'Seated Pigeon', areas: ['Hips', 'Glutes'] as BodyRegion[], primitives: ['HipOpener', 'Stretch'] as MovementPrimitive[], goals: ['Mobility', 'Recovery'] as Goal[], joints: ['Hips', 'Knees'] },
  { name: 'Shoulder Shrug Release', areas: ['Shoulders', 'Neck'] as BodyRegion[], primitives: ['Hold', 'ControlledTransition'] as MovementPrimitive[], goals: ['Stress Relief', 'Mobility'] as Goal[], joints: ['Shoulders'] },
];

interface BaseExercise {
  name: string;
  sanskrit?: string;
  areas: BodyRegion[];
  primitives: MovementPrimitive[];
  goals: Goal[];
  joints: string[];
}

const exerciseGroups: { exercises: BaseExercise[]; category: Exercise['category']; subcategory: string }[] = [
  { exercises: asanaPoses, category: 'Yoga', subcategory: 'Asana' },
  { exercises: mobilityDrills, category: 'Mobility', subcategory: 'Mobility Drill' },
  { exercises: strengthMovements, category: 'Strength', subcategory: 'Bodyweight Strength' },
  { exercises: breathingExercises, category: 'Breathing', subcategory: 'Pranayama' },
  { exercises: meditationPractices, category: 'Meditation', subcategory: 'Mindfulness Practice' },
  { exercises: flowSequences, category: 'Yoga', subcategory: 'Flow Sequence' },
  { exercises: postureExercises, category: 'Posture', subcategory: 'Posture Correction' },
  { exercises: recoveryMovements, category: 'Recovery', subcategory: 'Active Recovery' },
  { exercises: movementBreaks, category: 'Movement Break', subcategory: 'Desk Break' },
  ...additionalExerciseGroups,
];

const difficulties: Difficulty[] = ['Beginner', 'Intermediate', 'Advanced'];
const durations = [60, 90, 120, 180, 240, 300, 360, 480, 600];

const instructionTemplates: Record<string, (name: string) => string> = {
  Yoga: (n) => `Begin in a comfortable starting position. Transition into ${n} with controlled movement, maintaining steady breath throughout. Focus on alignment and engage the target areas. Hold or flow as appropriate, then return to start with the same control.`,
  Mobility: (n) => `Start in a relaxed position. Perform ${n} with smooth, controlled movement. Move through the full range of motion without forcing. Breathe naturally and focus on the quality of movement rather than quantity.`,
  Strength: (n) => `Set up with proper alignment. Execute ${n} with control, focusing on muscle engagement in the target areas. Lower with control and maintain tension throughout. Keep core engaged and breathe steadily.`,
  Breathing: (n) => `Find a comfortable seated position. Relax your shoulders and jaw. Begin ${n} by following the specific breathing pattern. Focus on the sensation of breath and maintain steady rhythm throughout.`,
  Meditation: (n) => `Find a quiet space and settle into a comfortable position. Begin ${n} by following the guided instructions. When your mind wanders, gently bring attention back to the practice without judgment.`,
  Posture: (n) => `Stand or sit with awareness of your current alignment. Perform ${n} slowly and deliberately. Focus on the target muscles and maintain awareness of your posture throughout the day.`,
  Recovery: (n) => `Find a comfortable, supported position. Allow your body to fully relax into ${n}. Breathe slowly and deeply. Let gravity do the work as you release tension from the target areas.`,
  'Movement Break': (n) => `Pause your current activity. Perform ${n} slowly and mindfully. This brief movement break helps reset your posture, release tension, and restore focus. Return to your work feeling refreshed.`,
};

const breathingTemplates: Record<string, string> = {
  Yoga: 'Inhale to prepare, exhale as you move into the pose. Breathe steadily while holding. Inhale to release.',
  Mobility: 'Inhale on the opening phase, exhale on the release. Maintain natural, relaxed breathing throughout.',
  Strength: 'Exhale on exertion, inhale on the return. Never hold your breath during the movement.',
  Breathing: 'Follow the specific breathing pattern for this technique. Maintain steady, controlled breaths.',
  Meditation: 'Breathe naturally and gently. Let the breath be an anchor for your attention.',
  Posture: 'Breathe naturally while maintaining the posture. Use exhales to deepen awareness.',
  Recovery: 'Slow, deep breathing throughout. Let each exhale release more tension.',
  'Movement Break': 'Inhale deeply, exhale fully. Use the breath to enhance the release and reset.',
};

const benefitMap: Record<string, string[]> = {
  Yoga: ['Improves flexibility and strength', 'Enhances body awareness', 'Promotes mind-body connection', 'Builds focus and concentration'],
  Mobility: ['Increases range of motion', 'Reduces stiffness', 'Improves joint health', 'Enhances movement quality'],
  Strength: ['Builds functional strength', 'Improves muscle tone', 'Enhances stability', 'Supports joint health'],
  Breathing: ['Calms the nervous system', 'Improves focus and clarity', 'Reduces stress and anxiety', 'Enhances breath awareness'],
  Meditation: ['Reduces stress and anxiety', 'Improves emotional regulation', 'Enhances self-awareness', 'Promotes mental clarity'],
  Posture: ['Corrects postural imbalances', 'Reduces neck and back strain', 'Improves alignment awareness', 'Supports healthy spine'],
  Recovery: ['Promotes active recovery', 'Reduces muscle tension', 'Calms the nervous system', 'Supports rest and restoration'],
  'Movement Break': ['Releases desk-related tension', 'Restores circulation', 'Improves focus and energy', 'Counters sedentary effects'],
};

const mistakeMap: Record<string, string[]> = {
  Yoga: ['Forcing the stretch beyond comfort', 'Holding breath during transitions', 'Misaligning joints', 'Rushing through movements'],
  Mobility: ['Moving too quickly', 'Forcing range of motion', 'Holding breath', 'Skipping warm-up'],
  Strength: ['Sacrificing form for reps', 'Holding breath', 'Rushing the eccentric', 'Poor core engagement'],
  Breathing: ['Straining to hold breath', 'Tensing shoulders', 'Rushing the rhythm', 'Breathing from chest instead of belly'],
  Meditation: ['Trying to empty the mind completely', 'Judging yourself for wandering thoughts', 'Tensing the body', 'Expecting immediate results'],
  Posture: ['Forcing the position', 'Tensing instead of engaging', 'Inconsistent practice', 'Forgetting to breathe'],
  Recovery: ['Pushing into pain', 'Rushing the recovery', 'Holding tension', 'Skipping breathing'],
  'Movement Break': ['Rushing through the movement', 'Not breathing fully', 'Forcing the stretch', 'Maintaining tension'],
};

const formCueMap: Record<string, FormCue[]> = {
  Yoga: [
    { cue: 'Keep spine long and extended' },
    { cue: 'Engage core for stability', phase: 'HOLD' },
    { cue: 'Relax shoulders away from ears' },
    { cue: 'Breathe steadily throughout' },
  ],
  Mobility: [
    { cue: 'Move through full comfortable range' },
    { cue: 'Keep movement smooth and controlled' },
    { cue: 'Do not force beyond comfort' },
    { cue: 'Maintain steady breathing' },
  ],
  Strength: [
    { cue: 'Engage core throughout movement' },
    { cue: 'Maintain controlled tempo', phase: 'MOVE' },
    { cue: 'Keep joints aligned' },
    { cue: 'Breathe out on exertion' },
  ],
  Breathing: [
    { cue: 'Sit tall with relaxed shoulders' },
    { cue: 'Breathe through the nose unless specified' },
    { cue: 'Keep the belly soft and relaxed' },
    { cue: 'Maintain steady rhythm' },
  ],
  Meditation: [
    { cue: 'Find a comfortable sustainable position' },
    { cue: 'Let the breath be natural' },
    { cue: 'When mind wanders, gently return' },
    { cue: 'Relax the body progressively' },
  ],
  Posture: [
    { cue: 'Keep movements slow and deliberate' },
    { cue: 'Focus on the target muscles' },
    { cue: 'Maintain awareness throughout the day' },
    { cue: 'Do not force the position' },
  ],
  Recovery: [
    { cue: 'Allow full relaxation' },
    { cue: 'Breathe slowly and deeply' },
    { cue: 'Let gravity assist' },
    { cue: 'Release tension with each exhale' },
  ],
  'Movement Break': [
    { cue: 'Move slowly and mindfully' },
    { cue: 'Breathe fully' },
    { cue: 'Release tension with movement' },
    { cue: 'Return to work feeling refreshed' },
  ],
};

function generateAnimationSequence(primitives: MovementPrimitive[], duration: number): AnimationStep[] {
  const hasHold = primitives.includes('Hold');
  const isBreathing = primitives.includes('BreathingCycle');
  const isFlow = primitives.includes('Flow');

  if (isFlow) {
    return [
      { phase: 'START', description: 'Begin in starting position, centering breath and body', duration: 5, breathing: 'inhale' },
      { phase: 'MOVE', description: 'Flow through the sequence with controlled transitions', duration: Math.floor(duration * 0.4), breathing: 'exhale' },
      { phase: 'HOLD', description: 'Pause at key positions to find alignment and breath', duration: Math.floor(duration * 0.3), breathing: 'hold' },
      { phase: 'RETURN', description: 'Complete the flow and return to center', duration: 5, breathing: 'exhale' },
    ];
  }

  if (isBreathing) {
    return [
      { phase: 'START', description: 'Settle into position and relax the body', duration: 5, breathing: 'inhale' },
      { phase: 'MOVE', description: 'Begin the breathing pattern with full awareness', duration: Math.floor(duration * 0.3), breathing: 'inhale' },
      { phase: 'HOLD', description: 'Maintain the breathing rhythm steadily', duration: Math.floor(duration * 0.5), breathing: 'hold' },
      { phase: 'RETURN', description: 'Gently return to natural breathing', duration: 5, breathing: 'exhale' },
    ];
  }

  const holdDuration = hasHold ? Math.floor(duration * 0.4) : Math.floor(duration * 0.15);
  return [
    { phase: 'START', description: 'Set up in the starting position with proper alignment', duration: 5, breathing: 'inhale' },
    { phase: 'MOVE', description: 'Transition into the movement with control', duration: Math.floor(duration * 0.2), breathing: 'exhale' },
    { phase: 'HOLD', description: 'Hold the position, maintaining engagement and breath', duration: holdDuration, breathing: 'hold' },
    { phase: 'RETURN', description: 'Return to start with the same control', duration: 5, breathing: 'inhale' },
  ];
}

function generateSteps(name: string, category: string, primitives: MovementPrimitive[]): string[] {
  const baseSteps: Record<string, string[]> = {
    Yoga: [
      `Begin in a neutral starting position`,
      `Inhale and transition into ${name}`,
      `Find your alignment and engage the target areas`,
      `Hold the pose with steady, even breathing`,
      `Exhale and release with control`,
      `Rest and observe the effects`,
    ],
    Mobility: [
      `Start in a comfortable position`,
      `Begin ${name} with slow, controlled movement`,
      `Move through the full comfortable range of motion`,
      `Return to center with the same control`,
      `Repeat on the other side if applicable`,
      `Notice any changes in ease of movement`,
    ],
    Strength: [
      `Set up with proper alignment`,
      `Engage the core and target muscles`,
      `Execute ${name} with controlled tempo`,
      `Lower with control — do not drop`,
      `Complete the set with steady breathing`,
      `Rest and reset before the next set`,
    ],
    Breathing: [
      `Find a comfortable seated position`,
      `Relax your shoulders, jaw, and belly`,
      `Begin ${name} following the specific pattern`,
      `Maintain steady rhythm and full attention`,
      `Notice the effects on body and mind`,
      `Return to natural breathing`,
    ],
    Meditation: [
      `Settle into a comfortable position`,
      `Close your eyes or soften your gaze`,
      `Begin ${name} following the guidance`,
      `When the mind wanders, gently return`,
      `Continue with patience and kindness`,
      `Gently transition back to awareness`,
    ],
    Posture: [
      `Stand or sit with awareness`,
      `Perform ${name} slowly and deliberately`,
      `Focus on the target muscles and alignment`,
      `Hold and deepen the awareness`,
      `Release with control`,
      `Carry this awareness into your day`,
    ],
    Recovery: [
      `Find a comfortable, supported position`,
      `Allow your body to fully settle`,
      `Breathe slowly and deeply`,
      `Let gravity and time do the work`,
      `Release tension with each exhale`,
      `Transition gently when ready`,
    ],
    'Movement Break': [
      `Pause your current activity`,
      `Stand or sit tall`,
      `Perform ${name} slowly and mindfully`,
      `Breathe fully throughout`,
      `Notice the release of tension`,
      `Return to your work refreshed`,
    ],
  };

  return baseSteps[category] || baseSteps['Yoga'];
}

function slugify(name: string): string {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

function generateExercises(): Exercise[] {
  const exercises: Exercise[] = [];
  const usedIds = new Set<string>();

  for (const group of exerciseGroups) {
    for (const base of group.exercises) {
      const difficultyIdx = Math.floor(Math.random() * 3);
      const difficulty = difficulties[difficultyIdx];
      const duration = durations[Math.floor(Math.random() * durations.length)];

      let baseId = slugify(base.name);
      if (usedIds.has(baseId)) baseId = `${baseId}-${group.category.toLowerCase()}`;
      if (usedIds.has(baseId)) baseId = `${baseId}-2`;
      usedIds.add(baseId);

      const category = group.category;
      const instructions = instructionTemplates[category]?.(base.name) || instructionTemplates['Yoga'](base.name);
      const breathing = breathingTemplates[category] || breathingTemplates['Yoga'];
      const benefits = benefitMap[category] || benefitMap['Yoga'];
      const mistakes = mistakeMap[category] || mistakeMap['Yoga'];
      const formCues = formCueMap[category] || formCueMap['Yoga'];
      const animationSeq = generateAnimationSequence(base.primitives, duration);

      const isBreathing = base.primitives.includes('BreathingCycle');
      const isMeditation = category === 'Meditation';

      exercises.push({
        id: baseId,
        name: base.name,
        category,
        subcategory: group.subcategory,
        difficulty,
        duration,
        targetAreas: base.areas,
        goals: base.goals,
        equipment: isBreathing || isMeditation ? [] : ['None'],
        instructions,
        steps: generateSteps(base.name, category, base.primitives),
        breathing,
        benefits: Array.isArray(benefits) ? benefits : [benefits],
        commonMistakes: mistakes,
        beginnerModification: `For beginners: Reduce the range of motion, use props or support, and focus on comfort rather than depth. Take breaks as needed.`,
        advancedProgression: `For advanced practitioners: Deepen the position, increase duration, add variations or combine with other movements for greater challenge.`,
        relatedExercises: [],
        tags: [category, group.subcategory, difficulty, ...base.goals, ...base.primitives].map(t => t.toString()),
        safetyNotes: 'Stop if you feel pain. This is general wellness guidance, not medical advice. Consult a qualified professional for any concerns.',
        movementPhases: ['START', 'MOVE', 'HOLD', 'RETURN'],
        movementType: base.primitives,
        jointsInvolved: base.joints,
        animationSequence: animationSeq,
        formCues,
        primitives: base.primitives,
      });
    }
  }

  const allIds = exercises.map(e => e.id);
  for (const ex of exercises) {
    const related = allIds
      .filter(id => id !== ex.id)
      .filter(id => {
        const other = exercises.find(e => e.id === id)!;
        return (
          other.category === ex.category ||
          other.goals.some(g => ex.goals.includes(g)) ||
          other.targetAreas.some(a => ex.targetAreas.includes(a)) ||
          other.primitives.some(p => ex.primitives.includes(p))
        );
      })
      .slice(0, 6);
    ex.relatedExercises = related;
  }

  return exercises;
}

export const exercises: Exercise[] = generateExercises();
export const exerciseCount = exercises.length;
