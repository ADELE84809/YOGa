import { useState } from 'react';
import { Play, Pause, RotateCcw, Eye, Bone, Wind, ZoomIn, Camera } from 'lucide-react';
import { VirtualHuman } from './VirtualHuman';
import type { Exercise, MovementPhase, CameraAngle } from '@/data/types';

export function ExerciseViewer({ exercise }: { exercise: Exercise }) {
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState<MovementPhase>('START');
  const [speed, setSpeed] = useState(1);
  const [showSkeleton, setShowSkeleton] = useState(true);
  const [showJoints, setShowJoints] = useState(true);
  const [showBreathing, setShowBreathing] = useState(false);
  const [cameraAngle, setCameraAngle] = useState<CameraAngle>('front');
  const [compareMode, setCompareMode] = useState(false);

  const phases: MovementPhase[] = ['START', 'MOVE', 'HOLD', 'RETURN'];

  const togglePlay = () => {
    if (!playing) {
      setPlaying(true);
      let p = progress;
      const interval = setInterval(() => {
        p += speed * 2;
        if (p >= 100) { p = 0; setPlaying(false); clearInterval(interval); }
        setProgress(p);
        if (p < 25) setPhase('START');
        else if (p < 50) setPhase('MOVE');
        else if (p < 75) setPhase('HOLD');
        else setPhase('RETURN');
      }, 50);
    } else { setPlaying(false); }
  };

  const replay = () => { setProgress(0); setPhase('START'); setPlaying(false); };
  const onPhaseClick = (p: MovementPhase) => { setPhase(p); setProgress(phases.indexOf(p) * 25 + 12); setPlaying(false); };

  return (
    <div className="glass rounded-2xl overflow-hidden">
      <div className="relative aspect-[4/3] sm:aspect-video bg-ink-950">
        <VirtualHuman
          exerciseName={exercise.name}
          primitives={exercise.primitives}
          activePhase={phase}
          showSkeleton={showSkeleton}
          showJoints={showJoints}
          showBreathing={showBreathing}
          cameraAngle={cameraAngle}
          playing={playing}
          speed={speed}
          progress={progress}
          highlightedAreas={exercise.targetAreas}
        />
        {compareMode && (
          <div className="absolute inset-0 grid grid-cols-2 gap-px bg-white/5">
            <div className="relative">
              <div className="absolute top-2 left-2 badge-sage text-[10px]">CORRECT</div>
              <VirtualHuman exerciseName="Correct Form" primitives={exercise.primitives} activePhase={phase} progress={progress} playing={playing} speed={speed} cameraAngle={cameraAngle} showSkeleton={showSkeleton} showJoints={showJoints} highlightedAreas={exercise.targetAreas} />
            </div>
            <div className="relative">
              <div className="absolute top-2 left-2 badge border-red-500/30 bg-red-500/10 text-red-400 text-[10px]">COMMON MISTAKE</div>
              <VirtualHuman exerciseName="Common Mistake" primitives={exercise.primitives} activePhase={phase} progress={progress} playing={playing} speed={speed} cameraAngle={cameraAngle} showSkeleton={showSkeleton} showJoints={showJoints} />
            </div>
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="p-4 space-y-3">
        <div className="flex items-center gap-2 flex-wrap">
          <button onClick={togglePlay} className="p-2.5 rounded-lg glass-card text-white hover:text-violet-soft">
            {playing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </button>
          <button onClick={replay} className="p-2.5 rounded-lg glass-card text-white hover:text-violet-soft">
            <RotateCcw className="w-4 h-4" />
          </button>
          <button onClick={() => setSpeed(speed === 1 ? 0.5 : 1)} className="px-3 py-2.5 rounded-lg glass-card text-white text-xs font-mono">
            {speed === 1 ? '🐢 0.5x' : '⚡ 1x'}
          </button>
          <div className="flex-1" />
          <button onClick={() => setCompareMode(!compareMode)} className={`px-3 py-2 rounded-lg text-xs font-medium transition-colors ${compareMode ? 'bg-violet-glow/20 text-violet-soft' : 'glass-card text-white/60'}`}>
            Compare
          </button>
        </div>

        {/* Timeline */}
        <div>
          <input type="range" min={0} max={100} value={progress} onChange={e => { setProgress(Number(e.target.value)); setPlaying(false); const p = Number(e.target.value); if (p < 25) setPhase('START'); else if (p < 50) setPhase('MOVE'); else if (p < 75) setPhase('HOLD'); else setPhase('RETURN'); }} className="w-full accent-violet-glow" />
        </div>

        {/* Phase buttons */}
        <div className="flex gap-1">
          {phases.map(p => (
            <button key={p} onClick={() => onPhaseClick(p)} className={`flex-1 py-2 rounded-lg text-xs font-medium transition-colors ${phase === p ? 'bg-violet-glow/20 text-violet-soft border border-violet-glow/30' : 'glass-card text-white/40'}`}>
              {p}
            </button>
          ))}
        </div>

        {/* Toggles */}
        <div className="flex items-center gap-2 flex-wrap text-xs">
          <button onClick={() => setShowSkeleton(!showSkeleton)} className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors ${showSkeleton ? 'bg-cyan-glow/10 text-cyan-soft' : 'glass-card text-white/40'}`}>
            <Bone className="w-3.5 h-3.5" /> Skeleton
          </button>
          <button onClick={() => setShowJoints(!showJoints)} className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors ${showJoints ? 'bg-cyan-glow/10 text-cyan-soft' : 'glass-card text-white/40'}`}>
            <Eye className="w-3.5 h-3.5" /> Joints
          </button>
          <button onClick={() => setShowBreathing(!showBreathing)} className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors ${showBreathing ? 'bg-cyan-glow/10 text-cyan-soft' : 'glass-card text-white/40'}`}>
            <Wind className="w-3.5 h-3.5" /> Breathing
          </button>
        </div>

        {/* Camera angles */}
        <div className="flex items-center gap-2 text-xs">
          <Camera className="w-3.5 h-3.5 text-white/30" />
          {(['front', 'side', 'back'] as CameraAngle[]).map(a => (
            <button key={a} onClick={() => setCameraAngle(a)} className={`px-3 py-1.5 rounded-lg capitalize transition-colors ${cameraAngle === a ? 'bg-violet-glow/20 text-violet-soft' : 'glass-card text-white/40'}`}>
              {a}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
