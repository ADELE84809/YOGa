import { Sparkles, AlertTriangle } from 'lucide-react';

export function Disclaimer() {
  return (
    <div className="glass p-4 border-clay-300/40">
      <div className="flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 text-clay-500 flex-shrink-0 mt-0.5" />
        <p className="text-sm text-ink-500 leading-relaxed">
          GlobalYogaCourse provides educational and general wellness information. It is not a substitute for professional medical advice, diagnosis, or treatment. If you experience pain, dizziness, or discomfort, stop the activity and consult a qualified professional.
        </p>
      </div>
    </div>
  );
}

export function DemoModeBadge() {
  return (
    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-sage-50 border border-sage-300 text-sage-700 text-xs font-medium">
      <Sparkles className="w-3.5 h-3.5" /> Demo Intelligence Mode
    </div>
  );
}

export function PageHeader({ title, subtitle, badge }: { title: string; subtitle?: string; badge?: string }) {
  return (
    <div className="pt-20 pb-8">
      <div className="section-padding">
        {badge && <div className="mb-4"><span className="badge-sage">{badge}</span></div>}
        <h1 className="font-display text-4xl sm:text-5xl font-bold text-ink-800 text-balance">{title}</h1>
        {subtitle && <p className="text-ink-500 text-lg mt-3 max-w-2xl text-balance">{subtitle}</p>}
      </div>
    </div>
  );
}

export function EmptyState({ title, message }: { title: string; message: string }) {
  return (
    <div className="glass p-8 text-center">
      <p className="font-display text-lg text-ink-500 mb-2">{title}</p>
      <p className="text-sm text-ink-400">{message}</p>
    </div>
  );
}
