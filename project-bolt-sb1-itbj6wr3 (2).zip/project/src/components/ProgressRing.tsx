interface Props { value: number; max?: number; label?: string; size?: number; }

export function ProgressRing({ value, max = 100, label, size = 120 }: Props) {
  const pct = Math.min(value / max, 1);
  const r = 45;
  const circ = 2 * Math.PI * r;
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
        <circle cx="50" cy="50" r={r} fill="none" stroke="rgba(94, 139, 94, 0.1)" strokeWidth="4" />
        <circle cx="50" cy="50" r={r} fill="none" stroke="url(#ringGrad)" strokeWidth="4" strokeLinecap="round"
          strokeDasharray={circ} strokeDashoffset={circ * (1 - pct)} />
        <defs>
          <linearGradient id="ringGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#5e8b5e" /><stop offset="100%" stopColor="#4d94a8" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-display text-2xl font-bold text-ink-800">{Math.round(value)}</span>
        {label && <span className="text-xs text-ink-400">{label}</span>}
      </div>
    </div>
  );
}
