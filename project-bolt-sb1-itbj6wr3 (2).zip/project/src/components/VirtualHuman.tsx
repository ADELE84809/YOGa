import { useEffect, useRef, useState } from 'react';
import type { MovementPhase, CameraAngle } from '@/data/types';

interface Props {
  exerciseName?: string;
  primitives?: string[];
  activePhase?: MovementPhase;
  showSkeleton?: boolean;
  showJoints?: boolean;
  showBreathing?: boolean;
  cameraAngle?: CameraAngle;
  playing?: boolean;
  speed?: number;
  progress?: number;
  highlightedAreas?: string[];
}

export function VirtualHuman({
  exerciseName = 'Movement', primitives = ['Hold'],
  activePhase = 'START', showSkeleton = true, showJoints = true,
  showBreathing = false, cameraAngle = 'front',
  playing = false, speed = 1, progress = 0, highlightedAreas = [],
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);
  const [breathPhase, setBreathPhase] = useState(0);
  const [mousePos, setMousePos] = useState({ x: 0.5, y: 0.5 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let frame = 0;
    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * window.devicePixelRatio;
      canvas.height = rect.height * window.devicePixelRatio;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    };
    resize();
    window.addEventListener('resize', resize);

    const draw = () => {
      const w = canvas.width / window.devicePixelRatio;
      const h = canvas.height / window.devicePixelRatio;
      ctx.clearRect(0, 0, w, h);

      const cx = w / 2;
      const cy = h / 2;
      const t = frame * 0.02 * speed;
      const phaseProgress = progress / 100;

      // Determine movement offset based on primitives and phase
      const isSquat = primitives.includes('Squat');
      const isLunge = primitives.includes('Lunge');
      const isForwardFold = primitives.includes('ForwardFold');
      const isBackbend = primitives.includes('Backbend');
      const isTwist = primitives.includes('Twist');
      const isBalance = primitives.includes('Balance');
      const isArmRaise = primitives.includes('ArmRaise');
      const isLateral = primitives.includes('Lateral');
      const isHipOpener = primitives.includes('HipOpener');
      const isFlow = primitives.includes('Flow');
      const isBreathing = primitives.includes('BreathingCycle');
      const isExtension = primitives.includes('Extension');
      const isRotation = primitives.includes('Rotation');

      // Movement amplitude based on phase
      let amp = 0;
      if (activePhase === 'START') amp = 0;
      else if (activePhase === 'MOVE') amp = 0.3 + phaseProgress * 0.4;
      else if (activePhase === 'HOLD') amp = 0.7;
      else if (activePhase === 'RETURN') amp = 0.7 - phaseProgress * 0.7;

      if (playing) {
        amp = 0.3 + Math.sin(t) * 0.4;
      }

      // Breathing scale
      const breathScale = showBreathing ? 1 + Math.sin(breathPhase) * 0.05 : 1;

      // Skeleton points (relative to center)
      const scale = Math.min(w, h) * 0.35;
      const headR = scale * 0.08;

      // Base body points
      let headY = cy - scale * 0.8;
      let shoulderY = cy - scale * 0.55;
      let hipY = cy + scale * 0.1;
      let kneeY = cy + scale * 0.45;
      let ankleY = cy + scale * 0.75;
      let armAngle = 0.15;
      let torsoAngle = 0;
      let hipAngle = 0;
      let kneeBend = 0;
      let headTilt = 0;

      // Apply movements
      if (isSquat) {
        kneeBend = amp * scale * 0.15;
        hipY += kneeBend;
        kneeY -= kneeBend * 0.3;
        headY += kneeBend;
        shoulderY += kneeBend;
      }
      if (isLunge) {
        kneeBend = amp * scale * 0.1;
        hipY += kneeBend * 0.5;
        headY += kneeBend * 0.5;
        shoulderY += kneeBend * 0.5;
      }
      if (isForwardFold) {
        torsoAngle = amp * 0.8;
        headY += amp * scale * 0.3;
        hipY -= amp * scale * 0.05;
      }
      if (isBackbend || isExtension) {
        torsoAngle = -amp * 0.3;
        headTilt = -amp * 0.2;
      }
      if (isTwist || isRotation) {
        torsoAngle = Math.sin(t * 0.5) * amp * 0.3;
      }
      if (isArmRaise) {
        armAngle = 0.15 + amp * 1.2;
      }
      if (isLateral) {
        torsoAngle = amp * 0.3;
      }
      if (isBalance) {
        ankleY -= Math.sin(t * 0.3) * scale * 0.02;
      }
      if (isHipOpener) {
        hipAngle = amp * 0.3;
      }
      if (isFlow) {
        amp = Math.sin(t) * 0.5;
        torsoAngle = Math.sin(t * 0.5) * 0.2;
        armAngle = 0.15 + (Math.sin(t * 0.7) + 1) * 0.5;
      }
      if (isBreathing) {
        amp = 0.1;
      }

      // Mouse interaction - subtle lean
      const mouseInfluence = (mousePos.x - 0.5) * 0.1;
      torsoAngle += mouseInfluence;

      // Camera angle offset
      const camOffset = cameraAngle === 'side' ? w * 0.1 : cameraAngle === 'back' ? 0 : 0;
      const camScale = cameraAngle === 'side' ? 0.85 : 1;

      const px = (x: number) => cx + camOffset + x * camScale;
      const py = (y: number) => y * breathScale;

      // Glow background
      const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, scale * 1.5);
      grad.addColorStop(0, 'rgba(124, 58, 237, 0.08)');
      grad.addColorStop(0.5, 'rgba(6, 182, 212, 0.04)');
      grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      // Particle field
      ctx.save();
      for (let i = 0; i < 30; i++) {
        const px2 = cx + Math.cos(t * 0.3 + i) * scale * (1 + Math.sin(i) * 0.3);
        const py2 = cy + Math.sin(t * 0.4 + i * 1.3) * scale * (1.2 + Math.cos(i) * 0.2);
        const alpha = 0.1 + Math.sin(t + i) * 0.05;
        ctx.fillStyle = `rgba(167, 139, 250, ${alpha})`;
        ctx.beginPath();
        ctx.arc(px2, py2, 1.5, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      // Helper to draw a line
      const drawLine = (x1: number, y1: number, x2: number, y2: number, color: string, width: number = 2) => {
        ctx.strokeStyle = color;
        ctx.lineWidth = width;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(px(x1), py(y1));
        ctx.lineTo(px(x2), py(y2));
        ctx.stroke();
      };

      const drawJoint = (x: number, y: number, r: number, color: string, glow: boolean = false) => {
        if (glow) {
          ctx.shadowBlur = 10;
          ctx.shadowColor = color;
        }
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(px(x), py(y), r, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      };

      // Calculate body points with movement
      const shoulderL = -scale * 0.25;
      const shoulderR = scale * 0.25;
      const hipL = -scale * 0.18 + hipAngle * scale * 0.1;
      const hipR = scale * 0.18 + hipAngle * scale * 0.1;
      const elbowL = shoulderL - Math.sin(armAngle) * scale * 0.2;
      const elbowR = shoulderR + Math.sin(armAngle) * scale * 0.2;
      const wristL = elbowL - Math.sin(armAngle + 0.3) * scale * 0.15;
      const wristR = elbowR + Math.sin(armAngle + 0.3) * scale * 0.15;
      const elbowY2 = shoulderY + Math.cos(armAngle) * scale * 0.15;
      const wristY2 = shoulderY + Math.cos(armAngle + 0.3) * scale * 0.15;
      const kneeL = hipL - scale * 0.05;
      const kneeR = hipR + scale * 0.05;
      const ankleL = kneeL;
      const ankleR = kneeR;

      // Apply torso rotation
      const torsoTopX = Math.sin(torsoAngle) * scale * 0.1;
      const torsoTopY = shoulderY - Math.cos(torsoAngle) * scale * 0.05;
      const headX = torsoTopX + Math.sin(torsoAngle + headTilt) * scale * 0.15;
      const headY2 = torsoTopY - Math.cos(torsoAngle + headTilt) * scale * 0.2;

      const jointColor = '#22d3ee';
      const boneColor = 'rgba(167, 139, 250, 0.6)';
      const activeColor = '#a78bfa';
      const boneWidth = showSkeleton ? 2.5 : 1.5;
      const jointR = showJoints ? 4 : 2;

      // Draw skeleton
      // Spine
      drawLine(torsoTopX, torsoTopY, 0, hipY, boneColor, boneWidth);
      // Shoulders
      drawLine(torsoTopX, torsoTopY, shoulderL, shoulderY, boneColor, boneWidth);
      drawLine(torsoTopX, torsoTopY, shoulderR, shoulderY, boneColor, boneWidth);
      // Arms
      drawLine(shoulderL, shoulderY, elbowL, elbowY2, boneColor, boneWidth);
      drawLine(shoulderR, shoulderY, elbowR, elbowY2, boneColor, boneWidth);
      drawLine(elbowL, elbowY2, wristL, wristY2, boneColor, boneWidth);
      drawLine(elbowR, elbowY2, wristR, wristY2, boneColor, boneWidth);
      // Hips
      drawLine(0, hipY, hipL, hipY, boneColor, boneWidth);
      drawLine(0, hipY, hipR, hipY, boneColor, boneWidth);
      // Legs
      drawLine(hipL, hipY, kneeL, kneeY, boneColor, boneWidth);
      drawLine(hipR, hipY, kneeR, kneeY, boneColor, boneWidth);
      drawLine(kneeL, kneeY, ankleL, ankleY, boneColor, boneWidth);
      drawLine(kneeR, kneeY, ankleR, ankleY, boneColor, boneWidth);

      // Head
      ctx.strokeStyle = boneColor;
      ctx.lineWidth = boneWidth;
      ctx.beginPath();
      ctx.arc(px(headX), py(headY2), headR, 0, Math.PI * 2);
      ctx.stroke();

      // Joints
      if (showJoints) {
        drawJoint(torsoTopX, torsoTopY, jointR, jointColor, true);
        drawJoint(shoulderL, shoulderY, jointR, jointColor, true);
        drawJoint(shoulderR, shoulderY, jointR, jointColor, true);
        drawJoint(elbowL, elbowY2, jointR * 0.8, jointColor);
        drawJoint(elbowR, elbowY2, jointR * 0.8, jointColor);
        drawJoint(wristL, wristY2, jointR * 0.7, jointColor);
        drawJoint(wristR, wristY2, jointR * 0.7, jointColor);
        drawJoint(0, hipY, jointR, jointColor, true);
        drawJoint(hipL, hipY, jointR * 0.8, jointColor);
        drawJoint(hipR, hipY, jointR * 0.8, jointColor);
        drawJoint(kneeL, kneeY, jointR * 0.8, jointColor);
        drawJoint(kneeR, kneeY, jointR * 0.8, jointColor);
        drawJoint(ankleL, ankleY, jointR * 0.7, jointColor);
        drawJoint(ankleR, ankleY, jointR * 0.7, jointColor);
      }

      // Highlighted areas
      if (highlightedAreas.length > 0) {
        const areaMap: Record<string, [number, number]> = {
          'Head': [headX, headY2], 'Neck': [torsoTopX, torsoTopY],
          'Shoulders': [shoulderR, shoulderY], 'Arms': [elbowR, elbowY2],
          'Wrists': [wristR, wristY2], 'Chest': [0, (torsoTopY + hipY) / 2],
          'Upper Back': [0, torsoTopY + scale * 0.05], 'Lower Back': [0, hipY - scale * 0.05],
          'Core': [0, (torsoTopY + hipY) / 2 + scale * 0.1], 'Hips': [hipR, hipY],
          'Glutes': [0, hipY + scale * 0.05], 'Thighs': [kneeR, (hipY + kneeY) / 2],
          'Knees': [kneeR, kneeY], 'Calves': [ankleR, (kneeY + ankleY) / 2],
          'Ankles': [ankleR, ankleY], 'Feet': [ankleR, ankleY + scale * 0.03],
        };
        for (const area of highlightedAreas) {
          const pos = areaMap[area];
          if (pos) {
            ctx.save();
            ctx.shadowBlur = 20;
            ctx.shadowColor = activeColor;
            ctx.fillStyle = 'rgba(167, 139, 250, 0.15)';
            ctx.beginPath();
            ctx.arc(px(pos[0]), py(pos[1]), 15, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
          }
        }
      }

      // Movement trajectory
      if (playing || activePhase !== 'START') {
        ctx.save();
        ctx.strokeStyle = 'rgba(34, 211, 238, 0.2)';
        ctx.lineWidth = 1;
        ctx.setLineDash([3, 3]);
        for (let i = 0; i < 5; i++) {
          const past = i * 0.3;
          const a = 0.3 + Math.sin(t - past) * 0.4;
          const handX = shoulderR + Math.sin(a + 0.3) * scale * 0.35;
          const handY = shoulderY + Math.cos(a + 0.3) * scale * 0.3;
          ctx.globalAlpha = 0.15 - i * 0.03;
          ctx.beginPath();
          ctx.arc(px(handX), py(handY), 3, 0, Math.PI * 2);
          ctx.stroke();
        }
        ctx.restore();
      }

      // Breathing indicator
      if (showBreathing) {
        const breathR = scale * 0.4 + Math.sin(breathPhase) * scale * 0.1;
        const breathAlpha = 0.05 + Math.sin(breathPhase) * 0.03;
        ctx.strokeStyle = `rgba(34, 211, 238, ${breathAlpha + 0.1})`;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(px(0), py((shoulderY + hipY) / 2), breathR, 0, Math.PI * 2);
        ctx.stroke();
        const inhale = Math.sin(breathPhase) > 0;
        ctx.fillStyle = inhale ? 'rgba(34, 211, 238, 0.6)' : 'rgba(167, 139, 250, 0.6)';
        ctx.font = '11px Inter, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(inhale ? 'INHALE' : 'EXHALE', px(0), py((shoulderY + hipY) / 2));
      }

      // Phase label
      ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
      ctx.font = '10px Inter, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(activePhase, px(0), h - 10);

      frame++;
      animRef.current = requestAnimationFrame(draw);
    };

    draw();
    return () => { cancelAnimationFrame(animRef.current); window.removeEventListener('resize', resize); };
  }, [activePhase, showSkeleton, showJoints, showBreathing, cameraAngle, playing, speed, progress, primitives, highlightedAreas, mousePos]);

  useEffect(() => {
    if (!showBreathing) return;
    const interval = setInterval(() => setBreathPhase(p => p + 0.05), 50);
    return () => clearInterval(interval);
  }, [showBreathing]);

  return (
    <div className="relative w-full h-full" onMouseMove={e => {
      const rect = e.currentTarget.getBoundingClientRect();
      setMousePos({ x: (e.clientX - rect.left) / rect.width, y: (e.clientY - rect.top) / rect.height });
    }}>
      <canvas ref={canvasRef} className="w-full h-full" />
      {exerciseName && (
        <div className="absolute top-3 left-3 px-3 py-1.5 rounded-lg glass text-xs text-white/60 font-mono">
          {exerciseName}
        </div>
      )}
      <div className="absolute top-3 right-3 px-2 py-1 rounded-md bg-ink-900/60 text-[10px] text-white/40 font-mono uppercase">
        {cameraAngle} view
      </div>
    </div>
  );
}
