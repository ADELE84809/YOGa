import { useState, useEffect } from 'react';

interface Props { duration?: number; pattern?: 'box' | '478' | 'coherent'; }

export function BreathingOrb({ duration = 120, pattern = 'box' }: Props) {
  const [phase, setPhase] = useState<'inhale' | 'hold1' | 'exhale' | 'hold2'>('inhale');
  const [running, setRunning] = useState(false);
  const [elapsed, setElapsed] = useState(0);

  const patterns: Record<string, { inhale: number; hold1: number; exhale: number; hold2: number }> = {
    box: { inhale: 4, hold1: 4, exhale: 4, hold2: 4 },
    '478': { inhale: 4, hold1: 7, exhale: 8, hold2: 0 },
    coherent: { inhale: 5, hold1: 0, exhale: 5, hold2: 0 },
  };
  const p = patterns[pattern];
  const cycleTime = p.inhale + p.hold1 + p.exhale + p.hold2;

  useEffect(() => {
    if (!running) return;
    const interval = setInterval(() => {
      setElapsed(e => {
        const next = e + 1;
        if (next >= duration) { setRunning(false); return 0; }
        const cyclePos = next % cycleTime;
        if (cyclePos < p.inhale) setPhase('inhale');
        else if (cyclePos < p.inhale + p.hold1) setPhase('hold1');
        else if (cyclePos < p.inhale + p.hold1 + p.exhale) setPhase('exhale');
        else setPhase('hold2');
        return next;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [running, duration, cycleTime, p.inhale, p.hold1, p.exhale]);

  const scale = phase === 'inhale' ? 1.2 : phase === 'exhale' ? 0.7 : phase === 'hold1' ? 1.2 : 0.7;
  const labels: Record<string, string> = { inhale: 'Breathe In', hold1: 'Hold', exhale: 'Breathe Out', hold2: 'Hold' };
  const colors: Record<string, string> = { inhale: '#4d94a8', hold1: '#5e8b5e', exhale: '#36748a', hold2: '#5e8b5e' };

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="relative w-48 h-48 flex items-center justify-center">
        <div className="absolute inset-0 rounded-full" style={{
          background: `radial-gradient(circle, ${colors[phase]}30, transparent 70%)`,
          transform: `scale(${scale * 1.5})`, transition: 'transform 4s ease-in-out, background 1s',
        }} />
        <div className="w-32 h-32 rounded-full border-2 flex items-center justify-center transition-all duration-1000"
          style={{ borderColor: colors[phase], transform: `scale(${scale})`, boxShadow: `0 0 30px ${colors[phase]}30` }}>
          <span className="font-display text-lg font-medium" style={{ color: colors[phase] }}>{labels[phase]}</span>
        </div>
      </div>
      {!running ? (
        <button onClick={() => setRunning(true)} className="btn-primary">Start Breathing</button>
      ) : (
        <button onClick={() => setRunning(false)} className="btn-secondary">Pause</button>
      )}
      <p className="text-ink-400 text-sm">{Math.floor(elapsed / 60)}:{(elapsed % 60).toString().padStart(2, '0')} / {Math.floor(duration / 60)}:{(duration % 60).toString().padStart(2, '0')}</p>
    </div>
  );
}
