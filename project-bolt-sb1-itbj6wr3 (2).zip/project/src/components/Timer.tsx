import { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw } from 'lucide-react';

interface Props { totalSeconds: number; onComplete?: () => void; label?: string }

export function Timer({ totalSeconds, onComplete, label }: Props) {
  const [seconds, setSeconds] = useState(totalSeconds);
  const [running, setRunning] = useState(false);

  useEffect(() => { setSeconds(totalSeconds); }, [totalSeconds]);

  useEffect(() => {
    if (!running) return;
    const interval = setInterval(() => {
      setSeconds(s => {
        if (s <= 1) { setRunning(false); onComplete?.(); return 0; }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [running, onComplete]);

  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  const progress = ((totalSeconds - seconds) / totalSeconds) * 100;

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="relative w-40 h-40">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="45" fill="none" stroke="rgba(94, 139, 94, 0.1)" strokeWidth="3" />
          <circle cx="50" cy="50" r="45" fill="none" stroke="url(#timerGrad)" strokeWidth="3" strokeLinecap="round"
            strokeDasharray={`${2 * Math.PI * 45}`} strokeDashoffset={`${2 * Math.PI * 45 * (1 - progress / 100)}`} />
          <defs>
            <linearGradient id="timerGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#5e8b5e" /><stop offset="100%" stopColor="#4d94a8" />
            </linearGradient>
          </defs>
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-display text-3xl font-bold text-ink-800">{mins}:{secs.toString().padStart(2, '0')}</span>
          {label && <span className="text-xs text-ink-400 mt-1">{label}</span>}
        </div>
      </div>
      <div className="flex items-center gap-2">
        <button onClick={() => setRunning(!running)} className="p-3 rounded-xl glass-card text-ink-600 hover:text-sage-700">
          {running ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
        </button>
        <button onClick={() => { setSeconds(totalSeconds); setRunning(false); }} className="p-3 rounded-xl glass-card text-ink-600 hover:text-sage-700">
          <RotateCcw className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
