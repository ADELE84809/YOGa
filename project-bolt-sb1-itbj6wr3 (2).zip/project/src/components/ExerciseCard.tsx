import { Link } from 'react-router-dom';
import { Clock, BarChart3 } from 'lucide-react';
import type { Exercise } from '@/data/types';

const diffColors: Record<string, string> = {
  Beginner: 'text-sage-700 border-sage-300 bg-sage-50',
  Intermediate: 'text-ocean-700 border-ocean-300 bg-ocean-50',
  Advanced: 'text-clay-600 border-clay-300 bg-clay-50',
};

export function ExerciseCard({ exercise }: { exercise: Exercise }) {
  return (
    <Link to={`/exercise/${exercise.id}`} className="glass-card p-4 group block">
      <div className="flex items-start justify-between gap-2 mb-3">
        <span className={`badge ${diffColors[exercise.difficulty] || diffColors.Beginner}`}>{exercise.difficulty}</span>
        <span className="badge-neutral">{exercise.category}</span>
      </div>
      <h3 className="font-display font-semibold text-ink-800 text-base leading-tight group-hover:text-sage-700 transition-colors">{exercise.name}</h3>
      <p className="text-ink-400 text-xs mt-1">{exercise.subcategory}</p>
      <div className="flex items-center gap-3 mt-3 text-xs text-ink-500">
        <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{Math.floor(exercise.duration / 60)}min</span>
        <span className="flex items-center gap-1"><BarChart3 className="w-3 h-3" />{exercise.goals[0]}</span>
      </div>
      <div className="flex flex-wrap gap-1 mt-2">
        {exercise.targetAreas.slice(0, 3).map(a => (
          <span key={a} className="text-[10px] text-ink-400 px-1.5 py-0.5 rounded bg-sage-50">{a}</span>
        ))}
      </div>
    </Link>
  );
}
