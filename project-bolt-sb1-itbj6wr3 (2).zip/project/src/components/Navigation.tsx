import { Link, useLocation } from 'react-router-dom';
import { useState, useEffect, useMemo } from 'react';
import { Home, BookOpen, Activity, Sparkles, LayoutDashboard, BookText, Menu, X, ChevronDown, ChevronRight, Search } from 'lucide-react';
import { getAllExercises } from '@/services/exerciseService';

const mainNav = [
  { name: 'Home', path: '/', icon: Home },
  { name: 'AI Tools', path: '/ai-tools', icon: Sparkles },
  { name: 'Exercises', path: '/exercises', icon: Activity },
  { name: 'Wellness OS', path: '/wellness-os', icon: LayoutDashboard },
  { name: 'Courses', path: '/courses', icon: BookText },
  { name: 'About', path: '/about', icon: BookOpen },
];

export function Navigation() {
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [search, setSearch] = useState('');
  const exercises = useMemo(() => getAllExercises(), []);
  const categories = useMemo(() => {
    const cats: Record<string, typeof exercises> = {};
    for (const ex of exercises) {
      if (!cats[ex.category]) cats[ex.category] = [];
      cats[ex.category].push(ex);
    }
    return cats;
  }, [exercises]);

  const filtered = useMemo(() => {
    if (!search) return null;
    const q = search.toLowerCase();
    return exercises.filter(e => e.name.toLowerCase().includes(q)).slice(0, 30);
  }, [search, exercises]);

  useEffect(() => { setSidebarOpen(false); }, [location.pathname]);

  return (
    <>
      {/* Top bar */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-cream-50/80 backdrop-blur-xl border-b border-sage-100">
        <div className="px-4 sm:px-6 flex items-center justify-between h-14">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2 text-ink-500 hover:text-sage-700 lg:hidden">
              {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            <Link to="/" className="flex items-center gap-2 group">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-sage-500 to-ocean-400 flex items-center justify-center">
                <Activity className="w-5 h-5 text-white" />
              </div>
              <span className="font-display font-semibold text-ink-800 text-lg">GlobalYogaCourse</span>
            </Link>
          </div>
          <div className="hidden lg:flex items-center gap-1">
            {mainNav.map(l => (
              <Link key={l.path} to={l.path} className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${location.pathname === l.path ? 'text-sage-700 bg-sage-50' : 'text-ink-500 hover:text-sage-700 hover:bg-sage-50'}`}>
                {l.name}
              </Link>
            ))}
          </div>
          <Link to="/ai-yoga-coach" className="btn-primary text-sm hidden sm:inline-flex">Try Free</Link>
        </div>
      </nav>

      {/* Left sidebar — exercise index */}
      <aside className={`fixed left-0 top-14 bottom-0 w-72 z-40 bg-cream-50/95 backdrop-blur-xl border-r border-sage-100 overflow-y-auto transition-transform duration-300 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="p-4">
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-400" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search exercises..." className="input-field pl-9 text-sm py-2" />
          </div>
          {filtered ? (
            <div>
              <p className="text-xs text-ink-400 mb-2">{filtered.length} results</p>
              <div className="space-y-1">
                {filtered.map(ex => (
                  <Link key={ex.id} to={`/exercise/${ex.id}`} className="block px-3 py-2 rounded-lg text-sm text-ink-600 hover:bg-sage-50 hover:text-sage-700 transition-colors">
                    {ex.name}
                  </Link>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {mainNav.map(l => (
                <Link key={l.path} to={l.path} className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${location.pathname === l.path ? 'text-sage-700 bg-sage-50' : 'text-ink-500 hover:bg-sage-50 hover:text-sage-700'}`}>
                  <l.icon className="w-4 h-4" /> {l.name}
                </Link>
              ))}
              <div className="pt-4 border-t border-sage-100">
                <p className="text-xs font-semibold text-ink-400 uppercase tracking-wider mb-2 px-3">Exercise Index</p>
                {Object.entries(categories).map(([cat, exs]) => (
                  <SidebarCategory key={cat} category={cat} exercises={exs} />
                ))}
              </div>
            </div>
          )}
        </div>
      </aside>

      {/* Mobile bottom nav */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-cream-50/90 backdrop-blur-xl border-t border-sage-100">
        <div className="flex items-center justify-around h-14">
          {[
            { name: 'Home', path: '/', icon: Home },
            { name: 'AI', path: '/ai-tools', icon: Sparkles },
            { name: 'Tools', path: '/exercises', icon: Activity },
            { name: 'Today', path: '/wellness-os', icon: LayoutDashboard },
            { name: 'Courses', path: '/courses', icon: BookText },
          ].map(item => {
            const Icon = item.icon;
            const active = location.pathname === item.path;
            return (
              <Link key={item.path} to={item.path} className={`flex flex-col items-center gap-0.5 px-3 py-1.5 transition-colors ${active ? 'text-sage-700' : 'text-ink-400'}`}>
                <Icon className="w-5 h-5" />
                <span className="text-xs font-medium">{item.name}</span>
              </Link>
            );
          })}
        </div>
      </nav>
    </>
  );
}

function SidebarCategory({ category, exercises }: { category: string; exercises: ReturnType<typeof getAllExercises> }) {
  const [open, setOpen] = useState(false);
  const display = exercises.slice(0, 15);
  return (
    <div className="mb-2">
      <button onClick={() => setOpen(!open)} className="flex items-center justify-between w-full px-3 py-2 rounded-lg text-sm font-medium text-ink-600 hover:bg-sage-50 transition-colors">
        <span>{category}</span>
        <span className="flex items-center gap-1 text-xs text-ink-400">{exercises.length}{open ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}</span>
      </button>
      {open && (
        <div className="ml-2 mt-1 space-y-0.5 max-h-60 overflow-y-auto scrollbar-hide">
          {display.map(ex => (
            <Link key={ex.id} to={`/exercise/${ex.id}`} className="block px-3 py-1.5 rounded-lg text-xs text-ink-500 hover:bg-sage-50 hover:text-sage-700 transition-colors">
              {ex.name}
            </Link>
          ))}
          {exercises.length > 15 && (
            <Link to={`/exercises?category=${category}`} className="block px-3 py-1.5 text-xs text-ocean-600 hover:text-ocean-700 font-medium">
              View all {exercises.length} →
            </Link>
          )}
        </div>
      )}
    </div>
  );
}
