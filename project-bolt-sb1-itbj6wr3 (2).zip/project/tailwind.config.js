/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        sand: {
          50: '#faf8f5', 100: '#f5f0e8', 200: '#ebe2d4', 300: '#ddcfb8',
          400: '#c9b893', 500: '#b5a072', 600: '#9a8559', 700: '#7d6a48',
        },
        sage: {
          50: '#f4f7f4', 100: '#e8efe8', 200: '#d0e0d0', 300: '#a8c5a8',
          400: '#7da67d', 500: '#5e8b5e', 600: '#4a734a', 700: '#3a5c3a',
          800: '#2d452d', 900: '#1e2f1e',
        },
        ocean: {
          50: '#f0f6f8', 100: '#d9e9ee', 200: '#b3d3dd', 300: '#7fb5c6',
          400: '#4d94a8', 500: '#36748a', 600: '#2b5c70', 700: '#234a59',
          800: '#1c3a47', 900: '#152d38',
        },
        clay: {
          50: '#faf5f2', 100: '#f2e8e1', 200: '#e5d0c2', 300: '#d4b09a',
          400: '#c08d72', 500: '#a8704f', 600: '#8a5a3e',
        },
        cream: {
          50: '#fdfcf9', 100: '#faf7f0', 200: '#f3ede0', 300: '#e8dec8',
        },
        ink: {
          50: '#f5f3f0', 100: '#e8e4de', 200: '#d4cec4', 300: '#b8b0a3',
          400: '#948c80', 500: '#736d63', 600: '#5a544c', 700: '#443f39',
          800: '#2e2a26', 850: '#242120', 900: '#1a1816', 950: '#121110',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
        display: ['Fraunces', 'Georgia', 'serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      animation: {
        'fade-in': 'fadeIn 0.6s ease-out forwards',
        'fade-up': 'fadeUp 0.6s ease-out forwards',
        'fade-down': 'fadeDown 0.6s ease-out forwards',
        'scale-in': 'scaleIn 0.4s ease-out forwards',
        'slide-right': 'slideRight 0.5s ease-out forwards',
        'breathe': 'breathe 4s ease-in-out infinite',
        'float': 'float 6s ease-in-out infinite',
        'gentle-pulse': 'gentlePulse 4s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: { '0%': { opacity: '0' }, '100%': { opacity: '1' } },
        fadeUp: { '0%': { opacity: '0', transform: 'translateY(20px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
        fadeDown: { '0%': { opacity: '0', transform: 'translateY(-20px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
        scaleIn: { '0%': { opacity: '0', transform: 'scale(0.95)' }, '100%': { opacity: '1', transform: 'scale(1)' } },
        slideRight: { '0%': { opacity: '0', transform: 'translateX(-20px)' }, '100%': { opacity: '1', transform: 'translateX(0)' } },
        breathe: { '0%, 100%': { transform: 'scale(1)' }, '50%': { transform: 'scale(1.08)' } },
        float: { '0%, 100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-8px)' } },
        gentlePulse: { '0%, 100%': { opacity: '0.5' }, '50%': { opacity: '0.8' } },
      },
    },
  },
  plugins: [],
};
