import { useParams, Link } from 'react-router-dom';
import { useState } from 'react';
import { courses } from '@/data/courses';
import { Disclaimer } from '@/components/Shared';
import { CheckCircle2, Clock, ChevronDown, ChevronUp, Lock } from 'lucide-react';

export function CoursesPage() {
  return (
    <div className="pb-20">
      <div className="pt-24 pb-8 section-padding"><h1 className="font-display text-4xl font-bold text-white">Premium Courses</h1><p className="text-white/50 mt-2">Structured wellness programs with lifetime access.</p></div>
      <div className="section-padding grid md:grid-cols-2 gap-6">
        {courses.map(c => (
          <Link key={c.id} to={`/courses/${c.id}`} className="glass-card p-6 block">
            {c.isLaunchOffer && <div className="flex items-center gap-2 mb-2"><span className="badge-violet">Launch Offer</span>{c.savings && <span className="text-xs text-white/40">Save ₹{c.savings.toLocaleString()}</span>}</div>}
            <h3 className="font-display text-xl font-bold text-white mb-2">{c.title}</h3>
            <p className="text-white/40 text-sm mb-4">{c.subtitle}</p>
            <div className="flex items-center justify-between">
              <div>{c.originalPrice && <span className="text-sm text-white/30 line-through mr-2">₹{c.originalPrice.toLocaleString()}</span>}<span className="text-2xl font-bold text-violet-soft">₹{c.price}</span></div>
              <span className="text-sm text-white/40">{c.duration} • {c.audience}</span>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}

export function CourseDetailPage() {
  const { id } = useParams();
  const course = courses.find(c => c.id === id);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [showCheckout, setShowCheckout] = useState(false);
  if (!course) return <div className="pt-24 section-padding"><p className="text-white/40">Course not found.</p><Link to="/courses" className="btn-primary mt-4 inline-block">Back to Courses</Link></div>;
  return (
    <div className="pb-20">
      <div className="pt-24 pb-8 section-padding">
        <Link to="/courses" className="text-sm text-white/40 hover:text-white mb-4 inline-block">← Back to Courses</Link>
        {course.isLaunchOffer && <div className="flex items-center gap-2 mb-3"><span className="badge-violet">Launch Offer</span>{course.savings && <span className="text-xs text-white/40">Save ₹{course.savings.toLocaleString()}</span>}</div>}
        <h1 className="font-display text-4xl font-bold text-white mb-3">{course.title}</h1>
        <p className="text-white/50 text-lg max-w-2xl">{course.subtitle}</p>
        <div className="flex items-center gap-4 mt-4 text-sm text-white/50">
          <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {course.duration}</span>
          <span>•</span><span>{course.audience}</span>
        </div>
      </div>
      <div className="section-padding grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="glass p-6"><h2 className="font-display text-xl font-bold text-white mb-3">About This Course</h2><p className="text-white/60 text-sm leading-relaxed">{course.description}</p></div>
          <div className="glass p-6"><h2 className="font-display text-xl font-bold text-white mb-4">Curriculum</h2><div className="space-y-3">{course.curriculum.map((item, i) => (
            <div key={i} className="glass-card p-4 flex items-start gap-3">
              <span className="w-8 h-8 rounded-full bg-violet-glow/20 text-violet-soft flex items-center justify-center text-sm font-mono flex-shrink-0">{i + 1}</span>
              <div className="flex-1"><div className="flex items-center justify-between"><p className="text-white font-medium text-sm">{item.title}</p><span className="text-xs text-white/40">{item.duration}</span></div><p className="text-xs text-white/50 mt-1">{item.description}</p></div>
            </div>
          ))}</div></div>
          <div className="glass p-6"><h2 className="font-display text-xl font-bold text-white mb-3">What You'll Learn</h2><ul className="space-y-2">{course.learnings.map(l => <li key={l} className="text-sm text-white/60 flex items-start gap-2"><CheckCircle2 className="w-4 h-4 text-sage-soft flex-shrink-0 mt-0.5" />{l}</li>)}</ul></div>
          <div className="glass p-6"><h2 className="font-display text-xl font-bold text-white mb-3">Course Benefits</h2><ul className="space-y-2">{course.benefits.map(b => <li key={b} className="text-sm text-white/60 flex items-start gap-2"><span className="text-violet-soft">+</span>{b}</li>)}</ul></div>
          <div className="glass p-6"><h2 className="font-display text-xl font-bold text-white mb-3">Instructor</h2><p className="text-white font-medium">{course.instructor.name}</p><p className="text-sm text-white/50 mt-1">{course.instructor.bio}</p></div>
          <div className="glass p-6"><h2 className="font-display text-xl font-bold text-white mb-4">FAQs</h2><div className="space-y-2">{course.faqs.map((faq, i) => (
            <div key={i} className="glass-card p-4">
              <button onClick={() => setOpenFaq(openFaq === i ? null : i)} className="flex items-center justify-between w-full text-left">
                <span className="text-sm text-white font-medium">{faq.q}</span>{openFaq === i ? <ChevronUp className="w-4 h-4 text-white/40" /> : <ChevronDown className="w-4 h-4 text-white/40" />}</button>
              {openFaq === i && <p className="text-sm text-white/50 mt-2">{faq.a}</p>}
            </div>
          ))}</div></div>
        </div>
        <div className="lg:sticky lg:top-20 h-fit space-y-4">
          <div className="glass p-6">
            <div className="mb-4">{course.originalPrice && <span className="text-sm text-white/30 line-through mr-2">₹{course.originalPrice.toLocaleString()}</span>}<span className="text-3xl font-bold text-violet-soft">₹{course.price}</span></div>
            <button onClick={() => setShowCheckout(true)} className="btn-primary w-full mb-3">Enroll Now</button>
            <p className="text-xs text-white/40 text-center">Lifetime access • Self-paced</p>
          </div>
          <Disclaimer />
        </div>
      </div>
      {showCheckout && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setShowCheckout(false)}>
          <div className="glass-strong p-6 max-w-md w-full" onClick={e => e.stopPropagation()}>
            <h3 className="font-display text-xl font-bold text-white mb-4">Checkout — {course.title}</h3>
            <div className="glass-card p-4 mb-4"><div className="flex items-center justify-between"><span className="text-white/60 text-sm">Course Price</span><span className="text-white font-bold">₹{course.price}</span></div></div>
            <div className="glass-card p-4 mb-4">
              <p className="text-sm text-white/60 mb-2">Pay via UPI:</p>
              <p className="font-mono text-violet-soft text-lg">9649916386@ybl</p>
              <p className="text-xs text-white/40 mt-2">This is a prototype payment instruction. For production, a secure payment gateway with server-side verification will be used. Do not send payment and claim access — payment status must be verified server-side.</p>
            </div>
            <div className="flex items-center gap-2 text-xs text-white/40 mb-4"><Lock className="w-3 h-3" /> Your payment is processed securely through UPI.</div>
            <button onClick={() => setShowCheckout(false)} className="btn-secondary w-full">Close</button>
          </div>
        </div>
      )}
    </div>
  );
}
