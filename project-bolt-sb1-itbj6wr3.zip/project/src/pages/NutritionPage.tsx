import { PageHeader, Disclaimer } from '@/components/Shared';
import { Droplets, Apple, Wheat, Salad, Citrus, Utensils, Moon, Coffee } from 'lucide-react';

const topics = [
  { icon: Droplets, title: 'Hydration', desc: 'Aim for adequate water intake throughout the day. Listen to thirst cues. Herbal teas and water-rich foods count toward hydration.' },
  { icon: Utensils, title: 'Balanced Meals', desc: 'Include protein, complex carbohydrates, healthy fats, and vegetables in main meals for sustained energy.' },
  { icon: Apple, title: 'Protein', desc: 'Protein supports muscle repair and satiety. Include legumes, dairy, eggs, or plant-based protein sources regularly.' },
  { icon: Wheat, title: 'Fiber', desc: 'Whole grains, legumes, vegetables, and fruits provide fiber for digestive health and steady energy.' },
  { icon: Citrus, title: 'Fruits & Vegetables', desc: 'Aim for variety and color. Different colors provide different phytonutrients that support overall wellness.' },
  { icon: Salad, title: 'Meal Structure', desc: 'A simple plate: half vegetables, quarter protein, quarter complex carbs, plus a small amount of healthy fat.' },
  { icon: Coffee, title: 'Pre-Exercise', desc: 'Light, easily digestible snack 30-60 min before practice. A banana or toast with nut butter works well.' },
  { icon: Moon, title: 'Post-Exercise', desc: 'Replenish with protein and carbs within 1-2 hours after intense sessions to support recovery.' },
  { icon: Utensils, title: 'Mindful Eating', desc: 'Eat slowly, chew thoroughly, and pay attention to hunger and fullness cues. Avoid screens during meals.' },
];

export function NutritionPage() {
  return (
    <div className="pb-20">
      <PageHeader title="Nutrition Education" subtitle="General wellness nutrition fundamentals. Educational only — not medical dietary treatment." badge="AI Tool" />
      <div className="section-padding space-y-6">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {topics.map(t => {
            const Icon = t.icon;
            return (
              <div key={t.title} className="glass-card p-5">
                <div className="p-3 rounded-xl bg-white/5 w-fit mb-3"><Icon className="w-5 h-5 text-sage-soft" /></div>
                <h3 className="font-display font-semibold text-white mb-2">{t.title}</h3>
                <p className="text-sm text-white/50 leading-relaxed">{t.desc}</p>
              </div>
            );
          })}
        </div>
        <Disclaimer />
      </div>
    </div>
  );
}
