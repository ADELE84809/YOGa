import { useState } from 'react';
import { PageHeader, DemoModeBadge, Disclaimer } from '@/components/Shared';
import { AssessmentFlow, type AssessmentQuestion } from '@/components/AssessmentFlow';
import { ProgressRing } from '@/components/ProgressRing';
import { calculateWellnessScore, recommendExercises } from '@/services/recommendationService';
import { ExerciseCard } from '@/components/ExerciseCard';
import { storage } from '@/services/storageService';
import type { AssessmentResult } from '@/data/types';

export function WellnessAssessmentPage() {
  const [result, setResult] = useState<{ overall: number; breakdown: Record<string, number>; improvements: string[]; nextAction: string } | null>(null);
  const [answers, setAnswers] = useState<Record<string, number | number[]> | null>(null);
  const questions: AssessmentQuestion[] = [
    { id: 'movement', question: 'How much intentional movement do you do weekly?', type: 'scale', min: 0, max: 10, labels: ['None', 'Daily'] },
    { id: 'energy', question: 'How is your average energy level?', type: 'scale', min: 1, max: 10, labels: ['Very low', 'Excellent'] },
    { id: 'sleep', question: 'How would you rate your sleep quality?', type: 'scale', min: 1, max: 10, labels: ['Poor', 'Excellent'] },
    { id: 'stress', question: 'How manageable is your stress?', type: 'scale', min: 1, max: 10, labels: ['Overwhelming', 'Well managed'] },
    { id: 'recovery', question: 'How well do you recover between activities?', type: 'scale', min: 1, max: 10, labels: ['Poorly', 'Very well'] },
    { id: 'mindfulness', question: 'How often do you practice mindfulness or breathing?', type: 'scale', min: 0, max: 10, labels: ['Never', 'Daily'] },
    { id: 'routine', question: 'How consistent is your daily routine?', type: 'scale', min: 1, max: 10, labels: ['Inconsistent', 'Very consistent'] },
    { id: 'activity', question: 'How active is your lifestyle overall?', type: 'scale', min: 1, max: 10, labels: ['Sedentary', 'Very active'] },
  ];
  const onComplete = (a: Record<string, number | number[]>) => {
    setAnswers(a);
    const score = calculateWellnessScore({
      movement: a.movement as number * 10, recovery: a.recovery as number * 10, sleep: a.sleep as number * 10,
      mindfulness: a.mindfulness as number * 10, routine: a.routine as number * 10, consistency: a.activity as number * 10,
    });
    setResult(score);
    const assessment: AssessmentResult = {
      date: new Date().toISOString(), movement: a.movement as number * 10, energy: a.energy as number * 10,
      sleep: a.sleep as number * 10, stress: a.stress as number * 10, recovery: a.recovery as number * 10,
      mindfulness: a.mindfulness as number * 10, routine: a.routine as number * 10, activity: a.activity as number * 10,
    };
    storage.addAssessment(assessment);
  };
  return (
    <div className="pb-20">
      <PageHeader title="Wellness Assessment" subtitle="A comprehensive evaluation across 8 dimensions of wellness. Not a clinical assessment — a general wellness indicator." badge="AI Tool" />
      <div className="section-padding">
        {!result ? <AssessmentFlow questions={questions} onComplete={onComplete} /> : (
          <div className="space-y-6 max-w-3xl mx-auto">
            <div className="flex items-center justify-between"><h2 className="font-display text-2xl font-bold text-white">Your Wellness Profile</h2><DemoModeBadge /></div>
            <div className="glass p-8 text-center">
              <ProgressRing value={result.overall} label="Overall Score" size={160} />
              <p className="text-white/40 text-sm mt-4 max-w-md mx-auto">This is a general wellness indicator based on your self-reported inputs, not a clinically validated score.</p>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {Object.entries(result.breakdown).map(([key, val]) => (
                <div key={key} className="glass-card p-4 text-center">
                  <ProgressRing value={val} size={80} />
                  <p className="text-sm text-white/60 mt-2">{key}</p>
                </div>
              ))}
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-3">Improvement Opportunities</h3>
              <ul className="space-y-2">{result.improvements.map(imp => <li key={imp} className="text-sm text-white/60 flex items-start gap-2"><span className="w-1.5 h-1.5 rounded-full bg-violet-glow mt-1.5" />{imp}</li>)}</ul>
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-2">Next Action</h3>
              <p className="text-sm text-violet-soft">{result.nextAction}</p>
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-3">Suggested Tools</h3>
              <div className="grid sm:grid-cols-2 gap-3">
                <a href="/routine-builder" className="glass-card p-3 text-center text-sm text-white/60 hover:text-violet-soft">Daily Routine Builder</a>
                <a href="/breathing-lab" className="glass-card p-3 text-center text-sm text-white/60 hover:text-violet-soft">Breathing Lab</a>
                <a href="/wellness-score" className="glass-card p-3 text-center text-sm text-white/60 hover:text-violet-soft">Wellness Score</a>
                <a href="/goal-planner" className="glass-card p-3 text-center text-sm text-white/60 hover:text-violet-soft">Goal Planner</a>
              </div>
            </div>
            <Disclaimer />
            <button onClick={() => { setResult(null); setAnswers(null); }} className="btn-secondary">Retake Assessment</button>
          </div>
        )}
      </div>
    </div>
  );
}
