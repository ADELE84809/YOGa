import { PageHeader, DemoModeBadge, EmptyState } from '@/components/Shared';
import { storage } from '@/services/storageService';
import { generateProgressInsights } from '@/services/recommendationService';
import { ProgressRing } from '@/components/ProgressRing';
import { Calendar, Clock, Activity, TrendingUp } from 'lucide-react';

export function HabitIntelligencePage() {
  const sessions = storage.getSessions();
  const insights = generateProgressInsights(sessions.map(s => ({ date: s.date, duration: s.duration, category: 'Yoga' })));
  return (
    <div className="pb-20">
      <PageHeader title="Habit Intelligence" subtitle="Track your actual wellness activity and get insights from real data." badge="AI Tool" />
      <div className="section-padding space-y-6">
        <DemoModeBadge />
        {!insights.hasData ? (
          <EmptyState title="No activity data yet" message="Complete a few sessions to unlock deeper habit insights. Try an exercise or breathing session." />
        ) : (
          <>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="glass p-5 text-center"><Calendar className="w-5 h-5 text-violet-soft mx-auto mb-2" /><p className="font-display text-2xl font-bold text-white">{insights.totalSessions}</p><p className="text-xs text-white/40">Sessions</p></div>
              <div className="glass p-5 text-center"><Clock className="w-5 h-5 text-cyan-soft mx-auto mb-2" /><p className="font-display text-2xl font-bold text-white">{insights.totalMinutes}</p><p className="text-xs text-white/40">Minutes</p></div>
              <div className="glass p-5 text-center"><Activity className="w-5 h-5 text-sage-soft mx-auto mb-2" /><p className="font-display text-2xl font-bold text-white">{Object.keys(insights.categories).length}</p><p className="text-xs text-white/40">Categories</p></div>
              <div className="glass p-5 text-center"><TrendingUp className="w-5 h-5 text-violet-soft mx-auto mb-2" /><p className="font-display text-2xl font-bold text-white">{Math.round(insights.totalMinutes / insights.totalSessions)}</p><p className="text-xs text-white/40">Avg min/session</p></div>
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-3">Category Breakdown</h3>
              <div className="space-y-2">
                {Object.entries(insights.categories).map(([cat, count]) => (
                  <div key={cat} className="flex items-center justify-between">
                    <span className="text-sm text-white/60">{cat}</span>
                    <span className="text-sm text-violet-soft">{count} sessions</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-3">Insights</h3>
              <ul className="space-y-2">{insights.insights.map(ins => <li key={ins} className="text-sm text-white/60 flex items-start gap-2"><span className="w-1.5 h-1.5 rounded-full bg-violet-glow mt-1.5" />{ins}</li>)}</ul>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export function ProgressIntelligencePage() {
  const sessions = storage.getSessions();
  const insights = generateProgressInsights(sessions.map(s => ({ date: s.date, duration: s.duration, category: s.exerciseName })));
  return (
    <div className="pb-20">
      <PageHeader title="Progress Intelligence" subtitle="Insights generated from your actual activity — no fabricated data." badge="AI Tool" />
      <div className="section-padding space-y-6">
        <DemoModeBadge />
        {!insights.hasData ? (
          <EmptyState title="You haven't completed enough sessions yet" message="Complete a few more sessions to unlock meaningful progress intelligence." />
        ) : (
          <>
            <div className="grid sm:grid-cols-3 gap-4">
              <div className="glass p-6 text-center"><ProgressRing value={insights.totalSessions} max={30} label="Sessions" size={100} /></div>
              <div className="glass p-6 text-center"><ProgressRing value={insights.totalMinutes} max={300} label="Minutes" size={100} /></div>
              <div className="glass p-6 text-center"><ProgressRing value={Object.keys(insights.categories).length} max={8} label="Categories" size={100} /></div>
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-3">Activity Timeline</h3>
              <div className="space-y-2">
                {sessions.slice(0, 10).map(s => (
                  <div key={s.id} className="flex items-center justify-between glass-card p-3">
                    <div><span className="text-sm text-white/80">{s.exerciseName}</span><span className="text-xs text-white/40 ml-2">{new Date(s.date).toLocaleDateString()}</span></div>
                    <span className="text-xs text-violet-soft">{Math.floor(s.duration / 60)}min</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-3">Insights</h3>
              <ul className="space-y-2">{insights.insights.map(ins => <li key={ins} className="text-sm text-white/60 flex items-start gap-2"><span className="w-1.5 h-1.5 rounded-full bg-cyan-glow mt-1.5" />{ins}</li>)}</ul>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
