import { Link } from 'react-router-dom';
import { PageHeader } from '@/components/Shared';
import { aiTools, ToolCard } from '@/data/aiTools';

export function AIToolsPage() {
  return (
    <div className="pb-20">
      <PageHeader title="AI Wellness Hub" subtitle="20 intelligent wellness tools. Each is a standalone mini-product with personalized output." badge="20 Tools" />
      <div className="section-padding">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {aiTools.map(tool => <ToolCard key={tool.id} tool={tool} />)}
        </div>
      </div>
    </div>
  );
}

export function ProgramsPage() {
  return (
    <div className="pb-20">
      <PageHeader title="Programs" subtitle="Structured wellness programs and courses." badge="Programs" />
      <div className="section-padding space-y-6">
        <Link to="/courses/yoga-foundations" className="glass-card p-6 block">
          <h3 className="font-display text-xl font-bold text-white mb-2">Yoga Foundations Masterclass</h3>
          <p className="text-white/40 text-sm mb-4">Build a strong, safe, and sustainable yoga practice from the ground up.</p>
          <div className="flex items-center justify-between"><span className="text-2xl font-bold text-violet-soft">₹29</span><span className="text-sm text-white/40">1.5 hours • Beginner</span></div>
        </Link>
        <Link to="/courses/7-day-transformation" className="glass-card p-6 block border-violet-glow/20">
          <div className="flex items-center gap-2 mb-2"><span className="badge-violet">Launch Offer</span><span className="text-xs text-white/40">Save ₹2,601</span></div>
          <h3 className="font-display text-xl font-bold text-white mb-2">7-Day AI Yoga Transformation</h3>
          <p className="text-white/40 text-sm mb-4">A structured week-long journey to transform your practice and wellbeing.</p>
          <div className="flex items-center justify-between"><div><span className="text-2xl font-bold text-violet-soft">₹399</span> <span className="text-sm text-white/30 line-through">₹3,000</span></div><span className="text-sm text-white/40">7 days • All levels</span></div>
        </Link>
      </div>
    </div>
  );
}
