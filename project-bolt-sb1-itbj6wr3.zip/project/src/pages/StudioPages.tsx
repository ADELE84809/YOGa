import { useState } from 'react';
import { PageHeader, DemoModeBadge, Disclaimer } from '@/components/Shared';
import { BreathingOrb } from '@/components/BreathingOrb';
import { Timer } from '@/components/Timer';
import { AssessmentFlow, type AssessmentQuestion } from '@/components/AssessmentFlow';

export function BreathingLabPage() {
  const [started, setStarted] = useState(false);
  const [pattern, setPattern] = useState<'box' | '478' | 'coherent'>('box');
  const [duration, setDuration] = useState(120);
  const [feedback, setFeedback] = useState<{ feel: string; energy: number; calmness: number } | null>(null);
  const questions: AssessmentQuestion[] = [
    { id: 'goal', question: 'What do you want from this breathing session?', type: 'choice', options: [
      { label: 'Reduce stress', value: 1 }, { label: 'Improve focus', value: 2 }, { label: 'Prepare for sleep', value: 3 }, { label: 'Energize', value: 4 },
    ]},
    { id: 'state', question: 'How are you feeling right now?', type: 'choice', options: [
      { label: 'Anxious', value: 1 }, { label: 'Tired', value: 2 }, { label: 'Scattered', value: 3 }, { label: 'Calm', value: 4 },
    ]},
    { id: 'duration', question: 'How long do you want to practice?', type: 'choice', options: [
      { label: '2 minutes', value: 120 }, { label: '5 minutes', value: 300 }, { label: '10 minutes', value: 600 },
    ]},
  ];
  return (
    <div className="pb-20">
      <PageHeader title="Breathing Lab" subtitle="Interactive breathing sessions with a visual breathing guide. Choose your pattern and duration." badge="AI Tool" />
      <div className="section-padding">
        {!started ? (
          <AssessmentFlow questions={questions} onComplete={(a) => { setDuration(a.duration as number); if (a.goal === 3) setPattern('478'); else if (a.goal === 4) setPattern('coherent'); else setPattern('box'); setStarted(true); }} />
        ) : !feedback ? (
          <div className="space-y-6">
            <div className="flex justify-center"><DemoModeBadge /></div>
            <div className="flex justify-center gap-2">
              {(['box', '478', 'coherent'] as const).map(p => (
                <button key={p} onClick={() => setPattern(p)} className={`px-4 py-2 rounded-lg text-sm capitalize ${pattern === p ? 'bg-violet-glow/20 text-violet-soft' : 'glass-card text-white/40'}`}>{p === '478' ? '4-7-8' : p}</button>
              ))}
            </div>
            <BreathingOrb duration={duration} pattern={pattern} />
            <div className="glass p-6 max-w-md mx-auto">
              <h3 className="font-display font-semibold text-white mb-3">Session Complete — How was it?</h3>
              <label className="text-xs text-white/40 mb-1 block">How do you feel?</label>
              <select onChange={e => setFeedback({ ...feedback!, feel: e.target.value, energy: feedback?.energy || 3, calmness: feedback?.calmness || 3 })} className="input-field text-sm mb-3">
                <option value="">Select...</option><option>More relaxed</option><option>Calmer</option><option>More focused</option><option>No change</option>
              </select>
              <label className="text-xs text-white/40 mb-1 block">Energy after ({feedback?.energy || 3}/5)</label>
              <input type="range" min={1} max={5} onChange={e => setFeedback({ ...feedback!, feel: feedback?.feel || '', energy: Number(e.target.value), calmness: feedback?.calmness || 3 })} className="w-full accent-violet-glow mb-3" />
              <label className="text-xs text-white/40 mb-1 block">Calmness ({feedback?.calmness || 3}/5)</label>
              <input type="range" min={1} max={5} onChange={e => setFeedback({ ...feedback!, feel: feedback?.feel || '', energy: feedback?.energy || 3, calmness: Number(e.target.value) })} className="w-full accent-violet-glow mb-3" />
              <button onClick={() => setFeedback({ feel: feedback?.feel || 'Good', energy: feedback?.energy || 3, calmness: feedback?.calmness || 3 })} className="btn-primary w-full">Submit Feedback</button>
            </div>
          </div>
        ) : (
          <div className="space-y-6 max-w-2xl mx-auto">
            <DemoModeBadge />
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-3">Personalized Breathing Review</h3>
              <p className="text-sm text-white/60">You reported feeling <span className="text-violet-soft">{feedback.feel}</span> after the session. Energy: {feedback.energy}/5, Calmness: {feedback.calmness}/5.</p>
              <p className="text-sm text-white/60 mt-2">{feedback.calmness >= 4 ? 'This breathing pattern works well for you. Consider making it a daily practice.' : 'Try a different pattern or longer duration next time.'}</p>
            </div>
            <button onClick={() => { setStarted(false); setFeedback(null); }} className="btn-secondary">New Session</button>
          </div>
        )}
      </div>
    </div>
  );
}

export function MeditationStudioPage() {
  const [started, setStarted] = useState(false);
  const [duration, setDuration] = useState(300);
  const [feedback, setFeedback] = useState<string | null>(null);
  const questions: AssessmentQuestion[] = [
    { id: 'goal', question: 'What do you want from this meditation?', type: 'choice', options: [
      { label: 'Reduce stress', value: 1 }, { label: 'Improve focus', value: 2 }, { label: 'Better sleep', value: 3 }, { label: 'Self-awareness', value: 4 },
    ]},
    { id: 'mood', question: 'How are you feeling?', type: 'choice', options: [
      { label: 'Anxious', value: 1 }, { label: 'Sad', value: 2 }, { label: 'Neutral', value: 3 }, { label: 'Good', value: 4 },
    ]},
    { id: 'duration', question: 'How long?', type: 'choice', options: [
      { label: '3 minutes', value: 180 }, { label: '5 minutes', value: 300 }, { label: '10 minutes', value: 600 },
    ]},
    { id: 'experience', question: 'Meditation experience?', type: 'choice', options: [
      { label: 'New to meditation', value: 1 }, { label: 'Some experience', value: 2 }, { label: 'Regular practice', value: 3 },
    ]},
  ];
  return (
    <div className="pb-20">
      <PageHeader title="Meditation Studio" subtitle="Personalized meditation sessions with timer, guidance, and post-session reflection." badge="AI Tool" />
      <div className="section-padding">
        {!started ? (
          <AssessmentFlow questions={questions} onComplete={(a) => { setDuration(a.duration as number); setStarted(true); }} />
        ) : !feedback ? (
          <div className="space-y-8 max-w-2xl mx-auto text-center">
            <DemoModeBadge />
            <Timer totalSeconds={duration} label="Meditation" onComplete={() => {}} />
            <div className="glass p-6 text-left">
              <h3 className="font-display font-semibold text-white mb-3">Guided Reflection</h3>
              <p className="text-sm text-white/60">Find a comfortable position. Close your eyes or soften your gaze. Breathe naturally. When your mind wanders, gently bring attention back to your breath. No judgment — just return.</p>
            </div>
            <button onClick={() => setFeedback('done')} className="btn-primary">Complete Session</button>
          </div>
        ) : (
          <div className="space-y-6 max-w-2xl mx-auto">
            <DemoModeBadge />
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-3">Session Reflection</h3>
              <p className="text-sm text-white/60">You completed a {Math.floor(duration / 60)}-minute meditation. Regular practice, even short sessions, builds mental clarity over time. Try to practice daily, even for just 3 minutes.</p>
            </div>
            <button onClick={() => { setStarted(false); setFeedback(null); }} className="btn-secondary">New Session</button>
          </div>
        )}
      </div>
    </div>
  );
}

export function SleepStudioPage() {
  return (
    <div className="pb-20">
      <PageHeader title="Sleep Studio" subtitle="An evening wellness experience with wind-down routine, breathing, and gentle movement." badge="AI Tool" />
      <div className="section-padding space-y-6 max-w-2xl mx-auto">
        <DemoModeBadge />
        <div className="glass p-6">
          <h3 className="font-display font-semibold text-white mb-3">Wind-Down Routine</h3>
          <div className="space-y-3">
            {[
              { time: '5 min', title: 'Gentle Movement', desc: 'Slow neck rolls, shoulder releases, and seated forward folds to release the day.' },
              { time: '5 min', title: '4-7-8 Breathing', desc: 'Calming breathing pattern to activate the parasympathetic nervous system.' },
              { time: '5 min', title: 'Body Scan', desc: 'Progressive relaxation from head to toe, releasing tension in each area.' },
              { time: '5 min', title: 'Gratitude Reflection', desc: 'Three things you are grateful for today.' },
            ].map((step, i) => (
              <div key={i} className="glass-card p-4">
                <div className="flex items-center justify-between mb-1"><span className="text-white font-medium text-sm">{step.title}</span><span className="text-xs text-white/40">{step.time}</span></div>
                <p className="text-xs text-white/50">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
        <div className="glass p-6 text-center">
          <h3 className="font-display font-semibold text-white mb-4">Breathing Exercise</h3>
          <BreathingOrb duration={180} pattern="478" />
        </div>
        <Disclaimer />
      </div>
    </div>
  );
}

export function FocusStudioPage() {
  const [active, setActive] = useState(false);
  const [duration, setDuration] = useState(1500);
  return (
    <div className="pb-20">
      <PageHeader title="Focus Studio" subtitle="Focus timer with breathing and movement breaks to maintain deep work." badge="AI Tool" />
      <div className="section-padding space-y-6 max-w-2xl mx-auto">
        <DemoModeBadge />
        <div className="glass p-6 text-center">
          <h3 className="font-display font-semibold text-white mb-4">Focus Session</h3>
          <div className="flex justify-center gap-2 mb-6">
            {[15, 25, 45].map(m => <button key={m} onClick={() => setDuration(m * 60)} className={`px-4 py-2 rounded-lg text-sm ${duration === m * 60 ? 'bg-violet-glow/20 text-violet-soft' : 'glass-card text-white/40'}`}>{m} min</button>)}
          </div>
          <Timer totalSeconds={duration} label="Focus" onComplete={() => setActive(false)} />
        </div>
        <div className="glass p-6">
          <h3 className="font-display font-semibold text-white mb-3">Movement Break (every 25 min)</h3>
          <p className="text-sm text-white/60">When the timer ends: 1 min shoulder rolls, 1 min seated spinal twist, 1 min standing side stretch, 30 sec eye palming. Then return to focus.</p>
        </div>
        <Disclaimer />
      </div>
    </div>
  );
}
