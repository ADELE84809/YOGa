import { Link } from 'react-router-dom';
import { VirtualHuman } from '@/components/VirtualHuman';
import { ToolCard, aiTools } from '@/data/aiTools';
import { exerciseCount } from '@/data/exercises';
import { ArrowRight, Activity, Brain, Eye, Heart, Zap, Moon } from 'lucide-react';

export function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
        <div className="absolute inset-0 bg-grid-pattern bg-grid opacity-30" />
        <div className="absolute inset-0 bg-radial-glow" />
        <div className="section-padding relative z-10 grid lg:grid-cols-2 gap-8 items-center">
          <div className="animate-fade-up">
            <div className="badge-violet mb-6"><Activity className="w-3 h-3" /> Intelligent Wellness Platform</div>
            <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold text-white leading-[1.05] text-balance">
              Your Body.<br />Your Mind.<br /><span className="text-gradient-violet">Powered by Intelligence.</span>
            </h1>
            <p className="text-white/50 text-lg mt-6 max-w-lg text-balance">
              One intelligent platform for movement, yoga, recovery, mindfulness, and everyday wellness.
            </p>
            <div className="flex flex-wrap items-center gap-3 mt-8">
              <Link to="/ai-tools" className="btn-primary flex items-center gap-2">Explore AI Tools <ArrowRight className="w-4 h-4" /></Link>
              <Link to="/ai-yoga-coach" className="btn-secondary">Start Free</Link>
            </div>
            <p className="text-white/30 text-sm mt-4">Free tools • No sign-up required</p>
          </div>
          <div className="relative h-[400px] lg:h-[500px] animate-scale-in">
            <VirtualHuman exerciseName="Holographic Avatar" primitives={['Flow', 'ArmRaise', 'Balance']} activePhase="HOLD" playing speed={0.5} progress={50} showSkeleton showJoints showBreathing />
          </div>
        </div>
      </section>

      {/* Why */}
      <section className="py-20 section-padding">
        <h2 className="font-display text-3xl sm:text-4xl font-bold text-white text-center mb-4">Why GlobalYogaCourse</h2>
        <p className="text-white/40 text-center max-w-2xl mx-auto mb-12">Understand your body → Build better movement → Recover → Improve → Repeat</p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { icon: Brain, title: 'Understand', desc: 'Assess your body, posture, mobility, and wellness with intelligent tools.', color: 'violet' },
            { icon: Activity, title: 'Move Better', desc: '500+ exercises with virtual human visualization and form guidance.', color: 'cyan' },
            { icon: Heart, title: 'Recover', desc: 'Personalized recovery, breathing, and meditation sessions.', color: 'sage' },
            { icon: Zap, title: 'Improve', desc: 'Track real progress and get smarter recommendations over time.', color: 'violet' },
          ].map((item, i) => {
            const Icon = item.icon;
            return (
              <div key={i} className="glass-card p-6">
                <div className="p-3 rounded-xl bg-white/5 w-fit mb-4"><Icon className="w-6 h-6 text-violet-soft" /></div>
                <h3 className="font-display font-semibold text-white text-lg mb-2">{item.title}</h3>
                <p className="text-white/40 text-sm leading-relaxed">{item.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* AI Wellness Hub */}
      <section className="py-20 section-padding">
        <div className="text-center mb-12">
          <span className="badge-cyan mb-4"><Brain className="w-3 h-3" /> 20 AI Wellness Tools</span>
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-white">AI Wellness Hub</h2>
          <p className="text-white/40 mt-2">Each tool is a standalone mini-product with personalized output.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {aiTools.slice(0, 12).map(tool => <ToolCard key={tool.id} tool={tool} />)}
        </div>
        <div className="text-center mt-8">
          <Link to="/ai-tools" className="btn-secondary inline-flex items-center gap-2">View All 20 Tools <ArrowRight className="w-4 h-4" /></Link>
        </div>
      </section>

      {/* Movement Intelligence */}
      <section className="py-20 section-padding">
        <div className="grid lg:grid-cols-2 gap-8 items-center">
          <div>
            <span className="badge-violet mb-4"><Eye className="w-3 h-3" /> Movement Intelligence</span>
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-white mb-4">Virtual Human Exercise System</h2>
            <p className="text-white/50 leading-relaxed mb-6">
              A futuristic holographic human shows you exactly how each movement works. See the skeleton, joints, movement paths, and breathing — all in an interactive laboratory.
            </p>
            <ul className="space-y-2 text-white/60">
              {['Front, side, and back camera views', 'Skeleton and joint tracking overlays', 'Movement phase timeline (Start → Move → Hold → Return)', 'Compare correct form vs common mistakes', 'Breathing synchronization guide'].map(f => (
              <li key={f} className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-violet-glow" />{f}</li>
            ))}
            </ul>
            <Link to="/movement-visualizer" className="btn-primary mt-8 inline-flex items-center gap-2">Open Movement Lab <ArrowRight className="w-4 h-4" /></Link>
          </div>
          <div className="h-[350px] glass rounded-2xl overflow-hidden">
            <VirtualHuman exerciseName="Warrior II" primitives={['Lunge', 'ArmRaise']} activePhase="HOLD" playing speed={0.4} progress={60} showSkeleton showJoints highlightedAreas={['Shoulders', 'Hips', 'Thighs']} />
          </div>
        </div>
      </section>

      {/* Exercise Library */}
      <section className="py-20 section-padding">
        <div className="text-center mb-12">
          <span className="badge-sage mb-4"><Activity className="w-3 h-3" /> Exercise Database</span>
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-white">{exerciseCount}+ Structured Movements</h2>
          <p className="text-white/40 mt-2">Yoga, mobility, strength, breathing, meditation, recovery, and more.</p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {['Yoga', 'Mobility', 'Strength', 'Breathing', 'Meditation', 'Posture', 'Recovery', 'Movement Break'].map(cat => (
            <Link key={cat} to={`/exercises?category=${cat}`} className="glass-card p-4 text-center group">
              <span className="text-sm font-medium text-white/60 group-hover:text-violet-soft transition-colors">{cat}</span>
            </Link>
          ))}
        </div>
        <div className="text-center mt-8">
          <Link to="/exercises" className="btn-secondary inline-flex items-center gap-2">Browse All Exercises <ArrowRight className="w-4 h-4" /></Link>
        </div>
      </section>

      {/* Courses */}
      <section className="py-20 section-padding">
        <div className="text-center mb-12">
          <span className="badge-blue mb-4"><Moon className="w-3 h-3" /> Programs & Courses</span>
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-white">Premium Wellness Courses</h2>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          <Link to="/courses/yoga-foundations" className="glass-card p-6 group">
            <h3 className="font-display text-xl font-bold text-white mb-2">Yoga Foundations Masterclass</h3>
            <p className="text-white/40 text-sm mb-4">Build a strong, safe, and sustainable yoga practice from the ground up.</p>
            <div className="flex items-center justify-between">
              <span className="text-2xl font-bold text-violet-soft">₹29</span>
              <span className="text-sm text-white/40">1.5 hours • Beginner</span>
            </div>
          </Link>
          <Link to="/courses/7-day-transformation" className="glass-card p-6 group border-violet-glow/20">
            <div className="flex items-center gap-2 mb-2"><span className="badge-violet">Launch Offer</span><span className="text-xs text-white/40">Save ₹2,601</span></div>
            <h3 className="font-display text-xl font-bold text-white mb-2">7-Day AI Yoga Transformation</h3>
            <p className="text-white/40 text-sm mb-4">A structured week-long journey to transform your practice and wellbeing.</p>
            <div className="flex items-center justify-between">
              <div><span className="text-2xl font-bold text-violet-soft">₹399</span> <span className="text-sm text-white/30 line-through">₹3,000</span></div>
              <span className="text-sm text-white/40">7 days • All levels</span>
            </div>
          </Link>
        </div>
      </section>

      {/* Wellness OS */}
      <section className="py-20 section-padding">
        <div className="glass p-8 lg:p-12 text-center">
          <span className="badge-cyan mb-4"><Zap className="w-3 h-3" /> Wellness OS</span>
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-white mb-4">Your Personal Wellness Dashboard</h2>
          <p className="text-white/50 max-w-2xl mx-auto mb-8">Track sessions, habits, goals, and progress — all from real data. No fake numbers.</p>
          <Link to="/wellness-os" className="btn-primary inline-flex items-center gap-2">Open Wellness OS <ArrowRight className="w-4 h-4" /></Link>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 section-padding">
        <div className="text-center">
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-white mb-4">Start Your Wellness Journey</h2>
          <p className="text-white/40 mb-8 max-w-xl mx-auto">Free tools. No sign-up required. {exerciseCount}+ movements and 20 intelligent wellness tools.</p>
          <div className="flex flex-wrap justify-center gap-3">
            <Link to="/ai-tools" className="btn-primary">Explore AI Tools</Link>
            <Link to="/wellness-assessment" className="btn-secondary">Take Assessment</Link>
          </div>
        </div>
      </section>
    </div>
  );
}
