import { useState, useMemo, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ExerciseCard } from '@/components/ExerciseCard';
import { PageHeader, EmptyState } from '@/components/Shared';
import { filterExercises, getCategories, getDifficulties, getGoals, getBodyAreas, getAllExercises } from '@/services/exerciseService';
import { Search, SlidersHorizontal } from 'lucide-react';

const PAGE_SIZE = 24;

export function ExerciseLibraryPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [search, setSearch] = useState(searchParams.get('q') || '');
  const [category, setCategory] = useState(searchParams.get('category') || '');
  const [difficulty, setDifficulty] = useState(searchParams.get('difficulty') || '');
  const [goal, setGoal] = useState(searchParams.get('goal') || '');
  const [bodyArea, setBodyArea] = useState(searchParams.get('bodyArea') || '');
  const [maxDuration, setMaxDuration] = useState(Number(searchParams.get('maxDuration')) || 0);
  const [page, setPage] = useState(1);
  const [showFilters, setShowFilters] = useState(false);

  const categories = useMemo(() => getCategories(), []);
  const difficulties = useMemo(() => getDifficulties(), []);
  const goals = useMemo(() => getGoals(), []);
  const bodyAreas = useMemo(() => getBodyAreas(), []);

  useEffect(() => { setPage(1); }, [search, category, difficulty, goal, bodyArea, maxDuration]);

  const results = useMemo(() => {
    let list = filterExercises({ category, difficulty, goal, bodyArea, maxDuration: maxDuration || undefined });
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(e => e.name.toLowerCase().includes(q) || e.tags.some(t => t.toLowerCase().includes(q)));
    }
    return list;
  }, [search, category, difficulty, goal, bodyArea, maxDuration]);

  const paged = results.slice(0, page * PAGE_SIZE);

  const updateFilter = (key: string, value: string) => {
    const params = new URLSearchParams(searchParams);
    if (value) params.set(key, value); else params.delete(key);
    setSearchParams(params);
    if (key === 'category') setCategory(value);
    if (key === 'difficulty') setDifficulty(value);
    if (key === 'goal') setGoal(value);
    if (key === 'bodyArea') setBodyArea(value);
  };

  return (
    <div>
      <PageHeader title="Exercise Library" subtitle="500+ structured movements with virtual human visualization, form guidance, and personalized recommendations." badge="Movement Database" />
      <div className="section-padding pb-20">
        <div className="flex gap-3 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search exercises..." className="input-field pl-11" />
          </div>
          <button onClick={() => setShowFilters(!showFilters)} className="btn-secondary flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4" /> Filters
          </button>
        </div>

        {showFilters && (
          <div className="glass p-4 mb-6 grid sm:grid-cols-2 lg:grid-cols-4 gap-4 animate-fade-up">
            <div>
              <label className="text-xs text-white/40 mb-1 block">Category</label>
              <select value={category} onChange={e => updateFilter('category', e.target.value)} className="input-field text-sm">
                <option value="">All</option>
                {categories.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-white/40 mb-1 block">Difficulty</label>
              <select value={difficulty} onChange={e => updateFilter('difficulty', e.target.value)} className="input-field text-sm">
                <option value="">All</option>
                {difficulties.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-white/40 mb-1 block">Goal</label>
              <select value={goal} onChange={e => updateFilter('goal', e.target.value)} className="input-field text-sm">
                <option value="">All</option>
                {goals.map(g => <option key={g} value={g}>{g}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-white/40 mb-1 block">Body Area</label>
              <select value={bodyArea} onChange={e => updateFilter('bodyArea', e.target.value)} className="input-field text-sm">
                <option value="">All</option>
                {bodyAreas.map(a => <option key={a} value={a}>{a}</option>)}
              </select>
            </div>
          </div>
        )}

        <p className="text-sm text-white/40 mb-4">{results.length} exercises found</p>

        {results.length === 0 ? (
          <EmptyState title="No movements match your filters" message="Try adjusting your goal, body area, or difficulty filters." />
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {paged.map(ex => <ExerciseCard key={ex.id} exercise={ex} />)}
            </div>
            {paged.length < results.length && (
              <div className="text-center mt-8">
                <button onClick={() => setPage(p => p + 1)} className="btn-secondary">Load More</button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
