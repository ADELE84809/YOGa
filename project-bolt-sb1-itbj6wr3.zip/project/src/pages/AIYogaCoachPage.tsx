import { useState } from 'react';
import { PageHeader, DemoModeBadge, Disclaimer } from '@/components/Shared';
import { AssessmentFlow, type AssessmentQuestion } from '@/components/AssessmentFlow';
import { recommendExercises } from '@/services/recommendationService';
import { ExerciseCard } from '@/components/ExerciseCard';
import { storage } from '@/services/storageService';

export function AIYogaCoachPage() {
  const [result, setResult] = useState<ReturnType<typeof recommendExercises> | null>(null);
  const [answers, setAnswers] = useState<Record<string, number | number[]> | null>(null);

  const questions: AssessmentQuestion[] = [
    { id: 'goal', question: 'What is your primary wellness goal?', type: 'choice', options: [
      { label: 'Flexibility & Mobility', value: 1 }, { label: 'Strength & Stability', value: 2 },
      { label: 'Stress Relief & Relaxation', value: 3 }, { label: 'Better Sleep', value: 4 },
      { label: 'Energy & Focus', value: 5 }, { label: 'Posture Correction', value: 6 },
    ]},
    { id: 'experience', question: 'What is your experience level?', type: 'choice', options: [
      { label: 'Complete beginner', value: 1 }, { label: 'Some experience', value: 2 }, { label: 'Regular practice', value: 3 }, { label: 'Advanced', value: 4 },
    ]},
    { id: 'duration', question: 'How long do you prefer to practice?', type: 'choice', options: [
      { label: '10-15 minutes', value: 600 }, { label: '20-30 minutes', value: 1800 }, { label: '40+ minutes', value: 2400 },
    ]},
    { id: 'days', question: 'How many days per week can you practice?', type: 'scale', min: 1, max: 7, labels: ['1 day', '7 days'] },
    { id: 'time', question: 'When do you prefer to practice?', type: 'choice', options: [
      { label: 'Morning', value: 1 }, { label: 'Afternoon', value: 2 }, { label: 'Evening', value: 3 },
    ]},
    { id: 'energy', question: 'How is your current energy level?', type: 'scale', min: 1, max: 5, labels: ['Low', 'High'] },
    { id: 'areas', question: 'Which body areas need attention?', type: 'multi', options: [
      { label: 'Hips', value: 1 }, { label: 'Shoulders', value: 2 }, { label: 'Lower Back', value: 3 },
      { label: 'Neck', value: 4 }, { label: 'Core', value: 5 }, { label: 'Hamstrings', value: 6 },
    ]},
    { id: 'shortGoal', question: 'What is your short-term goal?', type: 'choice', options: [
      { label: 'Build a daily habit', value: 1 }, { label: 'Reduce stiffness', value: 2 },
      { label: 'Improve flexibility', value: 3 }, { label: 'Feel more energized', value: 4 },
    ]},
  ];

  const goals = ['Flexibility', 'Strength', 'Stress Relief', 'Better Sleep', 'Energy', 'Posture'];
  const goalMap: Record<number, string> = { 1: 'Flexibility', 2: 'Strength', 3: 'Stress Relief', 4: 'Better Sleep', 5: 'Energy', 6: 'Posture' };
  const diffMap: Record<number, string> = { 1: 'Beginner', 2: 'Beginner', 3: 'Intermediate', 4: 'Advanced' };

  const onComplete = (a: Record<string, number | number[]>) => {
    setAnswers(a);
    const goal = goalMap[a.goal as number] || 'Flexibility';
    const diff = diffMap[a.experience as number] || 'Beginner';
    const rec = recommendExercises({ goal, difficulty: diff, maxDuration: (a.duration as number) || 600, limit: 6 });
    setResult(rec);
    storage.saveProfile({ goal: goal as any, experience: diff as any, preferredDuration: a.duration as number, energy: a.energy as number });
  };

  return (
    <div className="pb-20">
      <PageHeader title="AI Yoga Coach" subtitle="Get a personalized wellness profile, recommended exercises, and weekly structure based on your goals and experience." badge="AI Tool" />
      <div className="section-padding">
        {!result ? (
          <AssessmentFlow questions={questions} onComplete={onComplete} title="AI Yoga Coach Assessment" />
        ) : (
          <div className="space-y-6">
            <div className="flex items-center justify-between"><h2 className="font-display text-2xl font-bold text-white">Personal Wellness Profile</h2><DemoModeBadge /></div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-3">Personalized Review</h3>
              <p className="text-white/60 text-sm leading-relaxed">Based on your responses, you're focused on <span className="text-violet-soft">{goals[(answers?.goal as number || 1) - 1]}</span> at a <span className="text-violet-soft">{diffMap[answers?.experience as number || 1]}</span> level. You prefer <span className="text-violet-soft">{Math.floor((answers?.duration as number || 600) / 60)} minute</span> sessions, about <span className="text-violet-soft">{answers?.days || 3} days</span> per week.</p>
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-3">Recommended Exercises</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {result.exercises.map(ex => <ExerciseCard key={ex.id} exercise={ex} />)}
              </div>
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-3">Weekly Structure</h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
                {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, i) => (
                  <div key={day} className="glass-card p-3 text-center">
                    <p className="text-xs text-white/40 mb-1">{day}</p>
                    <p className="text-sm text-white/70">{i < (answers?.days || 3) ? `${Math.floor((answers?.duration as number || 600) / 60)}min` : 'Rest'}</p>
                  </div>
                ))}
              </div>
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-2">Suggested Session Duration</h3>
              <p className="text-sm text-white/60">{Math.floor((answers?.duration as number || 600) / 60)} minutes per session. Progression: Add 5 minutes every 2 weeks as consistency builds.</p>
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-2">Things to Focus On</h3>
              <ul className="space-y-1 text-sm text-white/60">{['Consistency over intensity — showing up matters more than pushing hard', 'Listen to your body — adjust intensity based on how you feel each day', 'Breath is your anchor — maintain steady breathing throughout', 'Track your sessions to see progress over time'].map(t => <li key={t} className="flex items-start gap-2"><span className="w-1.5 h-1.5 rounded-full bg-violet-glow mt-1.5" />{t}</li>)}</ul>
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-2">Next Action</h3>
              <p className="text-sm text-white/60">Start with one of the recommended exercises above. Complete it, provide feedback, and the system will refine future recommendations.</p>
            </div>
            <Disclaimer />
            <button onClick={() => setResult(null)} className="btn-secondary">Modify Answers & Regenerate</button>
          </div>
        )}
      </div>
    </div>
  );
}
