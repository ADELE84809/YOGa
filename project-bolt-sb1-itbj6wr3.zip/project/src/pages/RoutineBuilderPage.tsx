import { useState } from 'react';
import { PageHeader, DemoModeBadge, Disclaimer, EmptyState } from '@/components/Shared';
import { AssessmentFlow, type AssessmentQuestion } from '@/components/AssessmentFlow';
import { recommendExercises, generateRoutine } from '@/services/recommendationService';
import { ExerciseCard } from '@/components/ExerciseCard';
import { storage } from '@/services/storageService';
import type { SavedRoutine } from '@/data/types';
import { Plus, Trash2, GripVertical, Save } from 'lucide-react';

export function RoutineBuilderPage() {
  const [answers, setAnswers] = useState<Record<string, number | number[]> | null>(null);
  const [routine, setRoutine] = useState<ReturnType<typeof generateRoutine> | null>(null);
  const [routineName, setRoutineName] = useState('');
  const [saved, setSaved] = useState<SavedRoutine[]>(storage.getRoutines());
  const questions: AssessmentQuestion[] = [
    { id: 'wake', question: 'What time do you wake up?', type: 'choice', options: [
      { label: '5-6 AM', value: 5 }, { label: '6-7 AM', value: 6 }, { label: '7-8 AM', value: 7 }, { label: '8-9 AM', value: 8 },
    ]},
    { id: 'sleep', question: 'What time do you go to sleep?', type: 'choice', options: [
      { label: '9-10 PM', value: 21 }, { label: '10-11 PM', value: 22 }, { label: '11-12 PM', value: 23 }, { label: 'After 12', value: 24 },
    ]},
    { id: 'freeTime', question: 'How much free time do you have for wellness?', type: 'choice', options: [
      { label: '10 min', value: 10 }, { label: '20 min', value: 20 }, { label: '30 min', value: 30 }, { label: '45+ min', value: 45 },
    ]},
    { id: 'energy', question: 'When is your energy highest?', type: 'choice', options: [
      { label: 'Morning', value: 1 }, { label: 'Afternoon', value: 2 }, { label: 'Evening', value: 3 },
    ]},
    { id: 'goal', question: 'Primary goal?', type: 'choice', options: [
      { label: 'Energy', value: 1 }, { label: 'Flexibility', value: 2 }, { label: 'Stress Relief', value: 3 }, { label: 'Strength', value: 4 },
    ]},
  ];
  const goalMap: Record<number, string> = { 1: 'Energy', 2: 'Flexibility', 3: 'Stress Relief', 4: 'Strength' };
  const onComplete = (a: Record<string, number | number[]>) => { setAnswers(a); setRoutine(generateRoutine({ goal: goalMap[a.goal as number], difficulty: 'Beginner', duration: a.freeTime as number })); };

  const saveRoutine = () => {
    if (!routine || !routineName) return;
    const r: SavedRoutine = { id: `routine-${Date.now()}`, name: routineName, exercises: routine.map(e => ({ exerciseId: e.id, duration: e.duration })), createdAt: new Date().toISOString() };
    storage.saveRoutine(r);
    setSaved(storage.getRoutines());
    setRoutineName('');
  };

  return (
    <div className="pb-20">
      <PageHeader title="Daily Routine Builder" subtitle="Build your perfect daily wellness routine based on your schedule and goals." badge="AI Tool" />
      <div className="section-padding">
        {!routine ? <AssessmentFlow questions={questions} onComplete={onComplete} /> : (
          <div className="space-y-6">
            <div className="flex items-center justify-between"><h2 className="font-display text-2xl font-bold text-white">Your Daily Routine</h2><DemoModeBadge /></div>
            <div className="grid lg:grid-cols-3 gap-4">
              {[
                { title: 'Morning', desc: 'Energize & mobilize', color: 'text-amber-400' },
                { title: 'Afternoon', desc: 'Reset & refocus', color: 'text-cyan-soft' },
                { title: 'Evening', desc: 'Wind down & recover', color: 'text-violet-soft' },
              ].map((slot, i) => (
                <div key={slot.title} className="glass p-4">
                  <h3 className={`font-display font-semibold ${slot.color} mb-1`}>{slot.title}</h3>
                  <p className="text-xs text-white/40 mb-3">{slot.desc}</p>
                  <div className="space-y-2">
                    {routine.slice(i * 2, i * 2 + 2).map(ex => (
                      <div key={ex.id} className="glass-card p-3">
                        <p className="text-sm text-white/80">{ex.name}</p>
                        <p className="text-xs text-white/40">{Math.floor(ex.duration / 60)} min • {ex.category}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <div className="glass p-4 flex items-center gap-3">
              <input value={routineName} onChange={e => setRoutineName(e.target.value)} placeholder="Routine name..." className="input-field flex-1 text-sm" />
              <button onClick={saveRoutine} className="btn-primary flex items-center gap-2"><Save className="w-4 h-4" /> Save</button>
            </div>
            {saved.length > 0 && (
              <div>
                <h3 className="font-display font-semibold text-white mb-3">Saved Routines</h3>
                <div className="space-y-2">
                  {saved.map(r => (
                    <div key={r.id} className="glass-card p-3 flex items-center justify-between">
                      <div><span className="text-sm text-white/80">{r.name}</span><span className="text-xs text-white/40 ml-2">{r.exercises.length} exercises</span></div>
                      <button onClick={() => { storage.deleteRoutine(r.id); setSaved(storage.getRoutines()); }} className="text-white/30 hover:text-red-400"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  ))}
                </div>
              </div>
            )}
            <Disclaimer />
            <button onClick={() => { setRoutine(null); setAnswers(null); }} className="btn-secondary">Rebuild Routine</button>
          </div>
        )}
      </div>
    </div>
  );
}
