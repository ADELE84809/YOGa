import { useState } from 'react';
import { PageHeader, DemoModeBadge, Disclaimer } from '@/components/Shared';
import { AssessmentFlow, type AssessmentQuestion } from '@/components/AssessmentFlow';
import { recommendExercises } from '@/services/recommendationService';
import { ExerciseCard } from '@/components/ExerciseCard';

interface ToolConfig { title: string; subtitle: string; badge: string; questions: AssessmentQuestion[]; goalMap?: Record<number, string>; areaMap?: Record<number, string>; }

function GenericLabPage({ config, onComplete }: { config: ToolConfig; onComplete: (a: Record<string, number | number[]>) => void }) {
  const [done, setDone] = useState(false);
  return (
    <div className="pb-20">
      <PageHeader title={config.title} subtitle={config.subtitle} badge={config.badge} />
      <div className="section-padding">
        {!done ? <AssessmentFlow questions={config.questions} onComplete={(a) => { onComplete(a); setDone(true); }} /> : <Disclaimer />}
      </div>
    </div>
  );
}

export function PostureLabPage() {
  const [result, setResult] = useState<ReturnType<typeof recommendExercises> | null>(null);
  const [answers, setAnswers] = useState<Record<string, number | number[]> | null>(null);
  const questions: AssessmentQuestion[] = [
    { id: 'sitting', question: 'How many hours do you sit per day?', type: 'scale', min: 1, max: 12, labels: ['1hr', '12hr'] },
    { id: 'breaks', question: 'How often do you take movement breaks?', type: 'choice', options: [
      { label: 'Every 30 min', value: 1 }, { label: 'Every 1-2 hours', value: 2 }, { label: 'Rarely', value: 3 }, { label: 'Never', value: 4 },
    ]},
    { id: 'screen', question: 'How is your screen height relative to eye level?', type: 'choice', options: [
      { label: 'At eye level', value: 1 }, { label: 'Slightly below', value: 2 }, { label: 'Below — I look down', value: 3 },
    ]},
    { id: 'shoulders', question: 'Do your shoulders roll forward?', type: 'scale', min: 1, max: 5, labels: ['Never', 'Always'] },
    { id: 'awareness', question: 'How aware are you of your posture during the day?', type: 'scale', min: 1, max: 5, labels: ['Not aware', 'Very aware'] },
    { id: 'activity', question: 'What is your general activity level?', type: 'choice', options: [
      { label: 'Sedentary', value: 1 }, { label: 'Lightly active', value: 2 }, { label: 'Moderately active', value: 3 }, { label: 'Very active', value: 4 },
    ]},
  ];
  return (
    <div className="pb-20">
      <PageHeader title="Posture Lab" subtitle="Assess your posture habits and get a corrective movement plan." badge="AI Tool" />
      <div className="section-padding">
        {!result ? <AssessmentFlow questions={questions} onComplete={(a) => { setAnswers(a); setResult(recommendExercises({ goal: 'Posture', limit: 6 })); }} /> : (
          <div className="space-y-6">
            <div className="flex items-center justify-between"><h2 className="font-display text-2xl font-bold text-white">Posture Profile</h2><DemoModeBadge /></div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-3">Self-Reported Profile</h3>
              <p className="text-sm text-white/60">You sit <span className="text-violet-soft">{answers?.sitting} hours/day</span>, take breaks <span className="text-violet-soft">{answers?.breaks === 1 ? 'frequently' : answers?.breaks === 4 ? 'rarely' : 'occasionally'}</span>, and your screen is <span className="text-violet-soft">{answers?.screen === 1 ? 'at eye level' : 'below eye level'}</span>.</p>
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-3">Areas to Work On</h3>
              <ul className="space-y-2 text-sm text-white/60">
                {(answers?.sitting as number || 0) > 6 && <li className="flex items-start gap-2"><span className="text-amber-400">!</span> Extended sitting — add movement breaks every 45 minutes</li>}
                {(answers?.shoulders as number || 0) > 3 && <li className="flex items-start gap-2"><span className="text-amber-400">!</span> Forward shoulder posture — focus on chest openers and scapular retraction</li>}
                {(answers?.screen as number) > 1 && <li className="flex items-start gap-2"><span className="text-amber-400">!</span> Screen position — adjust to eye level to reduce neck strain</li>}
                <li className="flex items-start gap-2"><span className="text-sage-soft">+</span> Build posture awareness through regular check-ins</li>
              </ul>
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-3">Recommended Movements</h3>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{result.exercises.map(ex => <ExerciseCard key={ex.id} exercise={ex} />)}</div>
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-2">Desk Movement Routine</h3>
              <p className="text-sm text-white/60">Every 45 minutes: 1 minute of shoulder rolls, 1 minute seated spinal twist, 1 minute standing side stretch. Set a reminder.</p>
            </div>
            <Disclaimer />
            <button onClick={() => { setResult(null); setAnswers(null); }} className="btn-secondary">Retake Assessment</button>
          </div>
        )}
      </div>
    </div>
  );
}

export function FlexibilityLabPage() {
  const [result, setResult] = useState<ReturnType<typeof recommendExercises> | null>(null);
  const [answers, setAnswers] = useState<Record<string, number | number[]> | null>(null);
  const questions: AssessmentQuestion[] = [
    { id: 'hamstrings', question: 'Can you touch your toes with straight legs?', type: 'scale', min: 1, max: 5, labels: ['Easily', 'Cannot'] },
    { id: 'shoulders', question: 'Can you reach behind your back to touch the other hand?', type: 'scale', min: 1, max: 5, labels: ['Easily', 'Cannot'] },
    { id: 'hips', question: 'How easily can you sit cross-legged on the floor?', type: 'scale', min: 1, max: 5, labels: ['Easily', 'Cannot'] },
    { id: 'spine', question: 'How is your spinal mobility (twisting)?', type: 'scale', min: 1, max: 5, labels: ['Full range', 'Very limited'] },
    { id: 'neck', question: 'How is your neck mobility?', type: 'scale', min: 1, max: 5, labels: ['Full range', 'Very limited'] },
  ];
  return (
    <div className="pb-20">
      <PageHeader title="Flexibility Lab" subtitle="Rate your flexibility in key areas and get a targeted improvement plan." badge="AI Tool" />
      <div className="section-padding">
        {!result ? <AssessmentFlow questions={questions} onComplete={(a) => { setAnswers(a); setResult(recommendExercises({ goal: 'Flexibility', limit: 6 })); }} /> : (
          <div className="space-y-6">
            <div className="flex items-center justify-between"><h2 className="font-display text-2xl font-bold text-white">Flexibility Profile</h2><DemoModeBadge /></div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-3">Priority Areas</h3>
              <div className="space-y-2">
                {Object.entries(answers || {}).sort((a, b) => (b[1] as number) - (a[1] as number)).map(([key, val]) => (
                  <div key={key} className="flex items-center justify-between">
                    <span className="text-sm text-white/60 capitalize">{key}</span>
                    <div className="flex items-center gap-2"><div className="w-24 h-2 bg-white/5 rounded-full"><div className="h-full bg-gradient-to-r from-sage-glow to-cyan-glow rounded-full" style={{ width: `${(val as number) * 20}%` }} /></div><span className="text-xs text-white/40">{val as number}/5</span></div>
                  </div>
                ))}
              </div>
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-3">Recommended Movements</h3>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{result.exercises.map(ex => <ExerciseCard key={ex.id} exercise={ex} />)}</div>
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-2">Weekly Flexibility Routine</h3>
              <p className="text-sm text-white/60">3-4 sessions per week, 15-20 minutes each. Hold each stretch for 30-60 seconds. Never force — progress gradually.</p>
            </div>
            <Disclaimer />
            <button onClick={() => { setResult(null); setAnswers(null); }} className="btn-secondary">Retake Assessment</button>
          </div>
        )}
      </div>
    </div>
  );
}

export function MobilityLabPage() {
  const [result, setResult] = useState<ReturnType<typeof recommendExercises> | null>(null);
  const [answers, setAnswers] = useState<Record<string, number | number[]> | null>(null);
  const questions: AssessmentQuestion[] = [
    { id: 'Neck', question: 'Neck mobility and comfort?', type: 'scale', min: 1, max: 5, labels: ['Limited', 'Full'] },
    { id: 'Shoulders', question: 'Shoulder mobility?', type: 'scale', min: 1, max: 5, labels: ['Limited', 'Full'] },
    { id: 'Spine', question: 'Spinal mobility?', type: 'scale', min: 1, max: 5, labels: ['Limited', 'Full'] },
    { id: 'Wrists', question: 'Wrist mobility?', type: 'scale', min: 1, max: 5, labels: ['Limited', 'Full'] },
    { id: 'Hips', question: 'Hip mobility?', type: 'scale', min: 1, max: 5, labels: ['Limited', 'Full'] },
    { id: 'Knees', question: 'Knee mobility?', type: 'scale', min: 1, max: 5, labels: ['Limited', 'Full'] },
    { id: 'Ankles', question: 'Ankle mobility?', type: 'scale', min: 1, max: 5, labels: ['Limited', 'Full'] },
  ];
  const priority = answers ? Object.entries(answers).sort((a, b) => (a[1] as number) - (b[1] as number)).slice(0, 3).map(e => e[0]) : [];
  return (
    <div className="pb-20">
      <PageHeader title="Mobility Lab" subtitle="Rate joint mobility across 7 regions and get a targeted improvement plan." badge="AI Tool" />
      <div className="section-padding">
        {!result ? <AssessmentFlow questions={questions} onComplete={(a) => { setAnswers(a); setResult(recommendExercises({ goal: 'Mobility', limit: 6 })); }} /> : (
          <div className="space-y-6">
            <div className="flex items-center justify-between"><h2 className="font-display text-2xl font-bold text-white">Mobility Profile</h2><DemoModeBadge /></div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-3">Priority Regions</h3>
              <div className="space-y-2">
                {Object.entries(answers || {}).map(([key, val]) => (
                  <div key={key} className="flex items-center justify-between">
                    <span className="text-sm text-white/60">{key}</span>
                    <div className="flex items-center gap-2"><div className="w-24 h-2 bg-white/5 rounded-full"><div className="h-full bg-gradient-to-r from-violet-glow to-cyan-glow rounded-full" style={{ width: `${(val as number) * 20}%` }} /></div><span className="text-xs text-white/40">{val as number}/5</span></div>
                  </div>
                ))}
              </div>
              <p className="text-sm text-violet-soft mt-4">Focus on: {priority.join(', ')}</p>
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-3">Recommended Exercises</h3>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{result.exercises.map(ex => <ExerciseCard key={ex.id} exercise={ex} />)}</div>
            </div>
            <Disclaimer />
            <button onClick={() => { setResult(null); setAnswers(null); }} className="btn-secondary">Retake Assessment</button>
          </div>
        )}
      </div>
    </div>
  );
}

export function RecoveryLabPage() {
  const [result, setResult] = useState<ReturnType<typeof recommendExercises> | null>(null);
  const [answers, setAnswers] = useState<Record<string, number | number[]> | null>(null);
  const questions: AssessmentQuestion[] = [
    { id: 'energy', question: 'Current energy level?', type: 'scale', min: 1, max: 5, labels: ['Depleted', 'High'] },
    { id: 'sleep', question: 'How well did you sleep last night?', type: 'scale', min: 1, max: 5, labels: ['Poorly', 'Great'] },
    { id: 'stress', question: 'Current stress level?', type: 'scale', min: 1, max: 5, labels: ['Low', 'High'] },
    { id: 'activity', question: 'How intense was your recent activity?', type: 'scale', min: 1, max: 5, labels: ['Light', 'Very intense'] },
    { id: 'comfort', question: 'General body comfort?', type: 'scale', min: 1, max: 5, labels: ['Uncomfortable', 'Great'] },
  ];
  const lowEnergy = (answers?.energy as number || 3) <= 2;
  return (
    <div className="pb-20">
      <PageHeader title="Recovery Lab" subtitle="Get personalized recovery recommendations based on your current state." badge="AI Tool" />
      <div className="section-padding">
        {!result ? <AssessmentFlow questions={questions} onComplete={(a) => { setAnswers(a); setResult(recommendExercises({ goal: 'Recovery', limit: 6 })); }} /> : (
          <div className="space-y-6">
            <div className="flex items-center justify-between"><h2 className="font-display text-2xl font-bold text-white">Recovery Recommendations</h2><DemoModeBadge /></div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-3">Your Recovery Profile</h3>
              <p className="text-sm text-white/60">{lowEnergy ? 'Your energy is low — prioritize gentle, restorative practices.' : 'Your energy is moderate — a mix of light mobility and breathing is ideal.'} Stress level: {(answers?.stress as number) <= 2 ? 'low' : 'elevated'}.</p>
            </div>
            <div className="glass p-6">
              <h3 className="font-display font-semibold text-white mb-3">Recommended Session</h3>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{result.exercises.map(ex => <ExerciseCard key={ex.id} exercise={ex} />)}</div>
            </div>
            <Disclaimer />
            <button onClick={() => { setResult(null); setAnswers(null); }} className="btn-secondary">Retake</button>
          </div>
        )}
      </div>
    </div>
  );
}
