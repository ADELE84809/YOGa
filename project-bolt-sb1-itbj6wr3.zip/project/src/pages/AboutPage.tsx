import { PageHeader, Disclaimer } from '@/components/Shared';
import { Activity, Brain, Heart, Globe, Zap, Eye } from 'lucide-react';

export function AboutPage() {
  return (
    <div className="pb-20">
      <PageHeader title="About GlobalYogaCourse" subtitle="An intelligent global wellness platform for movement, yoga, recovery, mindfulness, and everyday wellness." badge="About" />
      <div className="section-padding space-y-8 max-w-3xl">
        <div className="glass p-6">
          <h2 className="font-display text-xl font-bold text-white mb-3">Our Mission</h2>
          <p className="text-white/60 text-sm leading-relaxed">GlobalYogaCourse exists to make intelligent wellness accessible to everyone. We combine movement science, yoga tradition, and AI-assisted personalization into a single platform that helps you understand your body, move better, and build sustainable wellness habits.</p>
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          {[
            { icon: Brain, title: 'AI-Assisted Personalization', desc: 'Every tool adapts to your goals, experience, and feedback — not generic templates.' },
            { icon: Eye, title: 'Movement Education', desc: 'See how your body moves with the Virtual Human system and understand every exercise.' },
            { icon: Heart, title: 'Accessibility', desc: 'Free tools with no sign-up required. Premium courses for deeper learning.' },
            { icon: Globe, title: 'Global Wellness', desc: 'International, technological, and premium — not limited to traditional yoga.' },
          ].map(item => {
            const Icon = item.icon;
            return (
              <div key={item.title} className="glass-card p-5">
                <div className="p-3 rounded-xl bg-white/5 w-fit mb-3"><Icon className="w-5 h-5 text-violet-soft" /></div>
                <h3 className="font-display font-semibold text-white mb-1">{item.title}</h3>
                <p className="text-sm text-white/50">{item.desc}</p>
              </div>
            );
          })}
        </div>
        <div className="glass p-6">
          <h2 className="font-display text-xl font-bold text-white mb-3">Wellness Philosophy</h2>
          <p className="text-white/60 text-sm leading-relaxed">The core loop is simple: Understand your body → Move better → Practice → Reflect → Recover → Improve → Repeat. We believe in real data over fake statistics, genuine functionality over flashy visuals, and sustainable habits over quick fixes.</p>
        </div>
        <div className="glass p-6">
          <h2 className="font-display text-xl font-bold text-white mb-3">AI Transparency</h2>
          <p className="text-white/60 text-sm leading-relaxed">When no real AI API is connected, intelligent outputs are labeled <span className="text-violet-soft">Demo Intelligence Mode</span> — deterministic structured logic, not a live AI model. The architecture is designed for future real AI integration. We never pretend a human or AI expert is reviewing you.</p>
        </div>
        <Disclaimer />
      </div>
    </div>
  );
}
