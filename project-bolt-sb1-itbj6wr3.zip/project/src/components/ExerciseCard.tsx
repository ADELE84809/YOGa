import { Link } from 'react-router-dom';
import { Clock, BarChart3, Tag } from 'lucide-react';
import type { Exercise } from '@/data/types';

const diffColors: Record<string, string> = {
  Beginner: 'text-sage-soft border-sage-glow/30 bg-sage-glow/10',
  Intermediate: 'text-cyan-soft border-cyan-glow/30 bg-cyan-glow/10',
  Advanced: 'text-violet-soft border-violet-glow/30 bg-violet-glow/10',
};

export function ExerciseCard({ exercise }: { exercise: Exercise }) {
  return (
    <Link to={`/exercise/${exercise.id}`} className="glass-card p-4 group block">
      <div className="flex items-start justify-between gap-2 mb-3">
        <span className={`badge ${diffColors[exercise.difficulty] || diffColors.Beginner}`}>{exercise.difficulty}</span>
        <span className="badge-neutral">{exercise.category}</span>
      </div>
      <h3 className="font-display font-semibold text-white text-base leading-tight group-hover:text-violet-soft transition-colors">{exercise.name}</h3>
      <p className="text-white/40 text-xs mt-1">{exercise.subcategory}</p>
      <div className="flex items-center gap-3 mt-3 text-xs text-white/50">
        <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{Math.floor(exercise.duration / 60)}min</span>
        <span className="flex items-center gap-1"><BarChart3 className="w-3 h-3" />{exercise.goals[0]}</span>
      </div>
      <div className="flex flex-wrap gap-1 mt-2">
        {exercise.targetAreas.slice(0, 3).map(a => (
          <span key={a} className="text-[10px] text-white/30 px-1.5 py-0.5 rounded bg-white/5">{a}</span>
        ))}
      </div>
    </Link>
  );
}
