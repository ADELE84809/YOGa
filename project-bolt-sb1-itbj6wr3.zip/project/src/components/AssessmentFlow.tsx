import { useState } from 'react';
import { ChevronRight, ChevronLeft } from 'lucide-react';

export interface AssessmentQuestion {
  id: string; question: string; type: 'scale' | 'choice' | 'multi';
  options?: { label: string; value: number }[];
  min?: number; max?: number; labels?: [string, string];
}

interface Props { questions: AssessmentQuestion[]; onComplete: (answers: Record<string, number | number[]>) => void; title?: string; }

export function AssessmentFlow({ questions, onComplete, title = 'Assessment' }: Props) {
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number | number[]>>({});

  const q = questions[current];
  const isLast = current === questions.length - 1;

  const setAnswer = (value: number | number[]) => { setAnswers({ ...answers, [q.id]: value }); };
  const next = () => { if (isLast) onComplete(answers); else setCurrent(c => c + 1); };
  const back = () => setCurrent(c => Math.max(0, c - 1));

  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <span className="text-sm text-white/40 font-mono">{current + 1} / {questions.length}</span>
        <div className="flex-1 mx-4 h-1 bg-white/5 rounded-full overflow-hidden">
          <div className="h-full bg-gradient-to-r from-violet-glow to-cyan-glow transition-all duration-500" style={{ width: `${((current + 1) / questions.length) * 100}%` }} />
        </div>
      </div>
      <div key={q.id} className="animate-fade-up">
        <h2 className="font-display text-2xl font-bold text-white mb-6 text-balance">{q.question}</h2>
        {q.type === 'scale' && (
          <div className="space-y-4">
            <input type="range" min={q.min || 0} max={q.max || 10} value={(answers[q.id] as number) || 5}
              onChange={e => setAnswer(Number(e.target.value))} className="w-full accent-violet-glow" />
            <div className="flex justify-between text-xs text-white/40">
              <span>{q.labels?.[0] || 'Low'}</span>
              <span className="text-violet-soft font-mono text-lg">{answers[q.id] as number || 5}</span>
              <span>{q.labels?.[1] || 'High'}</span>
            </div>
          </div>
        )}
        {q.type === 'choice' && (
          <div className="grid gap-3">
            {q.options?.map(opt => (
              <button key={opt.value} onClick={() => { setAnswer(opt.value); setTimeout(next, 200); }}
                className={`glass-card p-4 text-left transition-all ${answers[q.id] === opt.value ? 'border-violet-glow/40 bg-violet-glow/10' : ''}`}>
                <span className="text-white">{opt.label}</span>
              </button>
            ))}
          </div>
        )}
        {q.type === 'multi' && (
          <div className="grid gap-3">
            {q.options?.map(opt => {
              const selected = (answers[q.id] as number[] || []).includes(opt.value);
              return (
                <button key={opt.value} onClick={() => {
                  const current = (answers[q.id] as number[]) || [];
                  setAnswer(selected ? current.filter(v => v !== opt.value) : [...current, opt.value]);
                }} className={`glass-card p-4 text-left transition-all ${selected ? 'border-violet-glow/40 bg-violet-glow/10' : ''}`}>
                  <span className="text-white">{opt.label}</span>
                </button>
              );
            })}
          </div>
        )}
        <div className="flex items-center justify-between mt-8">
          <button onClick={back} disabled={current === 0} className="btn-ghost disabled:opacity-30 flex items-center gap-1">
            <ChevronLeft className="w-4 h-4" /> Back
          </button>
          {q.type !== 'choice' && (
            <button onClick={next} className="btn-primary flex items-center gap-1">
              {isLast ? 'Complete' : 'Next'} <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
