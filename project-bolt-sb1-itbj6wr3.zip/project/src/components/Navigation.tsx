import { Link, useLocation } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { Home, Sparkles, Wrench, LayoutDashboard, BookOpen, Menu, X, Activity } from 'lucide-react';

const navLinks = [
  { name: 'Home', path: '/' },
  { name: 'AI Tools', path: '/ai-tools' },
  { name: 'Exercises', path: '/exercises' },
  { name: 'Wellness OS', path: '/wellness-os' },
  { name: 'Programs', path: '/programs' },
  { name: 'Courses', path: '/courses' },
  { name: 'About', path: '/about' },
];

const mobileNav = [
  { name: 'Home', path: '/', icon: Home },
  { name: 'AI', path: '/ai-tools', icon: Sparkles },
  { name: 'Tools', path: '/exercises', icon: Wrench },
  { name: 'Today', path: '/wellness-os', icon: LayoutDashboard },
  { name: 'Courses', path: '/courses', icon: BookOpen },
];

export function Navigation() {
  const location = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => { setMobileMenuOpen(false); }, [location.pathname]);

  return (
    <>
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-ink-950/80 backdrop-blur-xl border-b border-white/5' : 'bg-transparent'}`}>
        <div className="section-padding flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-glow to-cyan-glow flex items-center justify-center">
              <Activity className="w-5 h-5 text-white" />
            </div>
            <span className="font-display font-bold text-white text-lg hidden sm:block">GlobalYogaCourse</span>
          </Link>
          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map(l => (
              <Link key={l.path} to={l.path} className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${location.pathname === l.path ? 'text-white bg-white/10' : 'text-white/50 hover:text-white hover:bg-white/5'}`}>
                {l.name}
              </Link>
            ))}
          </div>
          <div className="flex items-center gap-3">
            <Link to="/ai-tools" className="btn-primary text-sm hidden sm:inline-flex">Try Free</Link>
            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="lg:hidden p-2 text-white/60 hover:text-white">
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
        {mobileMenuOpen && (
          <div className="lg:hidden bg-ink-900/95 backdrop-blur-xl border-b border-white/5">
            <div className="section-padding py-4 flex flex-col gap-1">
              {navLinks.map(l => (
                <Link key={l.path} to={l.path} className={`px-4 py-3 rounded-lg text-sm font-medium transition-colors ${location.pathname === l.path ? 'text-white bg-white/10' : 'text-white/60 hover:text-white hover:bg-white/5'}`}>
                  {l.name}
                </Link>
              ))}
              <Link to="/ai-tools" className="btn-primary text-sm mt-2 text-center">Try Free</Link>
            </div>
          </div>
        )}
      </nav>
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-ink-900/90 backdrop-blur-xl border-t border-white/5">
        <div className="flex items-center justify-around h-16">
          {mobileNav.map(item => {
            const Icon = item.icon;
            const active = location.pathname === item.path;
            return (
              <Link key={item.path} to={item.path} className={`flex flex-col items-center gap-1 px-3 py-2 transition-colors ${active ? 'text-violet-soft' : 'text-white/40'}`}>
                <Icon className="w-5 h-5" />
                <span className="text-xs font-medium">{item.name}</span>
              </Link>
            );
          })}
        </div>
      </nav>
    </>
  );
}
