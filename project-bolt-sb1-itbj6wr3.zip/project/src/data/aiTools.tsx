import { Link } from 'react-router-dom';
import { Activity, Brain, Eye, Heart, Moon, Target, TrendingUp, Users, Wind, Zap, Dumbbell, Calendar, Sparkles, Gauge, Timer, FlaskConical } from 'lucide-react';

export const aiTools = [
  { id: 'ai-yoga-coach', name: 'AI Yoga Coach', icon: Sparkles, desc: 'Get a personalized wellness profile and practice plan', route: '/ai-yoga-coach', color: 'violet' },
  { id: 'exercise-intelligence', name: 'Exercise Intelligence', icon: Brain, desc: 'Find the perfect exercises based on your goals', route: '/exercise-intelligence', color: 'cyan' },
  { id: 'movement-visualizer', name: 'Movement Visualizer', icon: Eye, desc: 'Interactive movement laboratory with virtual human', route: '/movement-visualizer', color: 'violet' },
  { id: 'posture-lab', name: 'Posture Lab', icon: Activity, desc: 'Assess your posture and get corrective movements', route: '/posture-lab', color: 'cyan' },
  { id: 'flexibility-lab', name: 'Flexibility Lab', icon: TrendingUp, desc: 'Test your flexibility and get targeted routines', route: '/flexibility-lab', color: 'sage' },
  { id: 'mobility-lab', name: 'Mobility Lab', icon: Dumbbell, desc: 'Rate joint mobility and get improvement plans', route: '/mobility-lab', color: 'violet' },
  { id: 'breathing-lab', name: 'Breathing Lab', icon: Wind, desc: 'Interactive breathing sessions with visual guide', route: '/breathing-lab', color: 'cyan' },
  { id: 'meditation-studio', name: 'Meditation Studio', icon: Moon, desc: 'Personalized meditation sessions', route: '/meditation-studio', color: 'sage' },
  { id: 'wellness-assessment', name: 'Wellness Assessment', icon: Gauge, desc: 'Comprehensive wellness evaluation', route: '/wellness-assessment', color: 'violet' },
  { id: 'routine-builder', name: 'Daily Routine Builder', icon: Calendar, desc: 'Build your perfect daily wellness routine', route: '/routine-builder', color: 'cyan' },
  { id: 'habit-intelligence', name: 'Habit Intelligence', icon: Target, desc: 'Track and analyze your wellness habits', route: '/habit-intelligence', color: 'sage' },
  { id: 'recovery-lab', name: 'Recovery Lab', icon: Heart, desc: 'Get personalized recovery recommendations', route: '/recovery-lab', color: 'violet' },
  { id: 'sleep-studio', name: 'Sleep Studio', icon: Moon, desc: 'Evening wind-down routines for better rest', route: '/sleep-studio', color: 'cyan' },
  { id: 'focus-studio', name: 'Focus Studio', icon: Zap, desc: 'Focus timer with breathing and movement breaks', route: '/focus-studio', color: 'violet' },
  { id: 'nutrition', name: 'Nutrition Education', icon: FlaskConical, desc: 'Learn wellness nutrition fundamentals', route: '/nutrition', color: 'sage' },
  { id: 'wellness-score', name: 'Wellness Score', icon: Gauge, desc: 'Transparent score from your real data', route: '/wellness-score', color: 'cyan' },
  { id: 'progress-intelligence', name: 'Progress Intelligence', icon: TrendingUp, desc: 'Insights from your actual activity', route: '/progress-intelligence', color: 'violet' },
  { id: 'goal-planner', name: 'Goal Planner', icon: Target, desc: 'Plan milestones and weekly targets', route: '/goal-planner', color: 'sage' },
  { id: 'session-builder', name: 'Personalized Session Builder', icon: Timer, desc: 'Build a custom session from the exercise database', route: '/session-builder', color: 'cyan' },
  { id: 'globalyoga-ai', name: 'GlobalYoga AI Coach', icon: Brain, desc: 'Central intelligence combining all your data', route: '/globalyoga-ai', color: 'violet' },
];

export function ToolCard({ tool }: { tool: typeof aiTools[0] }) {
  const Icon = tool.icon;
  const colorMap: Record<string, string> = {
    violet: 'border-violet-glow/20 hover:border-violet-glow/40 text-violet-soft',
    cyan: 'border-cyan-glow/20 hover:border-cyan-glow/40 text-cyan-soft',
    sage: 'border-sage-glow/20 hover:border-sage-glow/40 text-sage-soft',
  };
  return (
    <Link to={tool.route} className={`glass-card p-5 group block ${colorMap[tool.color] || colorMap.violet}`}>
      <div className="flex items-start gap-4">
        <div className="p-3 rounded-xl bg-white/5 group-hover:bg-white/10 transition-colors">
          <Icon className="w-6 h-6" />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-display font-semibold text-white text-lg leading-tight">{tool.name}</h3>
          <p className="text-white/50 text-sm mt-1 leading-relaxed">{tool.desc}</p>
        </div>
      </div>
    </Link>
  );
}
